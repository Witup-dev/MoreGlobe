﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Balaso;

public class AppTrackingTransparencyBehaviour : MonoBehaviour
{

    
    private void Awake()
    {
#if UNITY_IOS
        AppTrackingTransparency.RegisterAppForAdNetworkAttribution();
        AppTrackingTransparency.UpdateConversionValue(3);
#else
        Destroy(this);
#endif

    }

    void Start()
    {
#if UNITY_IOS || UNITY_EDITOR
        AppTrackingTransparency.OnAuthorizationRequestDone += OnAuthorizationRequestDone;

        AppTrackingTransparency.AuthorizationStatus currentStatus = AppTrackingTransparency.TrackingAuthorizationStatus;
        Debug.Log(string.Format("Current authorization status: {0}", currentStatus.ToString()));
        if (currentStatus != AppTrackingTransparency.AuthorizationStatus.AUTHORIZED)
        {
            Debug.Log("Requesting authorization...");
            AppTrackingTransparency.RequestTrackingAuthorization();

        }
        else{
            GameData.instance.iOSHavePermission = true;
            GameData.instance.appConfig._gpsPermission = true;
            GameData.instance.updateAppConfig();
            Input.location.Start();

            GameData.instance.iOS_IDFA = AppTrackingTransparency.IdentifierForAdvertising();
            PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
            PlayerPrefs.Save();
            SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
        }
#endif
    }

#if UNITY_IOS || UNITY_EDITOR

    /// <summary>
    /// Callback invoked with the user's decision
    /// </summary>
    /// <param name="status"></param>
    private void OnAuthorizationRequestDone(AppTrackingTransparency.AuthorizationStatus status)
    {
        switch(status)
        {
            case AppTrackingTransparency.AuthorizationStatus.NOT_DETERMINED:
                Debug.Log("AuthorizationStatus: NOT_DETERMINED");
                break;
            case AppTrackingTransparency.AuthorizationStatus.RESTRICTED:
                Debug.Log("AuthorizationStatus: RESTRICTED");
                break;
            case AppTrackingTransparency.AuthorizationStatus.DENIED:
                {
                    GameData.instance.iOSHavePermission = false;
                    GameData.instance.appConfig._gpsPermission = false;
                    Debug.Log("AuthorizationStatus: DENIED");
                    break;
                }
                
            case AppTrackingTransparency.AuthorizationStatus.AUTHORIZED:
                {
                    GameData.instance.iOSHavePermission = true;
                    GameData.instance.appConfig._gpsPermission = true;
                    Input.location.Start();
                    Debug.Log("AuthorizationStatus: AUTHORIZED");
                    break;
                }
        }

        GameData.instance.updateAppConfig();

        // Obtain IDFA
        GameData.instance.iOS_IDFA = AppTrackingTransparency.IdentifierForAdvertising();

        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
        SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
    }

#endif
}
