using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;                  
using UnityEngine;
using UnityEngine.UI;
using easyar;

             

public class BuildMapController : MonoBehaviour
{
   
    //Sparse Spatial Map Related Objects
    public ARSession Session;

    private SparseSpatialMapBuilderFrameFilter builder;

   /// <summary>
    ///Save button
    /// </summary>
    private Button btnSave;

     /// <summary>
    ///Display text
    /// </summary>
    private Text text;


    

    private void Awake()
    {
       
        if (Session == null)
        {
            Session = FindFirstObjectByType<ARSession>();
        }

        
        if (Session != null)
        {
            Session.StateChanged += OnSessionStateChanged;
        }
        else
        {
            Debug.LogWarning("[BuildMapController] ARSession non trovata in scena.");
        }
    }

    private void OnDestroy()
    {
        if (Session != null)
        {
            Session.StateChanged -= OnSessionStateChanged;
        }
    }

    private void Start()
    {
        
        var btnGo = GameObject.Find("/Canvas/Button");
        if (btnGo != null)
        {
            btnSave = btnGo.GetComponent<Button>();
        }

        
        var txtGo = GameObject.Find("/Canvas/Panel/Text");
        if (txtGo != null)
        {
            text = txtGo.GetComponent<Text>();
        }

        if (btnSave != null)
        {
            btnSave.onClick.AddListener(Save);
            btnSave.interactable = false; 
        }

        if (text != null)
        {
            text.text = "Waiting for ARSession to be ready...";
        }
    }


    private void OnSessionStateChanged(ARSession.SessionState state)
    {
        Debug.Log("[BuildMapController] Session state changed: " + state);

        if (state == ARSession.SessionState.Ready)
        {
            TryFindBuilder();

            if (builder != null)
            {
                if (btnSave != null)
                    btnSave.interactable = true;

                if (text != null)
                    text.text = "Tracking ready. You can save the map.";
            }
            else
            {
                if (text != null)
                    text.text = "Builder not found. Check SparseSpatialMapBuilderFrameFilter in the scene.";
            }
        }
        else
        {
            if (btnSave != null)
                btnSave.interactable = false;

            if (text != null)
                text.text = "Session state: " + state;
        }
    }

     /// <summary>
    ///Save Map Method
    /// </summary>
    private void Save()
    {
        if (builder == null)
        {
            if (text != null)
                text.text = "Cannot save: builder is not ready.";
            Debug.LogWarning("[BuildMapController] Save() chiamato ma builder è null.");
            return;
        }

        if (btnSave != null)
            btnSave.interactable = false;

        string mapName = "LearnMap_" + DateTime.Now.ToString("yyyyMMddHHmm");

        try
        {
           
            builder.Host(
                mapName,
                default,   
                default,  
                OnHostCompleted
            );

            if (text != null)
                text.text = "Saving map \"" + mapName + "\". Please wait...";
        }
        catch (Exception ex)
        {
            Debug.LogError("[BuildMapController] Host exception: " + ex);
            if (text != null)
                text.text = "Save error: " + ex.Message;
            if (btnSave != null)
                btnSave.interactable = true;
        }
    }

      private void TryFindBuilder()
    {
        if (Session == null || Session.Assembly == null)
        {
            Debug.LogWarning("[BuildMapController] Session o Assembly null, non posso trovare il builder.");
            return;
        }

        builder = Session.Assembly.FrameFilters
            .OfType<SparseSpatialMapBuilderFrameFilter>()
            .FirstOrDefault();

        if (builder != null)
        {
            Debug.Log("[BuildMapController] SparseSpatialMapBuilderFrameFilter trovato.");
        }
        else
        {
            Debug.LogWarning("[BuildMapController] Nessun SparseSpatialMapBuilderFrameFilter trovato nell'Assembly.");
        }
    }

    private void OnHostCompleted(
        Optional<SparseSpatialMapController.SparseSpatialMapInfo> mapInfoOpt,
        Optional<string> errorOpt)
    {
        if (btnSave != null)
            btnSave.interactable = true;

        
        if (mapInfoOpt.OnSome)
        {
            var info = mapInfoOpt.Value;

           
            PlayerPrefs.SetString("MapID", info.ID);
            PlayerPrefs.SetString("MapName", info.Name);
            PlayerPrefs.Save();

            if (text != null)
            {
                text.text = "The map was saved successfully.\r\nMapID: " + info.ID + "\r\nMapName: " + info.Name;
            }

            Debug.Log($"[BuildMapController] Map saved. ID: {info.ID}, Name: {info.Name}");
            return;
        }

        
        if (errorOpt.OnSome)
        {
            string err = errorOpt.Value;
            if (text != null)
            {
                text.text = "Map save error: " + err;
            }
            Debug.LogError("[BuildMapController] Map save error: " + err);
        }
        else
        {
            
            if (text != null)
            {
                text.text = "Map save failed for unknown reason.";
            }
            Debug.LogError("[BuildMapController] Map save failed for unknown reason.");
        }
    }

    /// <summary>
    ///Camera state change
    /// </summary>
    /// <param name="status">status</param>

    private void OnTrackingStatusChanged(MotionTrackingStatus status)
 {
     if (btnSave == null || text == null)
         return;

     if (status == MotionTrackingStatus.Tracking)
     {
         btnSave.interactable = true;
         text.text = "Enter the tracking state.";
     }
     else
     {
         btnSave.interactable = false;
         text.text = "Exit tracking status. " + status;
     }
 }
}
