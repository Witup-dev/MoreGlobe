using UnityEngine;
public class ModelEntity : MonoBehaviour
{

    //' Inizializza posizione, rotazione e scala del modello 3D
    public void Constructor(DataRequest response)
    {
        GameObject meshGB = GetComponentInChildren<MeshRenderer>().gameObject;

        name = response.uid;

        RectTransform _rectTransform = gameObject.AddComponent<RectTransform>();

        _rectTransform.localPosition = new Vector3(response.x, response.y, response.z);
        Vector3 rot = new Vector3(response.rotation_x - 90f, response.rotation_y, response.rotation_z);
        _rectTransform.eulerAngles = rot;
        // transform.localRotation = Quaternion.Euler(new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        _rectTransform.localScale = new Vector3(response.width, response.height, response.deep);
        _rectTransform.sizeDelta = new Vector2(response.scale_x, response.scale_y);

    }
}