
using UnityEngine;
using System;
using UnityEngine.Video;
using UnityEngine.UI;
using TMPro;
using System.Globalization;

public class TextEntity : MonoBehaviour
{
    [SerializeField] RectTransform _rectTransform;
    [SerializeField] TMP_Text _text;
    [SerializeField] Animator m_anim;
    [SerializeField] TMP_FontAsset defaultFont;


    // Configura posizione, stile e animazione del testo
    public void Constructor(DataRequest response)
    {
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, 0, response.width);
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0, response.height);
        // _rectTransform.localRotation = Quaternion.AngleAxis(0f, new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        // _rectTransform.anchoredPosition = new Vector2(response.x, response.y);

        _rectTransform.sizeDelta = new Vector3(response.scale_x, response.scale_y);
        _rectTransform.localScale = new Vector3(response.width, response.height, response.deep);
        transform.localRotation = Quaternion.Euler(new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        _rectTransform.localPosition = new Vector3(response.x, response.y, response.z);

        _text.text = response.title;

        if (response.extra != null)
        {
            foreach (ExtraModel extra in response.extra)
            {
                switch (extra.key_)
                {
                    case "animation":
                        m_anim.Play(extra.value_);
                        break;
                    case "textcolor":
                        if (ColorUtility.TryParseHtmlString(extra.value_, out Color color))
                        {
                            Debug.Log($"color {color}");
                            _text.color = color;
                        }
                        break;
                    case "textfont":
                        if (!string.IsNullOrEmpty(extra.value_))
                            _text.font = Resources.Load($"Fonts/{extra.value_}") as TMP_FontAsset;
                        else
                            _text.font = defaultFont;
                        break;
                    case "textalignment":
                        _text.alignment = (TextAlignmentOptions)Enum.Parse(typeof(TextAlignmentOptions), extra.value_);
                        break;
                    case "textstyle":
                        _text.fontStyle = (FontStyles)Enum.Parse(typeof(FontStyles), extra.value_);
                        break;
                    case "textsize":
                        Debug.Log($"extra.value {extra.value_}");
                        extra.value_ = extra.value_.Replace('.', ',');
                        Debug.Log($"new extra.value {extra.value_}");
                        _text.fontSize = float.Parse(extra.value_);
                        Debug.Log($"_text.fontSize {_text.fontSize}");
                        //float.Parse(extra.value_, System.Globalization.CultureInfo.InvariantCulture);
                        break;
                }
            }
        }
    }
}