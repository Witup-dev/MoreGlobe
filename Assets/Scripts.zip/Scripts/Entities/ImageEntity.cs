using System;
using UnityEngine;
using UnityEngine.UI;

public class ImageEntity : MonoBehaviour
{
    [SerializeField] RectTransform _rectTransform;
    [SerializeField] Image _imageComponent;
    [SerializeField] Animator m_anim;


    //' Configura posizione, scala, rotazione, animazione e immagine
    public void Constructor(DataRequest response)
    {
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, 0, response.width);
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0, response.height);
        // _rectTransform.localRotation = Quaternion.AngleAxis(0f, new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        // _rectTransform.anchoredPosition = new Vector2(response.x, response.y);

        _rectTransform.sizeDelta = new Vector3(response.scale_x, response.scale_y);
        _rectTransform.localScale = new Vector3(response.width, response.height, response.deep);
        transform.localRotation = Quaternion.Euler(new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        _rectTransform.localPosition = new Vector3(response.x, response.y, response.z);

        if (response.extra != null)
        {
            foreach (ExtraModel extra in response.extra)
            {
                switch (extra.key_)
                {
                    case "animation":
                        m_anim.Play(extra.value_);
                        break;
                }
            }
        }
        OfflineGameManager.instance.targetManagerInstance.DownloadImage(response.url, _imageComponent);
    }
}