using System.Collections;
using System;
using UnityEngine;
using Video = UnityEngine.Video;
using UnityEngine.UI;
using easyar;

public class VideoEntity : MonoBehaviour
{
    [SerializeField] RectTransform _rectTransform;
    [SerializeField] RawImage renderImage;
    [SerializeField] Video.VideoPlayer _videoPlayer;
    [SerializeField] GameObject playImage;
    [SerializeField] Animator m_anim;

    public void Constructor(DataRequest response, ImageTargetController controller)
    {
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, 0, response.width);
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0, response.height);
        // transform.localRotation = Quaternion.AngleAxis(0f, new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        // _rectTransform.anchoredPosition = new Vector2(response.x, response.y);


        Debug.Log($"response.scale {response.scale_x} - {response.scale_y}");
        _rectTransform.sizeDelta = new Vector3(response.scale_x, response.scale_y);
        _rectTransform.localScale = new Vector3(response.width, response.height, response.deep);
        transform.localRotation = Quaternion.Euler(new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        _rectTransform.localPosition = new Vector3(response.x, response.y, response.z);

        if (response.extra != null)
        {
            foreach (ExtraModel extra in response.extra)
            {
                switch (extra.key_)
                {
                    case "animation":
                        m_anim.Play(extra.value_);
                        break;
                }
            }
        }
        RenderTexture rt = new RenderTexture(1920, 1080, 16, RenderTextureFormat.ARGB32);
        rt.Create();
        _videoPlayer.targetTexture = rt;
        renderImage.texture = rt;
        _videoPlayer.playOnAwake = response.autoplay;
        switch (response.source)
        {
            case "youtube":
                _videoPlayer.url = response.youtube_url;
                break;
            case "mp4":
                _videoPlayer.url = response.url;
                break;
        }
        GetComponent<Button>().onClick.AddListener(PausePlay);
        if (!_videoPlayer.playOnAwake)
            StartCoroutine(getPrev());
        else
        {
            _videoPlayer.Play();
            playImage.SetActive(false);
        }
        
        controller.TargetLost += () =>
                    {
                        _videoPlayer.Pause();
                    };
    }

    void PausePlay()
    {
        if (_videoPlayer.isPlaying)
        {
            playImage.SetActive(true);
            _videoPlayer.Pause();
        }
        else
        {
            playImage.SetActive(false);
            _videoPlayer.Play();
        }
    }

    IEnumerator getPrev()
    {
        Debug.Log($"[VIDEO PREV");
        _videoPlayer.Play();
        _videoPlayer.EnableAudioTrack(0, false);
        yield return new WaitForSeconds(.5f);
        _videoPlayer.Pause();
        _videoPlayer.EnableAudioTrack(0, true);
        playImage.SetActive(true);
    }
}
