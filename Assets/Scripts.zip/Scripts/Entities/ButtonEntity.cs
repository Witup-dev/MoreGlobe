
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.UI;
using TMPro;
using System.Globalization;

public class ButtonEntity : MonoBehaviour
{
    [SerializeField] RectTransform _rectTransform;
    [SerializeField] TMP_Text _buttonText;
    [SerializeField] Image iconSprite;
    [SerializeField] Animator m_anim;
    [SerializeField] TMP_FontAsset defaultFont;
    private string animationName;


    //' Configura bottone da dati/extra/operation
    public void Constructor(DataRequest response)
    {
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, 0, response.width);
        // _rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0, response.height);
        // _rectTransform.localRotation = Quaternion.AngleAxis(0f, new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        // _rectTransform.anchoredPosition = new Vector2(response.x, response.y);

        _rectTransform.sizeDelta = new Vector3(response.scale_x, response.scale_y);
        _rectTransform.localScale = new Vector3(response.width, response.height, response.deep);
        transform.localRotation = Quaternion.Euler(new Vector3(response.rotation_x, response.rotation_y, response.rotation_z));
        _rectTransform.localPosition = new Vector3(response.x, response.y, response.z);
        _buttonText.text = response.title;

        if (response.extra != null)
        {
            foreach (ExtraModel extra in response.extra)
            {
                switch (extra.key_)
                {
                    case "background":

                        OfflineGameManager.instance.targetManagerInstance.DownloadImage(extra.value_, transform.GetChild(0).GetComponent<Image>());
                        // StartCoroutine(Utilities.getImageAndApply(extra.value_, GetComponent<Image>(), OfflineGameManager.instance.targetManagerInstance.elementorModel.loading, OfflineGameManager.instance.targetManagerInstance.elementorModel.error));
                        break;
                    case "textcolor":
                        if (ColorUtility.TryParseHtmlString(extra.value_, out Color color))
                            _buttonText.color = color;
                        break;
                    case "textfont":
                        if (!string.IsNullOrEmpty(extra.value_))
                            _buttonText.font = Resources.Load($"Fonts/{extra.value_}") as TMP_FontAsset;
                        else
                            _buttonText.font = defaultFont;
                        break;
                    case "textalignment":
                        _buttonText.alignment = (TextAlignmentOptions)Enum.Parse(typeof(TextAlignmentOptions), extra.value_);
                        break;
                    case "textstyle":
                        _buttonText.fontStyle = (FontStyles)Enum.Parse(typeof(FontStyles), extra.value_);
                        break;
                    case "textsize":
                        Debug.Log($"button extra.value {extra.value_}");
                        extra.value_ = extra.value_.Replace('.', ',');
                        Debug.Log($"button new extra.value {extra.value_}");
                        _buttonText.fontSize = float.Parse(extra.value_);
                        Debug.Log($"_buttonText.fontSize {_buttonText.fontSize}");
                        break;
                    case "icon":
                        OfflineGameManager.instance.targetManagerInstance.DownloadImage(extra.value_, iconSprite);
                        // StartCoroutine(Utilities.getImageAndApply(extra.value_, iconSprite, OfflineGameManager.instance.targetManagerInstance.elementorModel.loading, OfflineGameManager.instance.targetManagerInstance.elementorModel.error));
                        iconSprite.preserveAspect = true;
                        iconSprite.gameObject.SetActive(true);
                        break;
                    case "animation":
                        animationName = extra.value_;
                        break;
                }
            }
        }

        if (response.operation != null)
        {
            switch (response.operation.type)
            {
                case "open-url":
                    GetComponent<Button>().onClick.AddListener(delegate { ActionManager.instance.OpenExternalLink(response.operation.action); });
                    break;
            }
        }

        if (!string.IsNullOrEmpty(animationName))
        {
            StartCoroutine(startAnimation(animationName));
        }
    }


    //' Avvia l’animazione del bottone
    IEnumerator startAnimation(string animName)
    {
        _buttonText.gameObject.SetActive(false);
        m_anim.gameObject.SetActive(false);
        yield return new WaitForEndOfFrame();
        _buttonText.gameObject.SetActive(true);
        m_anim.gameObject.SetActive(true);
        yield return new WaitForEndOfFrame();
        m_anim.Play(animName);
    }
}