﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using UnityEngine.UI;
using UnityEngine.Video;
using SimpleJSON;
using UnityEngine.SceneManagement;
using Vuplex.WebView;
using easyar;
using LightShaft.Scripts;
using TMPro;

public class TargetHandler : MonoBehaviour
{
    private Marker currentMarker;

    public ImageTargetController controller;

    public bool isLoading;

    public string id;

    //Buttons
    private GameObject playPauseButton;

    //loader
    private RectTransform loadingSpinner;

    //Player
    private YoutubePlayer _yp;
    private UnityEngine.Video.VideoPlayer player;

    public Animator _anim;

    public GameObject panelPause;

    private UnityEngine.UI.Image sourceType;

    private TextMeshProUGUI textPause;

    //local variable
    public bool isVideoBegin;
    public bool initialized; //TODO : Delete


    public RenderTexture texturePrefab;

    private void Awake()
    {
        isVideoBegin = false;
        isLoading = true;
        player = null;
        initialized = false;
        _anim = null;
        OfflineGameManager.instance.isFrameSomething = false;
    }




    private void Update()
    {

        if (_anim != null)
        {
            //check for animation end and start the video
            if (_anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 1.0f)
            {

                if (!currentMarker.isYoutube) //is an mp4
                {
                    Debug.Log("animazione finita");

                    Destroy(_anim.transform.parent.gameObject);



                    isVideoBegin = true;
                    player.SetDirectAudioMute(0, false);
                    player.time = currentMarker.start;
                    transform.GetChild(0).GetComponent<CanvasGroup>().alpha = 1;

                    player.Play();
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                    OfflineGameManager.instance.sideMenu.show();
                    OfflineGameManager.instance.sideMenu.firstOpen();
                    OfflineGameManager.instance.buttonDoPlayPause(true);
                    Analytics.instance.videoAction(1, currentMarker.name, 1, (int)player.time, GameData.instance.sessionId + ""); //1 play - 2 pause
                }

                else //is a webview
                {
                    Debug.Log("animazione finita");

                    Destroy(_anim.transform.parent.gameObject);

                    transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 1;

                    playButtonBehaviour();

                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                    OfflineGameManager.instance.sideMenu.show();
                    OfflineGameManager.instance.sideMenu.firstOpen();
                    OfflineGameManager.instance.buttonDoPlayPause(true);
                }

            }


        }



        if ((!currentMarker.isYoutube && player != null) && currentMarker.end > 0) //Gestione per il video mp4 con start timing
        {
            if (player.time >= currentMarker.end)
            {
                player.Stop();

                if (OfflineGameManager.instance.isInFullscreen)
                    exitFullscreen();

                OfflineGameManager.instance.buttonDoPlayPause(false);
                player.time = currentMarker.start;
            }
        }
    }

    public void initMarkerTarget()
    {
        if (!PlayerPrefs.HasKey("framingTutorial"))
        {
            PlayerPrefs.SetInt("framingTutorial", 1);
            PlayerPrefs.Save();
        }
        OfflineGameManager.instance.fetch3DModel();

        if (!GameData.instance.webviewForVideo || !currentMarker.isYoutube) //TODO to change only to isYoutube
        {
            //setting youtube
            _yp = GetComponentInChildren<YoutubePlayer>();
            _yp.videoQuality = YoutubePlayer.YoutubeVideoQuality.STANDARD;

            player = transform.GetComponentInChildren<UnityEngine.Video.VideoPlayer>();


            panelPause = transform.GetChild(0).GetChild(1).gameObject;

            textPause = transform.GetChild(0).GetChild(1).GetChild(0).GetComponent<TextMeshProUGUI>();
            textPause.text = currentMarker.markerName;

            sourceType = transform.GetChild(0).GetChild(1).GetChild(1).GetComponent<UnityEngine.UI.Image>();

            panelPause.transform.GetChild(3).GetComponent<Button>().onClick.AddListener(playButtonBehaviour);

            if (string.IsNullOrEmpty(currentMarker.sourceType))
            {
                sourceType.sprite = OfflineGameManager.instance.mp4SourceType;
            }

            else if (currentMarker.sourceType.Equals("youtube"))
            {
                sourceType.sprite = OfflineGameManager.instance.youtubeSourceType;
            }

            playPauseButton = transform.GetChild(1).GetChild(0).GetChild(0).gameObject;
            playPauseButton.SetActive(false);
            loadingSpinner = transform.GetChild(1).GetChild(1).GetComponent<RectTransform>();

            controller = transform.parent.GetComponent<ImageTargetController>();

            OfflineGameManager.instance.setCurrentTarget(this);

            if (currentMarker.tvMode && controller.Size.y > controller.Size.x)
                player.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(1 / controller.Target.aspectRatio(), 1);
            else
                player.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

            loadingSpinner.sizeDelta = new Vector2(0.2f / controller.Target.aspectRatio(), 0.2f / controller.Target.aspectRatio());
            playPauseButton.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(0.5f / controller.Target.aspectRatio(), 0.5f / controller.Target.aspectRatio());

            enableUI();

            OfflineGameManager.instance.isFrameSomething = true;

            if (OfflineGameManager.instance.isInFullscreen)
            {
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);

                OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
            }

            Debug.Log("🚀 ~ file: TargetHandler.cs:194 ~ playVideo");
            playVideo();
            

            initSideBarButtons();

            if (!currentMarker.isComboExperience)
            {
                OfflineGameManager.instance.sideMenu.show();
                OfflineGameManager.instance.sideMenu.firstOpen();
            }


            controller.TargetFound += () =>
            {

                OfflineGameManager.instance.connectionPopupActivator = true;


                if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(currentMarker.name))
                {
                    if (OfflineGameManager.instance.connectionPopup != null)
                    {
                        Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
                    }
                    StartCoroutine(OfflineGameManager.instance.targetManagerInstance.createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
                }

                OfflineGameManager.instance.setCurrentTarget(this);

                initSideBarButtons();

                if (currentMarker.tvMode && controller.Size.y > controller.Size.x)
                    player.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(1 / controller.Target.aspectRatio(), 1);
                else
                    player.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

                enableUI();

                OfflineGameManager.instance.isFrameSomething = true;

                if (OfflineGameManager.instance.isInFullscreen)
                {

                    if (!OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(currentMarker.name))
                    {
                        OfflineGameManager.instance.getCurrentTarget().exitFullscreen();

                        OfflineGameManager.instance.sideMenu.show();
                        OfflineGameManager.instance.buttonDoPlayPause(true);
                    }

                    else
                    {
                        OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);

                        OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
                    }


                }

                Debug.Log("🚀 ~ file: TargetHandler.cs:258 ~ playVideo");
                playVideo();
                

            };



            controller.TargetLost += () =>
            {

                if (!controller.IsTracked && !isVideoBegin)
                {
                    if (OfflineGameManager.instance.connectionPopup != null)
                    {
                        Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
                    }
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                    StartCoroutine(OfflineGameManager.instance.targetManagerInstance.createTarget(controller));

                }

                if (OfflineGameManager.instance.connectionPopup != null)
                {
                    OfflineGameManager.instance.connectionPopup.destroy();
                    OfflineGameManager.instance.resetBadConnectionTimer();
                }


                OfflineGameManager.instance.connectionPopupActivator = false;

                pauseVideo();
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                OfflineGameManager.instance.sideMenu.hide();
                OfflineGameManager.instance.buttonDoPlayPause(false);
                OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
                OfflineGameManager.instance.isFrameSomething = false;
                OfflineGameManager.instance.resetTimer();
            };

        }

        //Is a webView
        else
        {

            controller = transform.parent.GetComponent<ImageTargetController>();

            OfflineGameManager.instance.setCurrentTarget(this);


            enableUI();

            if (currentMarker.isComboExperience)
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);

            OfflineGameManager.instance.isFrameSomething = true;

            initSideBarButtons();


            controller.TargetFound += () =>
            {
                if (controller.transform.GetChild(0).GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha == 1)
                {
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                }

                OfflineGameManager.instance.setCurrentTarget(this);

                initSideBarButtons();

                enableUI();

                OfflineGameManager.instance.isFrameSomething = true;
            };



            controller.TargetLost += () =>
            {
                OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                OfflineGameManager.instance.isFrameSomething = false;
                OfflineGameManager.instance.resetTimer();
            };



        }




    }

    public void initWebView()
    {
        if (!PlayerPrefs.HasKey("framingTutorial"))
        {
            PlayerPrefs.SetInt("framingTutorial", 1);
            PlayerPrefs.Save();
        }

        OfflineGameManager.instance.fetch3DModel();
        controller = transform.parent.GetComponent<ImageTargetController>();

        OfflineGameManager.instance.setCurrentTarget(this);


        enableUI();

        if (currentMarker.isComboExperience)
            OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);

        OfflineGameManager.instance.isFrameSomething = true;

        // initSideBarButtons();


        controller.TargetFound += () =>
        {
            if (controller.transform.GetChild(0).GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha == 1)
            {
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
            }

            OfflineGameManager.instance.setCurrentTarget(this);

            // initSideBarButtons();

            enableUI();

            OfflineGameManager.instance.isFrameSomething = true;
        };



        controller.TargetLost += () =>
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
            OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
            OfflineGameManager.instance.isFrameSomething = false;
            OfflineGameManager.instance.resetTimer();
        };
    }



    private void initSideBarButtons()
    {
        OfflineGameManager.instance.playVideoButton.onClick.RemoveAllListeners();
        OfflineGameManager.instance.pauseVideoButton.onClick.RemoveAllListeners();
        OfflineGameManager.instance.gobackVideoButton.onClick.RemoveAllListeners();
        OfflineGameManager.instance.goForwardVideoButton.onClick.RemoveAllListeners();

        OfflineGameManager.instance.playVideoButton.onClick.AddListener(playButtonBehaviour);
        OfflineGameManager.instance.pauseVideoButton.onClick.AddListener(pauseButtonBehaviour);
        OfflineGameManager.instance.gobackVideoButton.onClick.AddListener(goBackwardButtonBehaviour);
        OfflineGameManager.instance.goForwardVideoButton.onClick.AddListener(goForwardButtonBehaviour);

        OfflineGameManager.instance.siteButton.onClick.RemoveAllListeners();
        OfflineGameManager.instance.fullScreenButton.onClick.RemoveAllListeners();

        OfflineGameManager.instance.fullScreenButton.onClick.AddListener(goToFullScreen);
        OfflineGameManager.instance.siteButton.onClick.AddListener(OfflineGameManager.instance.goToWebView);

    }

    private void playVideo()
    {

        if (isVideoBegin)
        {
            
            panelPause.SetActive(false);
            Debug.Log("🚀 ~ file: TargetHandler.cs:433 ~ panelPause");
            player.Play();
            OfflineGameManager.instance.sideMenu.show();
            OfflineGameManager.instance.sideMenu.firstOpen();
            OfflineGameManager.instance.buttonDoPlayPause(true);
            Analytics.instance.videoAction(1, currentMarker.name, 1, (int)player.time, GameData.instance.sessionId + ""); //1 play - 2 pause
        }

        else
        {
            Debug.Log("🚀 ~ file: TargetHandler.cs:445 ~ adRequest:");
            StartCoroutine(adRequest());
            
        }

    }

    private void pauseVideo()
    {
        if (!OfflineGameManager.instance.isInFullscreen)
        {
            player.Pause();
            Analytics.instance.videoAction(1, currentMarker.name, 2, (int)player.time, GameData.instance.sessionId + ""); //1 play - 2 pause
        }
    }


    public void playButtonBehaviour()
    {
        if (GameData.instance.webviewForVideo && currentMarker.isYoutube)
        {
            controller.transform.GetComponentInChildren<CanvasWebViewPrefab>().WebView.PostMessage(string.Format(
                            "{{ \"type\": \"play\"}}"));

        }

        else
        {
            panelPause.SetActive(false);
            playVideo();
        }

        OfflineGameManager.instance.buttonDoPlayPause(true);

    }

    private void pauseButtonBehaviour()
    {
        if (GameData.instance.webviewForVideo && currentMarker.isYoutube)
        {
            controller.transform.GetComponentInChildren<CanvasWebViewPrefab>().WebView.PostMessage(string.Format(
                            "{{ \"type\": \"pause\"}}"));

        }

        else
        {
            if (!OfflineGameManager.instance.isInFullscreen)
            {
                player.Pause();
                panelPause.SetActive(true);
            }
        }

        OfflineGameManager.instance.buttonDoPlayPause(false);

    }

    private void goForwardButtonBehaviour()
    {
        if (GameData.instance.webviewForVideo && currentMarker.isYoutube)
        {
            controller.transform.GetComponentInChildren<CanvasWebViewPrefab>().WebView.PostMessage(string.Format(
                            "{{ \"type\": \"next-10\"}}"));
        }

        else
        {
            double time = player.time;

            if (currentMarker.isYoutube)
            {
                _yp.Seek((float)time + 10);
                _yp.Play();
            }

            else
            {
                player.time += 10;
            }

            OfflineGameManager.instance.buttonDoPlayPause(true);
        }
    }


    private void goBackwardButtonBehaviour()
    {
        if (GameData.instance.webviewForVideo && currentMarker.isYoutube)
        {
            controller.transform.GetComponentInChildren<CanvasWebViewPrefab>().WebView.PostMessage(string.Format(
                            "{{ \"type\": \"prev-10\"}}"));
        }

        else
        {
            double time = player.time;

            if (currentMarker.isYoutube)
            {
                _yp.Seek((float)time - 10);
                _yp.Play();
            }

            else
            {
                player.time -= 10;
            }

            OfflineGameManager.instance.buttonDoPlayPause(true);
        }
    }

    public void resetVideo()
    {
        player.Stop();
        Analytics.instance.videoAction(2, currentMarker.name, 0, (int)player.time, GameData.instance.sessionId + "");
        resetTexture();

    }

    public void resetTexture()
    {
        RenderTexture videoTexture = new RenderTexture(texturePrefab);
        player.GetComponent<RawImage>().texture = videoTexture;
        player.targetTexture = videoTexture;
    }

    public void PlayPauseButton()
    {
        if (player.isPlaying)
        {
            player.Pause();
            playPauseButton.SetActive(true);
            loadingSpinner = null;

            Analytics.instance.videoAction(1, currentMarker.name, 2, (int)player.time, GameData.instance.sessionId + ""); //1 play - 2 pause
            Debug.Log("Pausa " + player.time);
        }

        else
        {
            player.Play();
            playPauseButton.SetActive(false);
            Analytics.instance.videoAction(1, currentMarker.name, 1, (int)player.time, GameData.instance.sessionId + "");
            Debug.Log("Resume " + player.time);
        }
    }


    private void goToFullScreen()
    {

        if (currentMarker.isWebPage)
        {
            Application.OpenURL(currentMarker.url);
        }

        else if (currentMarker.isYoutube)
        {
            controller.transform.GetComponentInChildren<CanvasWebViewPrefab>().WebView.PostMessage(string.Format(
                            "{{ \"type\": \"time\"}}"));
        }

        else
        {

            OfflineGameManager.instance.sideMenu.hide();
            OfflineGameManager.instance.buttonDoPlayPause(true);


            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
                OfflineGameManager.instance.resetBadConnectionTimer();
            }

            OfflineGameManager.instance.startToCountdownForBadConnection = false;
            OfflineGameManager.instance.connectionPopupActivator = false;

            OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);

            OfflineGameManager.instance.spatialButton.gameObject.SetActive(false);

            OfflineGameManager.instance.isInFullscreen = true;
            OfflineGameManager.instance.iAmWatching.enabled = false;

            player.renderMode = VideoRenderMode.CameraNearPlane;
            player.gameObject.GetComponent<RawImage>().enabled = false;

            //Controllo sull'orientamento
            if (currentMarker.orientation == "L")
            {
                //mandare lo schermo in landscape
                Screen.orientation = ScreenOrientation.LandscapeLeft;
            }
        }



    }

    public void exitFullscreen()
    {

        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(true);
        }

        else
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
        }

        OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);

        if (GameData.instance.modelListForSpatial.Count > 0)
        {
            OfflineGameManager.instance.spatialButton.gameObject.SetActive(true);
        }

        if (!OfflineGameManager.instance.isFrameSomething)
        {
            player.Pause();
            Analytics.instance.videoAction(1, currentMarker.name, 2, (int)player.time, GameData.instance.sessionId + ""); //1 play - 2 pause
            OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
        }

        OfflineGameManager.instance.isInFullscreen = false;
        OfflineGameManager.instance.iAmWatching.enabled = true;

        OfflineGameManager.instance.sideMenu.show();

        player.gameObject.GetComponent<RawImage>().enabled = true;
        player.renderMode = VideoRenderMode.RenderTexture;

        Screen.orientation = ScreenOrientation.Portrait;

    }

    private void ErrorReceived(UnityEngine.Video.VideoPlayer vp, string message)
    {
        //vp.prepareCompleted -= PrepareCompleted;
        //vp.errorReceived -= ErrorReceived;
        Debug.Log($"🚀 ~ file: TargetHandler.cs:690 ~ ErrorReceived: {message}");
        RetryPlayYoutubeVideo(vp);    
    }

    private void RetryPlayYoutubeVideo(UnityEngine.Video.VideoPlayer vp)
    {
        vp.Stop();
        vp.Play();
        Debug.Log("🚀 ~ file: TargetHandler.cs:699 ~ Retrying play");
        
        player.SetDirectAudioMute(0, false);
        transform.GetChild(0).GetComponent<CanvasGroup>().alpha = 1;

        
        OfflineGameManager.instance.buttonDoPlayPause(true);

    }

    

    #region VIDEO EVENTS

    //chiamato quando la preparazione del video è conclusa e lo si fa partire
    private void checkVideoPrepared(UnityEngine.Video.VideoPlayer vp)
    {
        vp.Pause();

        if (!PlayerPrefs.HasKey("offlineTutorial"))
        {
            PlayerPrefs.SetInt("offlineTutorial", 1);
            PlayerPrefs.Save();
        }

        OfflineGameManager.instance.startToCountdownForBadConnection = false;
        OfflineGameManager.instance.connectionPopupActivator = false;

        if (OfflineGameManager.instance.connectionPopup != null)
        {
            OfflineGameManager.instance.connectionPopup.destroy();
        }

        OfflineGameManager.instance.resetBadConnectionTimer();

        if (currentMarker.isComboExperience) //TODO : condizione per combo 3d+video
        {
            if (!initialized)
            {
                initialized = true;
                StartCoroutine(OfflineGameManager.instance.targetManagerInstance.get3DModelForCombo(controller, currentMarker));

            }

        }
        else
        {
            if (!controller.IsTracked)
            {
                if (OfflineGameManager.instance.connectionPopup != null)
                {
                    Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
                }
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                StartCoroutine(OfflineGameManager.instance.targetManagerInstance.createTarget(controller));

            }

            if (transform.childCount >= 5)
                Destroy(transform.GetChild(4).gameObject);

            isVideoBegin = true;
            Debug.Log($"🚀 ~ file: TargetHandler.cs:736 ~ isVideoBegin: {isVideoBegin}");

            if (currentMarker.isYoutube)
            {

                _yp.Play(currentMarker.url);
                transform.GetChild(0).GetComponent<CanvasGroup>().alpha = 1;
                Analytics.instance.videoAction(1, currentMarker.name, 1, (int)_yp.videoPlayer.time, GameData.instance.sessionId + ""); //1 play - 2 pause
            }
            else
            {

                vp.time = currentMarker.start;
                Debug.Log("🚀 ~ file: TargetHandler.cs:749 ~ currentMarker.start");


                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);

                vp.Play();
                player.SetDirectAudioMute(0, false);
                transform.GetChild(0).GetComponent<CanvasGroup>().alpha = 1;

                
                OfflineGameManager.instance.buttonDoPlayPause(true);
                Analytics.instance.videoAction(1, currentMarker.name, 1, (int)vp.time, GameData.instance.sessionId + ""); //1 play - 2 pause
            }



        }


    }

    //chiamato quando il video della pubblicità è pronto per essere mandato in play
    //private void checkAdVideoPrepared(UnityEngine.Video.VideoPlayer vp)
    //{
    //    Destroy(transform.GetChild(4).gameObject);

    //    OfflineGameManager.instance.startToCountdownForBadConnection = false;
    //    OfflineGameManager.instance.connectionPopupActivator = false;

    //    OfflineGameManager.instance.resetBadConnectionTimer();

    //    vp.Play();
    //    Debug.Log("pubblicità " + player.time);
    //}

    //chiamato quando la pubblicità finisce
    //private void checkAdEnd(UnityEngine.Video.VideoPlayer vp)
    //{

    //    if (!string.IsNullOrEmpty(currentMarker.site))
    //    {
    //        OfflineGameManager.instance.siteButton.gameObject.SetActive(true);
    //    }

    //    else
    //    {
    //        OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
    //    }

    //    OfflineGameManager.instance.siteButton.gameObject.SetActive(true);

    //    //Gestisco il video
    //    vp.url = currentMarker.url;

    //    vp.Prepare();

    //    vp.prepareCompleted += checkVideoPrepared;

    //}

    #endregion

    #region ASYNC METHODS

    IEnumerator adRequest()
    {
        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(true);
        }

        else
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
        }



        //Far partire il video
        if (currentMarker.isYoutube)
        {

            _yp.gameObject.GetComponent<YoutubeVideoEvents>().OnVideoStarted.AddListener(() =>
            {

                Destroy(transform.GetChild(4).gameObject);

            });

            _yp.Play(currentMarker.url);
            Analytics.instance.videoAction(1, currentMarker.name, 1, (int)_yp.videoPlayer.time, GameData.instance.sessionId + ""); //1 play - 2 pause
        }

        else
        {
            //Gestisco il video
            
            player.url = currentMarker.url;
            player.SetDirectAudioMute(0, true);

            player.Prepare();
            Debug.Log("🚀 ~ file: TargetHandler.cs:851 ~ prepareCompleted");
            player.prepareCompleted += checkVideoPrepared;
            //ANDREA
            player.errorReceived += ErrorReceived;
            
        }

        yield return null;
        /*
        string requestData = GameData.instance.loggedUser._token + "/" + GameData.instance.selectedContentId + "?"+"marker="+currentMarker.name;

        UnityWebRequest www = UnityWebRequest.Get(APIs.TAKE_ADV + requestData);
        yield return www.SendWebRequest();


        if (www.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(www.error);
        }

        else
        {
            JSONObject response = (JSONObject)JSON.Parse(www.downloadHandler.text);


            if (string.IsNullOrEmpty(response["link"]))
            {
                //NO PUBBLICITÀ

                //OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);

                if (!string.IsNullOrEmpty(currentMarker.site))
                {
                    OfflineGameManager.instance.siteButton.gameObject.SetActive(true);
                }

                else
                {
                    OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
                }



                //Far partire il video
                if (currentMarker.isYoutube)
                {

                    _yp.gameObject.GetComponent<YoutubeVideoEvents>().OnVideoStarted.AddListener(() =>
                    {

                        Destroy(transform.GetChild(4).gameObject);

                    });

                    _yp.Play(currentMarker.url);
                    Analytics.instance.videoAction(1, currentMarker.name, 1, (int)_yp.videoPlayer.time, GameData.instance.sessionId + ""); //1 play - 2 pause
                }

                else
                {
                    //Gestisco il video
                    player.url = currentMarker.url;
                    player.SetDirectAudioMute(0, true);

                    player.Prepare();

                    player.prepareCompleted += checkVideoPrepared;
                }


            }

            else
            {
                ////Mostro la pubblicità
                ////loadingSpinner.gameObject.SetActive(true);

                ////disabilito i pulsanti di sito e fullscreen
                //OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                //OfflineGameManager.instance.siteButton.gameObject.SetActive(false);

                //player.url = response["link"];

                //player.Prepare();

                //player.prepareCompleted += checkAdVideoPrepared;

                //player.loopPointReached += checkAdEnd;

            }


        }
        */
    }


    #endregion


    #region EXTRA METHODS

    public void disableUI()
    {
        OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);

        OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
    }

    public void enableUI(bool is3D = false)
    {
        if (!is3D)
        {
            if (GameData.instance.webviewForVideo && currentMarker.isYoutube)
            {

                if (transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha == 1)
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                else
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);


            }

            else // is Mp4
            {
                if (currentMarker.isComboExperience)
                {
                    if (!isVideoBegin)
                        OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                    else
                        OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                }

                else
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
            }
        }


        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(true);
        }

        else
        {
            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
        }

    }

    public void setMarker(Marker marker, bool canSetSite = false)
    {
        currentMarker = marker;

        if (canSetSite)
        {

            enableUI(true);

            initSideBarButtons();
        }
    }

    public Marker getMarker()
    {
        return currentMarker;
    }

    #endregion


}
