﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using DG.Tweening;
using TMPro;

public class ScrollPanel : MonoBehaviour
{
    public Image[] status;
    public Sprite active;
    public Sprite disable;

    public GameObject backButton;
    public GameObject nextButton;
    public TextMeshProUGUI skip;

    public RectTransform container;

    private Vector2 position;
    public float percentTreshold = 0.2f;
    private int currentPage;

    // Start is called before the first frame update
    void Start()
    {
        currentPage = 1;
        skip.text = "SKIP";
        position = Vector2.zero;

        status[0].sprite = active;
        status[1].sprite = status[2].sprite = disable;
    }


    public void onBackPressed()
    {
        if (currentPage > 1)
        {

            currentPage--;
            position += new Vector2(2000, 0);
            container.DOAnchorPos(position, 0.25f);
            setActivePage(currentPage - 1);
            setActiveButton();
        }
    }

    public void onNextPressed()
    {
        if (currentPage < 3)
        {

            currentPage++;
            position -= new Vector2(2000, 0);
            container.DOAnchorPos(position, 0.25f);
            setActivePage(currentPage - 1);
            setActiveButton();

        }
    }

    private void setActivePage(int index)
    {
        status[0].sprite = status[1].sprite = status[2].sprite = disable;

        status[index].sprite = active;
    }

    private void setActiveButton()
    {
        if(currentPage == 1)
        {
            skip.text = "SKIP";
            backButton.SetActive(false);
        }
        else if(currentPage == 3)
        {
            skip.text = "DONE";
            nextButton.SetActive(false);
        }

        else
        {
            skip.text = "SKIP";
            backButton.SetActive(true);
            nextButton.SetActive(true);
        }


    }

    public void resetTutorial()
    {
        currentPage = 1;
        position = Vector2.zero;
        container.DOAnchorPos(position, 0f);
    }
}
