﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimpleJSON;

[System.Serializable]
public class SaveObject
{
    [SerializeField]
    private string id;
    [SerializeField]
    private List<DLC> dlcs;

    //Constructor
    public SaveObject()
    {
        dlcs = new List<DLC>();
        id = string.Empty;
    }

    public List<DLC> _dlcs
    {
        get { return dlcs; }
        set { dlcs = value; }
    }

    public string _id
    {
        get { return id; }
        set { id = value; }
    }
    

}
