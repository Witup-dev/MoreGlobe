using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BusinessCard
{
    [SerializeField] private string id;
    [SerializeField] private string first_line;
    [SerializeField] private string second_line;
    [SerializeField] private string image;
    [SerializeField] private string video_url;
    [SerializeField] private string website;
    [SerializeField] private string linkedin;
    [SerializeField] private string template;
    [SerializeField] private List<BusinessCardAction> actions;
    [SerializeField] private List<BusinessCardAction> functions;


    public string _id
    {
        get { return id; }
        set { id = value; }
    }

    public string _first_line
    {
        get { return first_line; }
        set { first_line = value; }
    }

    public string _second_line
    {
        get { return second_line; }
        set { second_line = value; }
    }

    public string _image
    {
        get { return image; }
        set { image = value; }
    }

    public string _video_url
    {
        get { return video_url; }
        set { video_url = value; }
    }

    public string _website
    {
        get { return website; }
        set { website = value; }
    }

    public string _linkedin
    {
        get { return linkedin; }
        set { linkedin = value; }
    }

    public string _template
    {
        get { return template; }
        set { template = value; }
    }

    public List<BusinessCardAction> _actions
    {
        get { return actions; }
        set { actions = value; }
    }

    public List<BusinessCardAction> _functions
    {
        get { return functions; }
        set { functions = value; }
    }

}

[System.Serializable]
public class BusinessCardAction
{
    [SerializeField] private string id;
    [SerializeField] private string id_business_card;
    [SerializeField] private string image;
    [SerializeField] private string action;
    [SerializeField] private string value;
    [SerializeField] private string text;
    [SerializeField] private string external;


    public string _id
    {
        get { return id; }
        set { id = value; }
    }

    public string _id_business_card
    {
        get { return id_business_card; }
        set { id_business_card = value; }
    }

    public string _image
    {
        get { return image; }
        set { image = value; }
    }

    public string _action
    {
        get { return action; }
        set { action = value; }
    }

    public string _value
    {
        get { return value; }
        set { this.value = value; }
    }

    public string _text
    {
        get { return text; }
        set { text = value; }
    }

    public string _external
    {
        get { return external; }
        set { external = value; }
    }
}


