using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SignInWithApple;
using UnityEngine.Networking;

public class AppleLogin : GeneralLogin
{

    //contiene componente SDK Apple (siwa)
    public SignInWithApple siwa;
    public override void init()
    {
        siwa = gameObject.AddComponent<SignInWithApple>();
    }

    public override void login()
    {
        siwa.Login(onAppleLogin);
    }

    public override void logout()
    {
        Debug.Log($"apple logout");
    }

    public override void destroy()
    {
        if(siwa != null)
            Destroy(siwa);

        Destroy(this);
    }

    #region HANDLER

    private void onAppleLogin(SignInWithApple.CallbackArgs args)
    {
        UserInfo userInfo = args.userInfo;
        Debug.Log(
            string.Format("Display Name: {0}\nEmail: {1}\nUser ID: {2}\nID Token: {3}", userInfo.displayName ?? "",
                userInfo.email ?? "", userInfo.userId ?? "", userInfo.idToken ?? ""));


        StartCoroutine(doMoreglobeAppleLogin(userInfo));
    }



    private void onAppleLoginError(SignInWithApple.CallbackArgs args)
    {
        PopupInfo popup = UIController.instance.CreateInfoPopup();
        popup.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupInfoJson[1]._title,
            GameData.instance.currentLanguage._popupInfoJson[1]._message,
            GameData.instance.currentLanguage._popupInfoJson[1]._buttonText,
            "error",
            () => {
                Destroy(popup.gameObject);
                Destroy(siwa);
                Destroy(GameData.instance.loginMode);
                GameData.instance.loginMode = null;
            });
    }

    #endregion


    private IEnumerator doMoreglobeAppleLogin(UserInfo userInfo)
    {
        WWWForm form = new WWWForm();
        form.AddField("appleid", userInfo.userId);
        form.AddField("email", userInfo.email);
        form.AddField("name", userInfo.displayName);

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingIn);

        using (UnityWebRequest www = UnityWebRequest.Post(APIs.LOGIN_APPLE_SERVICE, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");

            }

            else
            {


                LoginResponse response = JsonUtility.FromJson<LoginResponse>(www.downloadHandler.text);

                Debug.Log("ricevuta response Apple: " + response);

                if (response._success)
                {
                    waiting.destroy();
                    GameData.instance.loggedUser._token = response._token;
                    GameData.instance.loggedUser._username = userInfo.displayName;
                    GameData.instance.loggedUser._email = userInfo.email;
                    GameData.instance.loggedUser._fbID = string.Empty;
                    GameData.instance.loggedUser._aID = userInfo.userId;
                    GameData.instance.loggedUser._gID = string.Empty;
                    GameData.instance.loggedUser._loginType = "a";

                    PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
                    PlayerPrefs.Save();

                    Debug.Log("Utente Apple salvato: " + PlayerPrefs.HasKey("loggedUser"));

                    goNext();

                }
                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }
        }

        yield return null;
    }


}
