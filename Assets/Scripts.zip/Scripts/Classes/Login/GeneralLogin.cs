using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.Android;

public abstract class GeneralLogin : MonoBehaviour
{
    public abstract void init();
    public abstract void login();
    public abstract void logout();
    public abstract void destroy();

    protected void goNext()
    {

        StartCoroutine(Utilities.handleOnesignalPlayerID(false));

        if (GameData.instance.gameObject.GetComponent<Analytics>() == null)
        {
            GameData.instance.gameObject.AddComponent<Analytics>();
        }

#if UNITY_IOS

        GameData.instance.gameObject.AddComponent<AppTrackingTransparencyBehaviour>();

#elif UNITY_ANDROID

        SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
#endif
    }

}
