/* using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Facebook.Unity;
using UnityEngine.Networking;

public class FacebookLogin : GeneralLogin
{

    private WaitingPopup FbWaiting;

    public override void init()
    {
        if (!FB.IsInitialized)
        {
            // Initialize the Facebook SDK
            FB.Init(onInitCallBack, onHideUnity);
        }
        else
        {

            // Already initialized, signal an app activation App Event
            FB.ActivateApp();
            if (!FB.IsLoggedIn)
            {
                Debug.Log($"Utente non loggato con facebook");
                if (GameData.instance.loggedUser._loginType.Equals("f"))
                {
                    GameData.instance.loggedUser = new User();
                }

                //using canLoadOn as passtrough. If true means that i am calling this in loginManager
                if (GameData.instance.canLoadOn)
                    login();
            }

            else
            {
                Debug.Log($"Utente  loggato con facebook");
                GameData.instance.canLoadOn = true;
            }
        }
    }

    public override void login()
    {
        FB.LogInWithReadPermissions(new List<string>() { "public_profile"}, onFacebookLoginResult);
        Debug.Log("login con facebook");
    }

    public override void logout()
    {
        Debug.Log("logout con facebook");
        FB.LogOut();
    }

    public override void destroy()
    {
        Destroy(this);
    }

    #region HANDLER
    private void onInitCallBack()
    {

        if (FB.IsInitialized)
        {
            if (!FB.IsLoggedIn)
            {
                Debug.Log($"Utente non loggato con facebook");
                if (GameData.instance.loggedUser._loginType.Equals("f"))
                {
                    GameData.instance.loggedUser = new User();
                }

                //using canLoadOn as passtrough. If true means that i am calling this in loginManager
                if (GameData.instance.canLoadOn)
                    login();
            }

            else
            {
                Debug.Log($"Utente  loggato con facebook");
                GameData.instance.canLoadOn = true;
            }

            
        }

        else
        {
            FB.Init(onInitCallBack, onHideUnity);
        }
    }

    private void onHideUnity(bool isGameShown)
    {
        if (!isGameShown)
        {
            // Pause the game - we will need to hide
            Time.timeScale = 0;
        }
        else
        {
            // Resume the game - we're getting focus again
            Time.timeScale = 1;
        }
    }

    private void onFacebookLoginResult(ILoginResult result)
    {
        if (FB.IsLoggedIn)
        {
            Debug.Log("login effettuato");
            handleFacebookLogin();
        }
        else
        {
            GameData.instance.loginMode = null;
            destroy();
            Debug.Log("User cancel login");
        }
    }

    private void handleFacebookLogin()
    {
        FbWaiting = UIController.instance.CreateWaitingPopup();
        FbWaiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingIn);
        FB.API("/me?fields=id,name,email", HttpMethod.GET, GetFacebookInfo, new Dictionary<string, string>() { });
    }

    private void GetFacebookInfo(IResult result)
    {

        if (result.Error == null)
        {
            var accessToken = AccessToken.CurrentAccessToken;

            Debug.Log(result.ResultDictionary["id"].ToString());
            Debug.Log(result.ResultDictionary["name"].ToString());
            Debug.Log(result.ResultDictionary["email"].ToString());

            GameData.instance.loggedUser._email = result.ResultDictionary["email"].ToString();
            GameData.instance.loggedUser._username = result.ResultDictionary["name"].ToString();
            GameData.instance.loggedUser._fbID = accessToken.UserId;
            GameData.instance.loggedUser._aID = string.Empty;
            GameData.instance.loggedUser._gID = string.Empty;
            

            GameData.instance.loggedUser._loginType = "f";

            PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
            PlayerPrefs.Save();

            StartCoroutine(doMoreglobeFacebookLogin(FbWaiting));

        }
        else
        {
            FbWaiting.destroy();
        }
    }

    #endregion


    private IEnumerator doMoreglobeFacebookLogin(WaitingPopup waiting)
    {

        WWWForm form = new WWWForm();
        form.AddField("fbid", GameData.instance.loggedUser._fbID);
        form.AddField("email", GameData.instance.loggedUser._email);
        form.AddField("name", GameData.instance.loggedUser._username);

        using (UnityWebRequest www = UnityWebRequest.Post(APIs.LOGIN_FB_SERVICE, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");

            }

            else
            {
                LoginResponse response = JsonUtility.FromJson<LoginResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    waiting.destroy();
                    GameData.instance.loggedUser._token = response._token;

                    PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
                    PlayerPrefs.Save();

                    Debug.Log("Utente facebook salvato: " + PlayerPrefs.HasKey("loggedUser"));

                    goNext();

                }
                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }
        }
    }

    
}
 */