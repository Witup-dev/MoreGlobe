﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class DLC {

    [SerializeField]
    private string id;
    [SerializeField]
    private double version;
    [SerializeField]
    private string downloadDate;

    public DLC(string id)
    {
        this.id = id;
        version = 0.0f;
    }


    public string _id
    {
        get { return id; }
        set { id = value; }
    }

    public double _version
    {
        get { return version; }
        set { version = value; }
    }

    public string _downloadDate
    {
        get { return downloadDate; }
        set { downloadDate = value; }
    }



}



[System.Serializable]
public class AvailableContents
{
    [SerializeField]
    private List<DLC> dlcs;

    public AvailableContents()
    {
        dlcs = new List<DLC>();
    }

    public List<DLC> _dlcs
    {
        get { return dlcs; }
        set { dlcs = value; }
    }


    public bool containsDlc(string id)
    {
        foreach(var dlc in dlcs)
        {
            if (dlc._id.Equals(id))
                return true;
        }

       return false;
    }

    public void removeDlc(string id)
    {
        int index = -1;
        foreach(var dlc in dlcs)
        {
            if (dlc._id.Equals(id))
            {
                index = dlcs.IndexOf(dlc);
                break;
            }
                
        }

        if (index >= 0)
            dlcs.RemoveAt(index);
    }

    public void updateDlc(string id, double version,string date)
    {
        int index = -1;
        foreach (var dlc in dlcs)
        {
            if (dlc._id.Equals(id))
            {
                index = dlcs.IndexOf(dlc);
                break;
            }

        }

        if (index >= 0)
        {
            dlcs[index]._version = version;
            dlcs[index]._downloadDate = date;
        }

    }

    public DLC getDLC(string id)
    {
        foreach (var dlc in dlcs)
        {
            if (dlc._id.Equals(id))
                return dlc;
        }

        return null;
    }

}
