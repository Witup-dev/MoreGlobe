﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class AppSaveObject
{
    [SerializeField]
    private List<Content> availableContents;


    public AppSaveObject()
    {
        availableContents = new List<Content>();
    }


    public List<Content> _availableContents
    {
        get { return availableContents; }
        set { availableContents = value; }
    }

}
