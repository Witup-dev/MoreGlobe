[System.Serializable]
    public class DataRequest
    {
        public string id;
        public string uid;
        public string id_experience;
        public string name;
        public string type;
        public float x;
        public float y;
        public float z;
        public float width;
        public float height;
        public float deep;
        public float rotation_x;
        public float rotation_y;
        public float rotation_z;
        public float scale_x;
        public float scale_y;
        public string title;
        public string url;
        public string source;
        public bool autoplay;
        public string youtube_url;
        public ExtraModel[] extra;
        public ActionModel operation;
    }