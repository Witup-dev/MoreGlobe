﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MarkerModel
{
    [SerializeField]
    private string id;

    [SerializeField]
    private string id_content;

    [SerializeField]
    private string name;

    [SerializeField]
    private string tags;

    [SerializeField]
    private string src;

    [SerializeField]
    private string gltf;

    [SerializeField]
    private string image;

    [SerializeField]
    private string inserted_at;



    public string _id
    {
        get { return id; }
        set { id = value; }
    }

    public string _id_content
    {
        get { return id_content; }
        set { id_content = value; }
    }

    public string _name
    {
        get { return name; }
        set { name = value; }
    }

    public string _tags
    {
        get { return tags; }
        set { tags = value; }
    }

    public string _src
    {
        get { return src; }
        set { src = value; }
    }

    public string _gltf
    {
        get { return gltf; }
        set { gltf = value; }
    }

    public string _image
    {
        get { return image; }
        set { image = value; }
    }

    public string _inserted_at
    {
        get { return inserted_at; }
        set { inserted_at = value; }
    }



}
