﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[System.Serializable]
public class User
{


 [Header("Dati principali")]

// Token di autenticazione associato all’utente
    [SerializeField]
    private string token;

//' Email dell’utente
    [SerializeField]
    private string email;

//' Username visualizzato
    [SerializeField]
    private string username;

    [SerializeField]
   // ' Tipo di login ("m" = Moreglobe, "g" = Google, "f" = Facebook, "a" = Apple)
    private string loginType;

     
    [SerializeField]
    //' Lista degli ID dei contenuti associati all’utente
    private List<string> associatedContent;




 [Header("ID provider esterni")]

//' ID Facebook collegato all’utente (se presente)
    private string fbID;

//' ID Apple collegato all’utente (se presente)
    private string aID;

//' ID Google collegato all’utente (se presente)
    private string gID;

   


//  ' Costruttore di default:
//  '  - inizializza token e loginType a stringa vuota
 // '  - inizializza la lista dei contenuti associati
    public User()
    {
        token = string.Empty;
        loginType = string.Empty;
        associatedContent = new List<string>();
    }

    public string _token
    {
        get { return token; }
        set { token = value; }
    }

    public string _email
    {
        get { return email; }
        set { email = value; }
    }

    public string _username
    {
        get { return username; }
        set { username = value; }
    }

    public string _fbID
    {
        get { return fbID; }
        set { fbID = value; }
    }

    public string _aID
    {
        get { return aID; }
        set { aID = value; }
    }

    public string _gID
    {
        get { return gID; }
        set { gID = value; }
    }

    public string _loginType
    {
        get { return loginType; }
        set { loginType = value; }
    }


    public List<string> _associatedContent
    {
        get { return associatedContent; }
        set { associatedContent = value; }
    }

    //public DateTime _tokenExpireDate
    //{
    //    get { return tokenExpireDate; }
    //    set {  tokenExpireDate = value;}
    //}






}
