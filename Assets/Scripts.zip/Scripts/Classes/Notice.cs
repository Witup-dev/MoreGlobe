﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Notice
{
    [SerializeField]
    private string id;

    [SerializeField]
    private string id_user;

    [SerializeField]
    private string title;

    [SerializeField]
    private string message;

    [SerializeField]
    private string icon;

    [SerializeField]
    private string action;

    [SerializeField]
    private string action_value;

    [SerializeField]
    private string firstname;

    [SerializeField]
    private string lastname;

    [SerializeField]
    private string id_read_notification;

    [SerializeField]
    private string inserted_at;//data di inserimento

    public string _id
    {
        get { return id; }
        set { id = value; }
    }

    public string _id_user
    {
        get { return id_user; }
        set { id_user = value; }
    }

    public string _title
    {
        get { return title; }
        set { title = value; }
    }

    public string _message
    {
        get { return message; }
        set { message = value; }
    }

    public string _icon
    {
        get { return icon; }
        set { icon = value; }
    }

    public string _action
    {
        get { return action; }
        set { action = value; }
    }

    public string _action_value
    {
        get { return action_value; }
        set { action_value = value; }
    }

    public string _firstname
    {
        get { return firstname; }
        set { firstname = value; }
    }

    public string _lastname
    {
        get { return lastname; }
        set { lastname = value; }
    }

    public string _id_read_notification
    {
        get { return id_read_notification; }
        set { id_read_notification = value; }
    }

    public string _inserted_at
    {
        get { return inserted_at; }
        set { inserted_at = value; }
    }
}
