﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Marker
{

[Header("Campi principali")]

// ' URL del contenuto principale (es. video)
    public string url;

    // ' URL di un sito collegato al marker
    public string site;

     //' Nome del marker (identificativo logico)
    public string name;

    //' Orientamento del marker (es. "L" = landscape)
    public string orientation;

     //' Nome del modello 3D associato (vuoto se non usato)
    public string is3D; 

     //' Larghezza fisica del marker (unità AR)
    public float width;

    //' Altezza fisica del marker (unità AR)
    public float height;

    //' True se il contenuto è un video YouTube
    public bool isYoutube;

    //' Nome/percorso della maschera grafica associata
    public string mask;

     ///' ID del contenuto a cui il marker è collegato
    public string contentID;

    //' True se il contenuto è una pagina web
    public bool isWebPage;

    // ' Secondo di inizio del video/esperienza
    public int start;

    //' Secondo di fine del video/esperienza (-1 = fino alla fine)
    public int end;

    //' True se il marker fa parte di una “combo experience”
    public bool isComboExperience;

    ///' True se il contenuto è pensato per una modalità “TV”
    public bool tvMode;

     //' Nome leggibile del marker (può differire da name)
    public string markerName;

    //' Tipo di sorgente (""=mp4 default, "youtube", "facebook", …)
    public string sourceType;

    //' Tipo di esperienza (video, 3D, ecc. – dipende dall’app)
    public string type;

     //' True se l’audio del contenuto è muto
    public bool mute;

    //' ID dell’esperienza AR associata
    public int id_experience;

    public Marker()
    {

    }

    public Marker(string urlVideo, string urlSite, string name, string orientation, string is3D, float width, float height, bool isYoutube, string mask, string contentID, bool isWebPage,
        int start, int end, bool isComboExperience, bool tvMode,string markerName, string sourceType, string type, bool mute, int id_experience)
    {

        this.url = urlVideo;
        this.site = urlSite;
        this.name = name;
        this.orientation = orientation;
        this.is3D = is3D;
        this.width = width;
        this.height = height;
        this.isYoutube = isYoutube;
        this.mask = mask;
        this.contentID = contentID;
        this.isWebPage = isWebPage;
        this.start = start;
        this.end = end;
        this.isComboExperience = isComboExperience;
        this.tvMode = tvMode;
        this.markerName = markerName;
        this.sourceType = sourceType; // "" = default mp4, youtube, facebook
        this.type = type;
        this.mute = mute;
        this.id_experience = id_experience;

    }

    public Marker(string name)
    {
        this.name = name;
    }

    
    //' Restituisce un marker di default con valori preimpostati
    public static Marker getDefaultMarker()
    {
        Marker m = new Marker();

        m.url = string.Empty;
        m.site = string.Empty;
        m.name = "default";
        m.orientation = "L";
        m.is3D = string.Empty;
        m.width = 1f;
        m.height = 1f;
        m.isYoutube = false;
        m.mask = string.Empty;
        m.contentID = string.Empty;
        m.isWebPage = false;
        m.start = 0;
        m.end = -1;
        m.isComboExperience = false;
        m.tvMode = false;
        m.markerName = string.Empty;
        m.sourceType = string.Empty;
        m.type = string.Empty;
        m.mute = false;


        return m;
    }

}
