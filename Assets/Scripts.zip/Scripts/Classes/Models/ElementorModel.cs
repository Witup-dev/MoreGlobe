
using UnityEngine;
using UnityEngine.UI;
using easyar;

[CreateAssetMenu(fileName = "ElementorModel", menuName = "ScriptableObjects/ElementorModel", order = 0)]
public class ElementorModel : ScriptableObject
{
    private Transform canvasGB;
    private GameObject gb;

    [Header("Button Elements")]
    [SerializeField] GameObject buttonPrefab;

    [Header("Video Elements")]
    [SerializeField] GameObject videoPanelPrefab;

    [Header("Text Elements")]
    [SerializeField] GameObject textPrefab;

    [Header("Image Elements")]
    [SerializeField] GameObject imagePrefab;

    [Header("Canvas Element")]
    [SerializeField] GameObject canvas;

    public Sprite loading;
    public Sprite error;

    private GameObject canvasInstantiate;

    public void EntityInstantiate(DataRequest[] response, ImageTargetController parentController = null, bool isNfc = false)
    {
        if (parentController != null)
            canvasInstantiate = Instantiate(canvas, parent: parentController.transform);
        else
            canvasInstantiate = Instantiate(canvas);


        if (isNfc)
            OfflineGameManager.instance.MarkerToSpatial(false, true, canvasInstantiate.transform);

        for (int i = 0; i < response.Length; i++)
        {
            switch (response[i].type)
            {
                case "button":
                    gb = Instantiate(buttonPrefab, parent: canvasInstantiate.transform);
                    gb.GetComponent<ButtonEntity>().Constructor(response[i]);
                    break;

                case "video":
                    gb = Instantiate(videoPanelPrefab, parent: canvasInstantiate.transform);
                    gb.GetComponent<VideoEntity>().Constructor(response[i], parentController);
                    break;

                case "text":
                    gb = Instantiate(textPrefab, parent: canvasInstantiate.transform);
                    gb.GetComponent<TextEntity>().Constructor(response[i]);
                    break;
                case "3d":
                    OfflineGameManager.instance.targetManagerInstance.Get3DModelElement(canvasInstantiate.transform, response[i]);
                    break;
                case "image":
                    gb = Instantiate(imagePrefab, parent: canvasInstantiate.transform);
                    gb.GetComponent<ImageEntity>().Constructor(response[i]);
                    break;
            }
        }

        
    }

    public void SetCanvasPosition(Transform newPos)
    {
        canvasInstantiate.transform.position = new Vector3(newPos.position.x, newPos.position.y, newPos.position.z);
    }
}