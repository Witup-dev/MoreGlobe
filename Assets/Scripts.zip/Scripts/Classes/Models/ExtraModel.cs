[System.Serializable]
public class ExtraModel
{

    //' Id dell’oggetto extra (se serve a identificarlo lato backend)
    public string id;
    //' Chiave del parametro extra (es. "color", "link", "tag", ecc.)
    public string key_;
    //' Valore associato alla chiave (testo generico)
    public string value_;
}