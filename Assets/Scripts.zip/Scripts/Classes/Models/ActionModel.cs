[System.Serializable]
public class ActionModel
{
    //' Identificativo univoco dell’azione
    public string id;
    //' Id dell’elemento di esperienza a cui è legata l’azione
    public string id_experience_item;
    //' Tipo di azione (es. "open_url", "play_video", ecc.)
    public string type;
    //' Dettaglio/parametro dell’azione (es. URL, comando, ecc.)
    public string action;
}