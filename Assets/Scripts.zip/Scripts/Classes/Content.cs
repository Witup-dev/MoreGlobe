﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimpleJSON;

[System.Serializable]
public class Content
{
    [SerializeField]
    private string id;

    [SerializeField]
    private string contentName;

    [SerializeField]
    private double versionThumbnail;

    [SerializeField]
    private double version;

    [SerializeField]
    private string category;

    [SerializeField]
    private string description;

    [SerializeField]
    private string longDescription;

    [SerializeField]
    private string downloadLink;//zip

    [SerializeField]
    private string thumbnailLink;

    [SerializeField]
    private string thumbnailLibraryLink;

    [SerializeField]
    private string thumbnailDescription;

    [SerializeField]
    private string website;

    [SerializeField]
    private string extra;

    [SerializeField]
    private string websiteShop;

    [SerializeField]
    private bool isOnlyCloud;

    [SerializeField]
    private bool expired;

    [SerializeField]
    private bool connect;

    [SerializeField]
    private string inserted_at;//data di inserimento

    [SerializeField]
    private string updated_at;//data aggiornamento

    [SerializeField]
    private string is_brand;

    [SerializeField]
    private string tabbar_logo;

    [SerializeField]
    private string splash_logo;

    [SerializeField]
    private string custom_page;



    public Content()
    {
        version = 0.0f;
    }


    public bool _isBrand
    {
        get { return is_brand.Equals("1") ? true : false; }
    }

    public string _tabbar_logo
    {
        get { return tabbar_logo; }
        set { tabbar_logo = value; }
    }

    public string _splash_logo
    {
        get { return splash_logo; }
        set { splash_logo = value; }
    }

    public string _custom_page
    {
        get { return custom_page; }
        set { custom_page = value; }
    }

    public string _id
    {
        get { return id; }
        set { id = value; }
    }

    public bool _connect
    {
        get { return connect; }
        set { connect = value; }
    }

    public string _contentName
    {
        get { return contentName; }
        set { contentName = value; }
    }

    public double _version
    {
        get { return version; }
        set { version = value; }
    }

    public double _versionThumbnail
    {
        get { return versionThumbnail; }
        set { versionThumbnail = value; }
    }

    public string _category
    {
        get { return category; }
        set { category = value; }
    }

    public string _description
    {
        get { return description; }
        set { description = value; }
    }

    public string _longDescription
    {
        get { return longDescription; }
        set { longDescription = value; }
    }

    public string _downloadLink
    {
        get { return downloadLink; }
        set { downloadLink = value; }
    }

    public string _thumbnailLink
    {
        get { return thumbnailLink; }
        set { thumbnailLink = value; }
    }

    public string _thumbnailLibraryLink
    {
        get { return thumbnailLibraryLink; }
        set { thumbnailLibraryLink = value; }
    }

    public string _thumbnailDescription
    {
        get { return thumbnailDescription; }
        set { thumbnailDescription = value; }
    }

    public string _website
    {
        get { return website; }
        set { website = value; }
    }

    public string _extra
    {
        get { return extra; }
        set { extra = value; }
    }

    public string _websiteShop
    {
        get { return websiteShop; }
        set { websiteShop = value; }
    }

    public bool _isOnlyCloud
    {
        get { return isOnlyCloud; }
        set { isOnlyCloud = value; }
    }

    public bool _expired
    {
        get { return expired; }
        set { expired = value; }
    }

    public string _inserted_at
    {
        get { return inserted_at; }
        set { inserted_at = value; }
    }

    public string _updated_at
    {
        get { return updated_at; }
        set { updated_at = value; }
    }

}

[System.Serializable]
public class CustomizationItem
{
    [SerializeField] private string id;
    [SerializeField] private string footerImageLink;
    [SerializeField] private string splashImageLink;
    [SerializeField] private string customPageLink;

    public CustomizationItem()
    {
        id = string.Empty;
        footerImageLink = string.Empty;
        splashImageLink = string.Empty;
        customPageLink = string.Empty;
    }

    public string _id
    {
        get { return id; }
        set { id = value; }
    }
    
    public string _footerImageLink
    {
        get { return footerImageLink; }
        set { footerImageLink = value; }
    }
    
    public string _splashImageLink
    {
        get { return splashImageLink; }
        set { splashImageLink = value; }
    }
    
    public string _customPageLink
    {
        get { return customPageLink; }
        set { customPageLink = value; }
        
    }

}