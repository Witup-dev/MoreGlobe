﻿
//================================================================================================================================
//
//  Copyright (c) 2015-2021 VisionStar Information Technology (Shanghai) Co., Ltd. All Rights Reserved.
//  EasyAR is the registered trademark or trademark of VisionStar Information Technology (Shanghai) Co., Ltd in China
//  and other countries for the augmented reality technology developed by VisionStar Information Technology (Shanghai) Co., Ltd.
//
//================================================================================================================================


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using easyar;
using System;
using System.IO;
using SimpleJSON;
using System.Text;

namespace ImageTracking_CloudRecognition
{
    public class RecognitionHandler : MonoBehaviour
    {

        //My var
        public GameObject imageTargetPrefab;
        private Marker marker;
        public ARSession Session;
        private CloudRecognizerFrameFilter cloudRecognizer;
        private ImageTrackerFrameFilter tracker;
        private List<GameObject> targetObjs = new List<GameObject>();
        private List<string> loadedCloudTargetUids = new List<string>();
        private ResolveInfo resolveInfo;
        private float autoResolveRate = 1f;
        private bool isTracking;
        private bool resolveOn;

        private void Awake()
        {
            tracker = Session.GetComponentInChildren<ImageTrackerFrameFilter>();
            cloudRecognizer = Session.GetComponentInChildren<CloudRecognizerFrameFilter>();

        }

        private void Start()
        {
            Debug.Log($"🚀 ~ file: RecognitionHandler.cs:49 ~ StartAutoResolve");
            StartAutoResolve(autoResolveRate);
        }

        private void Update()
        {

            AutoResolve();
        }

        private void OnDestroy()
        {
            foreach (var obj in targetObjs)
            {
                Destroy(obj);
            }
        }

        public void ClearAll()
        {

            foreach (var obj in targetObjs)
            {
                Destroy(obj);
            }
            targetObjs.Clear();
            loadedCloudTargetUids.Clear();
        }

        public void StartAutoResolve(float resolveRate)
        {
            if (Session != null && resolveInfo == null)
            {
                autoResolveRate = resolveRate;
                resolveInfo = new ResolveInfo();
                resolveOn = true;
            }
        }

        public void StopResolve()
        {
            if (Session != null)
            {
                resolveInfo = null;
                resolveOn = false;
            }
        }
        
     private void AutoResolve()
{
    var time = Time.time;
    if (!resolveOn || isTracking || resolveInfo.Running || time - resolveInfo.ResolveTime < autoResolveRate)
    {
        return;
    }

    resolveInfo.Running = true;
    resolveInfo.ResolveTime = time;

   
    cloudRecognizer.Resolve(
        default,  
        (response) =>
        {
            if (resolveInfo == null)
            {
                return;
            }

            resolveInfo.Running = false;
            resolveInfo.Index++;

           
            resolveInfo.CostTime = Time.time - resolveInfo.ResolveTime;

            
            resolveInfo.CloudStatus = response.Status;
            resolveInfo.UnknownErrorMessage = response.ErrorMessage;
            resolveInfo.TargetName = "-";

    
            if (response.Status != CloudRecognizationStatus.FoundTarget)
            {
                if (response.ErrorMessage.OnSome)
                {
                    Debug.LogWarning(
                        $"[RecognitionHandler] Cloud status: {response.Status}, error: {response.ErrorMessage.Value}");
                }
                else
                {
                    Debug.Log($"[RecognitionHandler] Cloud status: {response.Status}");
                }
                return;
            }

           
            var targetOpt = response.Target;
            if (targetOpt.OnSome)
            {
                //Debug.Log($"🚀 ~  file: RecognitionHandler.cs:141 ~ TargetName: {target.Value.name()}");
                //Debug.Log($"🚀 ~  file: RecognitionHandler.cs:141 ~ TargetId: {target.Value.uid()}");
                using (var targetValue = targetOpt.Value)
                {
                

                    resolveInfo.TargetName = targetValue.name();

                    if (!loadedCloudTargetUids.Contains(targetValue.uid()))
                    {
                        LoadCloudTarget(targetValue.Clone());
                    }
                }
            }
        });
}



        private void LoadCloudTarget(ImageTarget target)
        {
            
            Debug.Log("🚀 ~ file: RecognitionHandler.cs:151 ~ LoadCloudTarget:");
            if (GameManager.instance.isInFullScreen())
            {
                GameManager.instance.exitFullScreen();
            }
            ClearAll();
            Debug.Log("🚀 ~ file: RecognitionHandler.cs:163 ~ ClearAll:");
            


            var uid = target.uid();
            loadedCloudTargetUids.Add(uid);
            var go = new GameObject(uid);
            targetObjs.Add(go);
            var targetController = go.AddComponent<ImageTargetController>();
            
          

             //EasyAR 4.4
            //targetController.SourceType = ImageTargetController.DataSource.Target;
            //targetController.TargetSource = target;
            //targetController.HorizontalFlip = false;

            //EasyAR 4000
            targetController.Source = new ImageTargetController.TargetDataFileSourceData();
            targetController.Source = new ImageTargetController.ImageFileSourceData
            {
                Name = target.name(),
            };

            LoadTargetIntoTracker(targetController);

           //EasyAR 4000
            targetController.TargetDataLoad += (result) =>
            {
                 Debug.Log($"🚀 ~ file: RecognitionHandler.cs:174 ~ result: {result}");
                if (!result)
                {
                    Debug.LogErrorFormat("target {0} load failed", uid);
                    return;
                }
                CreateVideoPlayer(targetController);
            };

        }


        private void LoadTargetIntoTracker(ImageTargetController controller)
        {
            controller.Tracker = tracker;
            Debug.Log($"🚀 ~ file: RecognitionHandler.cs:198 ~ tracker: {tracker}");
            Debug.Log($"🚀 ~ file: RecognitionHandler.cs:198 ~ controller: {controller}");

            
            controller.TargetFound += () =>
            {
                Debug.Log($"🚀 ~ file: RecognitionHandler.cs:202 ~ TargetFound: {controller}");
                if (!PlayerPrefs.HasKey("framingTutorial"))
                {
                    PlayerPrefs.SetInt("framingTutorial", 1);
                    PlayerPrefs.Save();
                }

                isTracking = true;
                GameManager.instance.isFrameSomething = true;
               
                Debug.Log($"🚀 ~ file: RecognitionHandler.cs:209 ~ aspectRatio(): {controller.Target.aspectRatio()}");
                GameManager.instance.playAndAppear(controller.Target.aspectRatio());
                GameManager.instance.setFocus(1);
            };
            controller.TargetLost += () =>
            {
               
                Debug.Log($"🚀 ~ file: RecognitionHandler.cs:217 ~ TargetLost: {controller}");
                isTracking = false;
                GameManager.instance.isFrameSomething = false;
                GameManager.instance.setFullAndSite(false);
                GameManager.instance.handleModelAudio(false);
                GameManager.instance.pauseVideo();
                GameManager.instance.setFocus(0);
                GameManager.instance.destroyChoicePanel();
            };
        }

        private void CreateVideoPlayer(ImageTargetController controller)
        {
            string metadata = controller.Target.meta();
            byte[] mbyte = System.Convert.FromBase64String(metadata);
            string decodedMeta = Encoding.UTF8.GetString(mbyte);
            
            Debug.Log($"🚀 ~ file: RecognitionHandler.cs:221 ~ id: {controller.Target.uid()} - metadati: {decodedMeta}");

            JSONObject obj = (JSONObject)JSON.Parse(decodedMeta);

            marker = JsonUtility.FromJson<Marker>(decodedMeta);


            var prefab = Instantiate(imageTargetPrefab) as GameObject;
            prefab.transform.parent = controller.transform;
            prefab.transform.localPosition = new Vector3(0, 0, 0);
            prefab.transform.localScale = new Vector3(1, 1, 1);
            Destroy(prefab.transform.GetChild(4).gameObject);


            if (GameManager.instance.getMarker() != null)
            {
                Debug.Log(GameManager.instance.getMarker().name + " - " + marker.name);

                if (GameManager.instance.getMarker().name != marker.name)
                {
                    Debug.Log("Marker diversi");
                    Analytics.instance.recognize(marker.name, GameData.instance.sessionId + "");
                    GameManager.instance.setCurrentMarker(controller.gameObject, marker);
                }
                else
                {
                    Debug.Log("Marker uguali");
                }
            }

            else
            {
                Debug.Log("Prima istanza");
                GameManager.instance.setCurrentMarker(controller.gameObject, marker);
            }
        }

        private class ResolveInfo
        {
            public int Index = 0;
            public bool Running = false;
            public float ResolveTime = 0;
            public float CostTime = 0;
            public string TargetName = "-";
            public Optional<string> UnknownErrorMessage;
            public CloudRecognizationStatus CloudStatus = CloudRecognizationStatus.UnknownError;
        }
    }
}
