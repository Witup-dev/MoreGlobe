﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using System.Linq;
using System;
using ICSharpCode.SharpZipLib.Zip;

public static class DownloadManager
{

    #region Download immagini

    public static IEnumerator downloadImage(Content c)
    {
        using (var www = UnityWebRequestTexture.GetTexture(c._thumbnailLink))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                if (www.isDone)
                {
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    File.WriteAllBytes(Path.Combine(SaveLoadManager.THUMBNAILPATH, c._id + ".png"), x.EncodeToPNG());
                }
            }
        }

        //download lib thumbnail
        if (!string.IsNullOrEmpty(c._thumbnailLibraryLink))
        {
            using (var www = UnityWebRequestTexture.GetTexture(c._thumbnailLibraryLink))
            {
                yield return www.SendWebRequest();

                if (www.result != UnityWebRequest.Result.Success)
                {
                    Debug.Log(www.error);
                }
                else
                {
                    if (www.isDone)
                    {
                        Texture2D x = DownloadHandlerTexture.GetContent(www);
                        File.WriteAllBytes(Path.Combine(SaveLoadManager.THUMBNAILPATH, c._id + "_lib.png"), x.EncodeToPNG());
                    }
                }
            }
        }

        if (!string.IsNullOrEmpty(c._thumbnailDescription))
        {
            using (var www = UnityWebRequestTexture.GetTexture(c._thumbnailDescription))
            {
                yield return www.SendWebRequest();

                if (www.result != UnityWebRequest.Result.Success)
                {
                    Debug.Log(www.error);
                }
                else
                {
                    if (www.isDone)
                    {
                        Texture2D x = DownloadHandlerTexture.GetContent(www);
                        File.WriteAllBytes(Path.Combine(SaveLoadManager.THUMBNAILPATH, c._id + "_proj.png"), x.EncodeToPNG());
                    }
                }
            }
        }


        yield return null;
    }

        public static IEnumerator updateDLC(Content c, DownloadPopup downPopup, string date)
    { 
         
        string requestData = $"{GameData.instance.loggedUser._token}/check-marker-update?id_content={c._id}&date={date}";

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.UPDATE_CONTENT + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.LogError(www.error);
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }


            else
            {
                ContentUpdateResponse response = JsonUtility.FromJson<ContentUpdateResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    string dlcPath = Path.Combine(SaveLoadManager.DLCPATH, c._id);

                    if (Directory.Exists(dlcPath))
                    {

                        downPopup.title.text = GameData.instance.currentLanguage._downloading;

                        string path = Path.Combine(dlcPath, "marker");

                        DirectoryInfo dir = new DirectoryInfo(path);

                        Dictionary<string, string> markerIDs = dir.GetFiles().ToDictionary(x => x.Name.Split('.')[0], x => x.FullName);

                        List<UpdateContent> contentToUpdate = response._data;
                        int index = 0;

                        foreach (var content in contentToUpdate)
                        {
                            index++;
                            Debug.Log($"contentToUpdate {content._id} - {content._action} - {content._link}");

                            if (content._action.Equals("create"))
                            {
                                yield return downloadImageInPath(content._id, path, content._link);
                            }

                            else if (content._action.Equals("update"))
                            {
                                if (markerIDs.ContainsKey(content._id))
                                {
                                    if (File.Exists(markerIDs[content._id]))
                                    {
                                        File.Delete(markerIDs[content._id]);

                                    }
                                }

                                yield return downloadImageInPath(content._id, path, content._link);
                            }

                            else if (content._action.Equals("delete"))
                            {
                                if (markerIDs.ContainsKey(content._id))
                                {
                                    if (File.Exists(markerIDs[content._id]))
                                    {
                                        File.Delete(markerIDs[content._id]);

                                    }
                                }
                            }

                            else
                            {
                                Debug.Log($"Azione non consentita");
                            }

                            downPopup.setValue((float)Math.Round((((float)index / (float)contentToUpdate.Count)), 2) * 100);
                            yield return new WaitForSeconds(0.1f);

                        }

                        downPopup.destroy();

                    }

                }

                else
                {
                    downPopup.destroy();
                }

            }

        }

        yield return null;
    }

#endregion
#region Download pacchetti DLC 


    public static IEnumerator downloadDLC(Content c, DownloadPopup downPopup)
    {

        using (UnityWebRequest www = new UnityWebRequest(c._downloadLink))
        {
            www.downloadHandler = new DownloadHandlerBuffer();

            downPopup.title.text = GameData.instance.currentLanguage._downloading;

            UnityWebRequestAsyncOperation download = www.SendWebRequest();

            yield return handleDownloadProgressBar(download, downPopup);

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                downPopup.destroy();

                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }


            else
            {

                byte[] data = www.downloadHandler.data;

                string savingPath = Path.Combine(SaveLoadManager.DLCPATH,c._id);

                downPopup.destroy();

                WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
                waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._initializating);

                waiting.title.text = GameData.instance.currentLanguage._decompressing;

                yield return ExtractZipFile(data,savingPath);

                waiting.destroy();

            }
        }

        yield return null;
    }

    private static IEnumerator downloadImageInPath(string name,string path, string link)
    {

        using (var www = UnityWebRequestTexture.GetTexture(link))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                
            }
            else
            {
                if (www.isDone)
                {
                    string ext = link.Split('.')[link.Split('.').Length - 1];

                    Texture2D x = DownloadHandlerTexture.GetContent(www);

                    byte[] encoding;

                    if (ext.Equals("png"))
                        encoding = x.EncodeToPNG();
                    else
                        encoding = x.EncodeToJPG();

                    File.WriteAllBytes(Path.Combine(path, name + $".{ext}"),encoding);
                }
            }
        }
    }

        private static IEnumerator ExtractZipFile(byte[] zipFileData, string targetDirectory, int bufferSize = 256 * 1024)
    {

        ZipConstants.DefaultCodePage = System.Text.Encoding.UTF8.CodePage;
        Directory.CreateDirectory(targetDirectory);

        using (MemoryStream fileStream = new MemoryStream())
        {
            fileStream.Write(zipFileData, 0, zipFileData.Length);
            fileStream.Flush();
            fileStream.Seek(0, SeekOrigin.Begin);

            ZipFile zipFile = new ZipFile(fileStream);

            foreach (ZipEntry entry in zipFile)
            {
                //Debug.Log(entry.Name);
                //yield return null;
                string targetFile = Path.Combine(targetDirectory, entry.Name);

                if (entry.IsDirectory)
                {
                    if (!Directory.Exists(targetFile))
                    {
                        Directory.CreateDirectory(targetFile);
                    }
                }

                else
                {

                    using (FileStream outputFile = File.Create(targetFile))
                    {
                        if (entry.Size > 0)
                        {
                            Stream zippedStream = zipFile.GetInputStream(entry);
                            byte[] dataBuffer = new byte[bufferSize];

                            int readBytes;
                            while ((readBytes = zippedStream.Read(dataBuffer, 0, bufferSize)) > 0)
                            {
                                outputFile.Write(dataBuffer, 0, readBytes);
                                outputFile.Flush();
                                yield return null;
                            }
                        }
                    }

                }

            }
        }
    }


#endregion
#region Gestione progress bar 

    public static IEnumerator handleDownloadProgressBar(UnityWebRequestAsyncOperation op, DownloadPopup down)
    {
        while (!op.isDone)
        {
            down.setValue((float)Math.Round(op.progress, 2) * 100);
            yield return null;
        }
    }

    public static IEnumerator handleBundleDownloadProgressBar(easyar.ImageTargetController controller, UnityWebRequest www ,UnityWebRequestAsyncOperation op, DownloadPopup down)
    {

        if(controller == null)
        {
            while (!op.isDone)
            {
                if (down != null)
                    down.setValue((float)Math.Round(op.progress, 2) * 100);

                yield return null;
            }
        }

        else
        {
            while (!op.isDone)
            {
                if (!controller.IsTracked)
                {
                    OfflineGameManager.instance.downloadAborted = true;
                    www.Abort();
                    break;
                }


                if (down != null)
                    down.setValue((float)Math.Round(op.progress, 2) * 100);

                yield return null;
            }
        }

        if (down != null)
            down.destroy();

    }


#endregion
#region File system


    public static IEnumerator deleteDLCFromFileSystem(string id)
    {
        if (Directory.Exists(Path.Combine(SaveLoadManager.DLCPATH, id)))
        {
            Directory.Delete(Path.Combine(SaveLoadManager.DLCPATH, id), true);
        }

        yield return null;
    }

    #endregion
#region Notifica al backend


    public static IEnumerator UserDownloadDLC(string id)
    {
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm(APIs.LOGGED_USER_ACTION + GameData.instance.loggedUser._token + "/SET/" + id, string.Empty))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }

            else
            {
                Debug.Log("inserito");
            }
        }
    
    }


    public static IEnumerator UserDeleteDLC(string id)
    {
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm(APIs.LOGGED_USER_ACTION + GameData.instance.loggedUser._token + "/DELETE/" + id, string.Empty))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }

            else
            {
                Debug.Log("Cancellato");
            }
        }

    }

#endregion
}
