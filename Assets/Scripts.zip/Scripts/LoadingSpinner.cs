﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoadingSpinner : MonoBehaviour
{
    private RectTransform _rect;

    private float speed = 5f;

    // Start is called before the first frame update
    void Start()
    {
        _rect = this.GetComponent<RectTransform>();
    }

    // Update is called once per frame
    void Update()
    {
        _rect.Rotate( new Vector3( 0, 0, -45 * speed * Time.deltaTime ) );
    }
}
