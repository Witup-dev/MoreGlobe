using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using DG.Tweening;
using TMPro;

public class BusinessCardBehaviour : MonoBehaviour
{

    private float duration;
    private float smallDuration;
    private bool isWebviewOpen;
    public bool isVideoPlaying;
    public bool isVideoReady;
    public GameObject loading;



    [Header("CanvasInfo")]
    public RectTransform canvasInfo; //x 1.15f
    public Image profileImage;
    public TextMeshProUGUI first_line;
    public TextMeshProUGUI second_line;

    [Header("CanvasVideo")]
    public RectTransform canvasVideo;//y -0.8
    public RectTransform canvasWebButtons;//x 115

    public VideoPlayer player;

    [Header("OptionButtons")]
    public RectTransform optionButtonsContainer;
    public Button[] actionButtons;
    public Button[] functionButtons;

    [Header("Webview")]
    public RectTransform webviewContainer;
    public RectTransform webviewOptions;//x 34.5

    public Button expandButton;
    public Button closeButton;

    private void Start()
    {
        duration = 0.5f;
        smallDuration = 0.3f;
        isWebviewOpen = false;
        isVideoPlaying = false;
        isVideoReady = false;
        //initAnimation();
    }

    public void initialize()
    {
        closeButton.onClick.AddListener(closeWebView);
        
        if(string.IsNullOrEmpty(player.url))
        {
            player.transform.parent.gameObject.SetActive(false);
        }
        
        initAnimation();
    }


    private void initAnimation()
    {
        Destroy(loading.gameObject);

        canvasInfo.DOAnchorPosX(1.025f, duration).onComplete = () => {

            first_line.rectTransform.DOScaleY(1, smallDuration);
            second_line.rectTransform.DOScaleY(1, smallDuration).onComplete = () => {


                canvasVideo.DOAnchorPosY(-0.665f, duration).onComplete = () => {

                    if (!string.IsNullOrEmpty(player.url))
                    {
                        player.Play();
                        isVideoReady = true;
                        isVideoPlaying = true;

                        canvasWebButtons.DOAnchorPos(new Vector2(102.5f, canvasWebButtons.position.y), duration).onComplete = () => {


                            optionButtonsContainer.DOScaleY(1, smallDuration);

                        };
                    }

                    else
                    {
                        optionButtonsContainer.DOScaleY(1, smallDuration);
                    }

                };


            };

        };
    }


    public void openWebView()
    {
        if (!isWebviewOpen)
        {

            if (!string.IsNullOrEmpty(player.url))
            {
                player.Pause();
                isVideoPlaying = false;
            }

            webviewContainer.DOScaleY(1, 0.3f).onComplete = () =>
            {

                webviewOptions.gameObject.SetActive(true);
                webviewOptions.DOAnchorPosX(35f, duration);

            };
            isWebviewOpen = true;
        }
        
    }

    private void closeWebView()
    {

        if (isWebviewOpen)
        {
            if (!string.IsNullOrEmpty(player.url))
            {
                player.Play();
                isVideoPlaying = true;
            }

            webviewOptions.DOAnchorPosX(0, duration).onComplete = () => {

                webviewOptions.gameObject.SetActive(false);
                webviewContainer.DOScaleY(0, smallDuration);

            };
            isWebviewOpen = false;
        }

    }

}
