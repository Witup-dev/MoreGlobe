﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.SignInWithApple;
using TMPro;
#if UNITY_IOS
using Unity.Notifications.iOS;
#elif UNITY_ANDROID
using UnityEngine.Android;
#endif

public class SplashSceneManager : MonoBehaviour
{
    [Header("Variables")]
    public VideoPlayer player;

    public CanvasGroup canvGroup;

    public GameObject loadingImage;
    public Image customLoadingImage;


    public GameObject languagePanel;
    public TextMeshProUGUI chooseLanguage;
    public TextMeshProUGUI confirmButtonText;

    

    public float duration = 1f;


    private string storeUrl;



    #region Unity Lifecycle 
    private void Awake()
    {
#if UNITY_ANDROID

        storeUrl = "market://details?id=com.creatiwa.moreglobe";
#endif

#if UNITY_IOS
        storeUrl = "itms-apps://itunes.apple.com/app/id1524559649";
#endif

        Application.targetFrameRate = 30;
        initializeDirectory();
        setResolution();
    }

    // Start is called before the first frame update
    void Start()
    {

        StartCoroutine(Utilities.checkForMaintenance(true));

        GameData.instance.gameObject.AddComponent<NotificationInitializer>();


        if (PlayerPrefs.HasKey("appConfig"))
        {
            Debug.Log($"final debug: ho app config");
            GameData.instance.appConfig = JsonUtility.FromJson<AppConfiguration>(PlayerPrefs.GetString("appConfig"));

        }

        else
        {
            Debug.Log($"final debug: non ho app config");
            GameData.instance.appConfig = new AppConfiguration();




            PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
            PlayerPrefs.Save();
        }

        if (PlayerPrefs.HasKey("firstStart"))//ho già effettuato il primo avvio
        {
            Debug.Log($"final debug: not the first start");

            if (PlayerPrefs.HasKey("customContent"))
            {
                Debug.Log($"final debug: have the custo content");
                //handle here the splash image
                GameData.instance.selectedCustomContent = JsonUtility.FromJson<CustomizationItem>(PlayerPrefs.GetString("customContent"));
                
                #region custom splash
                // if(File.Exists(Path.Combine(Application.persistentDataPath, "customSplash.png")))
                // {
                //     Debug.Log($"final debug: have the custo pic");
                //     Texture2D tex = new Texture2D(2, 2);
                //     tex.LoadImage(File.ReadAllBytes(Path.Combine(Application.persistentDataPath, "customSplash.png")));
                //     customLoadingImage.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f));
                //     customLoadingImage.gameObject.SetActive(true);
                // }
                // else
                #endregion
                {
                    Debug.Log($"final debug: not have the custo pic");
                    loadingImage.SetActive(true);
                }
                
            }
            else
            {
                Debug.Log($"final debug: not have the custo");
                loadingImage.SetActive(true);
            }
            
            StartCoroutine(checkForApplicationUpdate());
        }

        else
        {
            Debug.Log($"final debug: first access");
            PlayerPrefs.SetInt("firstStart", 1);
            PlayerPrefs.Save();

            player.loopPointReached += checkVideoEnd;
            player.Play();
        }

        


    }

    #endregion
    #region Video Listeners

    private void checkVideoEnd(VideoPlayer vp)
    {
        if (!PlayerPrefs.HasKey("appLanguage"))
        {
            languagePanel.SetActive(true);
        }
        else
        {
            StartCoroutine(openSceneWaitingGameData("LoginScene"));
        }

    }


    #endregion

    #region APPLE_SIGIN

    //public void isAppleIDAuthorized(SignInWithApple.CallbackArgs args)
    //{
    //    if (args.credentialState == UserCredentialState.Authorized)
    //    {
    //        StartCoroutine(getUserDownloadedContentList());
    //    }

    //    else
    //    {
    //        GameData.instance.loggedUser = new User();
    //        PlayerPrefs.DeleteKey("loggedUser");
    //        PlayerPrefs.Save();

    //        StartCoroutine(openSceneWaitingGameData("LoginScene"));
    //    }
    //}


    #endregion

        private void setResolution()
    {
        Debug.Log($"Resolution: {Screen.currentResolution}");
        foreach(var res in Screen.resolutions)
            Debug.Log($"Resolutions: {res}");
        var aspectRatio = Mathf.Max(Screen.width, Screen.height) / Mathf.Min(Screen.width, Screen.height);

        var isTablet = (Utilities.DeviceDiagonalSizeInInches() > 6.5f && aspectRatio < 2f);

        if (isTablet)
            Screen.SetResolution(1440, 2560, true);
    }

    private void initializeDirectory()
    {
        
        if (!PlayerPrefs.HasKey("deepClean2"))
        {
            
            PlayerPrefs.DeleteAll();

            if (Directory.Exists(SaveLoadManager.DLCPATH))
            {
                Directory.Delete(SaveLoadManager.DLCPATH,true);
            }

            if (Directory.Exists(SaveLoadManager.THUMBNAILPATH))
                Directory.Delete(SaveLoadManager.THUMBNAILPATH, true);

            if (Directory.Exists(SaveLoadManager.SAVINGPATH))
                Directory.Delete(SaveLoadManager.SAVINGPATH, true);

            PlayerPrefs.SetInt("deepClean2", 1);
            PlayerPrefs.Save();
        }

        if (!Directory.Exists(SaveLoadManager.DLCPATH))
            Directory.CreateDirectory(SaveLoadManager.DLCPATH);        

    }

   

    private IEnumerator checkForApplicationUpdate()
    {

#if UNITY_ANDROID
        var os = "/android";
#else
        var os = "/ios";
#endif

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.VERSION_CONTROL + Application.version + os))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {

                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[1]._title,
                    GameData.instance.currentLanguage._popupInfoJson[1]._message,
                    GameData.instance.currentLanguage._popupInfoJson[1]._buttonText,
                    "error",
                    () => { StartCoroutine(checkForApplicationUpdate()); });
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success)
                {
                    Destroy(loadingImage);


                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[2]._title,
                        GameData.instance.currentLanguage._popupInfoJson[2]._message,
                        GameData.instance.currentLanguage._popupInfoJson[2]._buttonText,
                        default,
                        () =>
                        {

                            Application.OpenURL(storeUrl);

                        });

                }
                else
                {
                    //handle this in gameData
                    if (!string.IsNullOrEmpty(GameData.instance.loggedUser._token)) // logged in
                    {

                        yield return getUserDownloadedContentList();

                    }

                    else // not logged
                    {
                        if (!PlayerPrefs.HasKey("appLanguage"))
                        {
                            languagePanel.SetActive(true);

                        }
                        else
                        {
                            StartCoroutine(openSceneWaitingGameData("LoginScene"));
                        }
                    }

                }

            }
            yield return null;
        }


    }

    private IEnumerator getUserDownloadedContentList()
    {
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm(APIs.LOGGED_USER_ACTION + GameData.instance.loggedUser._token + "/LIST", string.Empty))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                GameData.instance.loggedUser._associatedContent = new List<string>();
            }

            else
            {
                UserContentResponse response = JsonUtility.FromJson<UserContentResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    GameData.instance.loggedUser._associatedContent = response.getAllContentIDs();
                }
            }

            if (PlayerPrefs.HasKey("lastContentViewed") && GameData.instance.appConfig._cameraPermission && !DeepLinkManager.instance.hasAction)
            {
                var c = JsonUtility.FromJson<Content>(PlayerPrefs.GetString("lastContentViewed"));

                GameData.instance.selectedContentId = c._id;

                StartCoroutine(openSceneWaitingGameData("LocalMarkerScene"));
            }

            else
            {
                StartCoroutine(openSceneWaitingGameData("MenuScene"));
            }
        }

    }


    private IEnumerator openSceneWaitingGameData(string sceneName)
    {
        yield return new WaitUntil(() => GameData.instance.canLoadOn);
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }

    

    #region Languege handler

    public void changeLanguage(string lan)
    {
        GameData.instance.selectedLanguage = lan;
        chooseLanguage.text = Utilities.chooseLanguageMap[lan][0];
        confirmButtonText.text = Utilities.chooseLanguageMap[lan][1];
    }

    public void languageSelected()
    {
        var jsonLanguageFile = Resources.Load("Localization/" + GameData.instance.selectedLanguage) as TextAsset;
        GameData.instance.currentLanguage = JsonUtility.FromJson<JsonLanguage>(jsonLanguageFile.text);
        
        PlayerPrefs.SetString("appLanguage", GameData.instance.selectedLanguage);
        PlayerPrefs.Save();

        StartCoroutine(openSceneWaitingGameData("LoginScene"));

    }

    #endregion

    #region APP PERMISSION


//    public void onGPSToggleChange(Toggle value)
//    {
//        if (value.isOn)
//        {
//#if UNITY_ANDROID

//            if (!Permission.HasUserAuthorizedPermission(Permission.FineLocation))
//            {
//                var callbacks = new PermissionCallbacks();
//                callbacks.PermissionDenied += ((name) => {
//                    value.isOn = false;
//                });
//                callbacks.PermissionGranted += ((name) => {
//                    GameData.instance.appConfig._gpsPermission = true;
//                });

//                Permission.RequestUserPermission(Permission.FineLocation, callbacks);
//            }


//#elif UNITY_IOS
//        getIosGPSPermission(value);
//#endif
//        }

//        else
//        {
//            GameData.instance.appConfig._gpsPermission = false;
//        }
//    }

//    public void onCameraToggleChange(Toggle value)
//    {

//        if (value.isOn)
//        {
//#if UNITY_ANDROID

//            if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
//            {
//                var callbacks = new PermissionCallbacks();
//                callbacks.PermissionDenied += ((name) => {
//                    value.isOn = false;
//                    GameData.instance.appConfig._cameraPermission = false;
//                });
//                callbacks.PermissionGranted += ((name) => {
//                    GameData.instance.appConfig._cameraPermission = true;
//                });

//                Permission.RequestUserPermission(Permission.Camera, callbacks);
//            }

//            else
//            {
//                GameData.instance.appConfig._cameraPermission = true;
//            }

//#elif UNITY_IOS
//        StartCoroutine(getIosCameraPermission(value));
//#endif
//        }

//        else
//        {
//            GameData.instance.appConfig._cameraPermission = false;
//        }
//    }

//    public void onNotificationToggleChange(Toggle value)
//    {
//        if (value.isOn)
//        {
//#if UNITY_ANDROID

//            GameData.instance.appConfig._notificationPermission = true;


//#elif UNITY_IOS
//        StartCoroutine(getNotificationPermission(value));
//#endif
//        }

//        else
//        {
//            GameData.instance.appConfig._notificationPermission = false;
//        }
//    }

//    public void permissionContinueButton()
//    {
//        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
//        PlayerPrefs.Save();

        
//    }


//    private IEnumerator getIosCameraPermission(Toggle value)
//    {
//        foreach (var device in WebCamTexture.devices)
//        {
//            Debug.Log("Name: " + device.name);
//        }

//        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
//        if (Application.HasUserAuthorization(UserAuthorization.WebCam))
//        {
//            GameData.instance.appConfig._cameraPermission = true;
//        }
//        else
//        {
//            GameData.instance.appConfig._cameraPermission = false;
//            value.isOn = false;
//        }
//    }
//    private void getIosGPSPermission(Toggle value)
//    {
//        if (!Input.location.isEnabledByUser)
//        {
//            Input.location.Start();

//            Input.location.Stop();

//            if (!Input.location.isEnabledByUser)
//            {
//                GameData.instance.appConfig._gpsPermission = false;
//                value.isOn = false;
//            }

//            else
//            {
//                GameData.instance.appConfig._gpsPermission = true;
//            }
//        }

//        else
//        {
//            GameData.instance.appConfig._cameraPermission = true;
//        }
//    }

    #endregion

}
