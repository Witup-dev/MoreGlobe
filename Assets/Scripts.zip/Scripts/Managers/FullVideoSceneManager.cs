﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine.SceneManagement;
using Vuplex.WebView;
using UnityEngine;
using SimpleJSON;

public class FullVideoSceneManager : MonoBehaviour
{

    public Transform canvas;

    private CanvasWebViewPrefab webViewFullScreen;



    // Start is called before the first frame update
    void Start()
    {
        if(GameData.instance.fullScreenVideoMarker != null)
        {
            if(GameData.instance.fullScreenVideoMarker.orientation.Equals("L"))
                Screen.orientation = ScreenOrientation.LandscapeLeft;
            else
                Screen.orientation = ScreenOrientation.Portrait;
        }

        else
        {
            Screen.orientation = ScreenOrientation.LandscapeLeft;
        }
       
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        webViewFullScreen = CanvasWebViewPrefab.Instantiate();
        webViewFullScreen.transform.SetParent(canvas);
        var rectTransform = webViewFullScreen.transform as RectTransform;
        rectTransform.anchoredPosition3D = Vector3.zero;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        webViewFullScreen.Resolution = 1300;
        webViewFullScreen.transform.localScale = Vector3.one;

        webViewFullScreen.Native2DModeEnabled = true;

        Web.SetAutoplayEnabled(true);
        Web.SetUserAgent(true);
        

        webViewFullScreen.Initialized += (sender, e) =>
        {
            if (GameData.instance.fullScreenVideoMarker.isWebPage)
            {
                webViewFullScreen.WebView.LoadUrl(GameData.instance.fullScreenVideoMarker.url);
                canvas.GetComponent<CanvasGroup>().alpha = 1;
            }

            else
            {
                // esempio https://www.moreglobe.com/be/youtube/fb/2139491862804999?start=10&end=40&fullscreen=0
                var splitted = GameData.instance.fullScreenVideoMarker.url.Split(new char[] { '?', '&' }); //[1] = start, [2] = end, [3] = fullscreen, [4] = id

                string newUri = splitted[0] + "?start=" + GameData.instance.fullScreenTimeToResume + "&" + splitted[2] + "&fullscreen=1&" +splitted[4];

                Debug.Log("Fullscreen uri: " + newUri);

                webViewFullScreen.WebView.LoadUrl(newUri);
                canvas.GetComponent<CanvasGroup>().alpha = 1;

                webViewFullScreen.WebView.MessageEmitted += (sender2, eventArgs2) =>
                {
                    Debug.Log("received from WebView: " + eventArgs2.Value);

                    var jobj = JSON.Parse(eventArgs2.Value);

                    if (jobj["action"].Equals("close"))
                    {
                        GameData.instance.fullScreenTimeToResume = (int)jobj["time"];

                        Debug.Log("time ricevuto: " + (int)jobj["value"]);

                        SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);

                    }


                };
            }
            
        };
     
    }

   // private void Update()
    //{
      //  if (Input.GetKeyDown(KeyCode.Escape))
        //{
         //   SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);
        //}
    //}

    private void OnApplicationPause(bool pause)
    {
        if (pause)
        {
            SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);
        }

        
    }

}
