﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using SimpleJSON;
using easyar;
using LightShaft.Scripts;
using UnityEngine.Android;
using OneSignalSDK;

public class GameManager : MonoBehaviour
{



[Header("Singleton")]

    public static GameManager instance { get; private set; }



[Header("AR / Camera")]

    public CameraDeviceFrameSource cameraDevice;

    private bool isFlashActive;

    public GameObject switchCameraButton;



[Header("UI di scena")]

    public GameObject panelOptions;
    public Canvas globalCanvas;
    public GameObject bottomLogo;
    public Button siteButton;
    public Button fullScreenButton;
    public Button spatialButton;
    public GameObject closeFullScreenButton;
    public GameObject flashButton;
    public GameObject menuButton;



[Header("Marker & contenuti")]

    private Content tmpContent;
    private Marker currentMarker;
    private float currentRatio;
    private GameObject target;
    private bool hasModel;
    private bool isIstantiated;
    private bool isBegin;




    
[Header("Video / YouTube")]

    private UnityEngine.Video.VideoPlayer currentPlayer;
    private RectTransform videoPanel;
    private bool isFullScreen;
    private bool isOnfocus;
    private RectTransform loadingSpinner;
    private UnityEngine.UI.Image panelImage;
    private Mask panelMask;
    public RenderTexture texturePrefab;
    // Youtube Player
    private YoutubePlayer _yp;
    // audiosource
    private AudioSource audiosource;
    private GameObject playPauseButton;


    

[Header("Popup & tutorial")]

    public PopupConnect choice;
     //tutorial
    private bool isTutorialSeen;
    public Sprite tutorialSprite;




[Header("Stato sessione")]

    public bool isFrameSomething;
    private long sessionId;

   

    #region UNITY METHODS


    private void Awake()
    {

        sessionId = new DateTimeOffset(DateTime.Now).ToUnixTimeSeconds();

        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }


        GameData.instance.modelListForSpatialDemo = new List<MarkerModel>();

        currentMarker = null;
        currentPlayer = null;
        hasModel = false;
        isBegin = false;

        isFrameSomething = false;
        tmpContent = null;

        isFlashActive = false;

        GameData.instance.hasStartAR = true;

        isTutorialSeen = false;

        if (PlayerPrefs.HasKey("framingTutorial"))
        {
            isTutorialSeen = true;
        }

    }

    // Start is called before the first frame update
    void Start()
    {
        Screen.orientation = ScreenOrientation.Portrait;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        StartCoroutine(initialize());
        Debug.Log("🚀 ~ file: GameManager.cs:134 ~ initialize:");



        if (!GameData.instance.appConfig._cameraPermission)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            Debug.Log("🚀 ~ file: GameManager.cs:141 ~ CreateInfoPopup");
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[20]._title,
                GameData.instance.currentLanguage._popupInfoJson[20]._message,
                GameData.instance.currentLanguage._popupInfoJson[20]._buttonText,
                "error",
                () =>
                {

                    goToMenu();
                    Debug.Log("🚀 ~ file: GameManager.cs:151 ~ goToMenu");

                });
        }

        else if (!isTutorialSeen)
        {
            StartCoroutine(startTutorial());
        }
        else
        {
            cameraDevice.transform.parent.GetComponentInChildren<ImageTrackerFrameFilter>().enabled = true;
        }

        if (!PlayerPrefs.HasKey("see3DSpaceTut"))
        {
            spatialButton.transform.GetChild(0).gameObject.SetActive(true);
        }
        else
            spatialButton.transform.GetChild(0).gameObject.SetActive(false);

        if (PlayerPrefs.HasKey("lastContentViewed"))
            spatialButton.gameObject.SetActive(false);
        else
            StartCoroutine(getContent3DModel());

    }

     private void OnApplicationPause(bool pause)
    {

        if (pause)
        {
            cameraDevice.enabled = false;

        }

        else
        {
            cameraDevice.enabled = true;
        }


    }


    private void OnApplicationFocus(bool focus)
    {
        if (focus)
        {
            cameraDevice.enabled = true;
            cameraDevice.transform.parent.GetComponent<ImageTrackerFrameFilter>().enabled = true;
        }
    }

    #endregion

    #region Initialization Methods

    private IEnumerator startTutorial()
    {
        yield return new WaitForSeconds(1f);
        var tutorial = UIController.instance.CreateTutorialPopupImage();
        tutorial.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[1]._title,
            GameData.instance.currentLanguage._popupTutorialJson[1]._message,
            tutorialSprite,
            0,
            () =>
            {

                cameraDevice.transform.parent.GetComponentInChildren<ImageTrackerFrameFilter>().enabled = true;

            });

    }

    private IEnumerator initialize()
    {
        yield return Utilities.checkForMaintenance(false);

        if (GameData.instance.isInMaintenance)
        {
            MaintenancePopup popup = UIController.instance.CreateMaintenancePopup();
            popup.initialize(UIController.instance.mainCanvas);
        }
    }

    private IEnumerator getContent3DModel()
    {

        // if (haveToWait)
        // {
        //     yield return new WaitForSeconds(3f);
        // }


        string requestData = APIs.TAKE_3D_MODEL_LIST + GameData.instance.loggedUser._token + APIs.LIST_FOR_SPATIAL_TO_ADD + "2";

        Debug.Log($"requestData {requestData}");
        using (UnityWebRequest www = UnityWebRequest.Get(requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }


            else
            {
                MarkerModelResponse response = JsonUtility.FromJson<MarkerModelResponse>(www.downloadHandler.text);

                Debug.Log($"requestData 1");
                if (response._success)
                {

                    if (GameData.instance.modelListForSpatialDemo.Count > 0)
                        GameData.instance.modelListForSpatialDemo.Clear();
                    Debug.Log($"requestData 2");
                    if (response._data.Count > 0)
                    {
                        // Debug.Log("entrato nel counter " + response._data.Count);
                        spatialButton.gameObject.SetActive(true);
                        GameData.instance.modelListForSpatialDemo = response._data;

                        Debug.Log($"GameData.instance.modelListForSpatialDemo {GameData.instance.modelListForSpatialDemo.Count}");
                    }
                    else
                    {

                        Debug.Log($"requestData 3");
                        spatialButton.gameObject.SetActive(false);
                        GameData.instance.modelListForSpatialDemo = new List<MarkerModel>();
                    }


                }

            }

        }
    }

   
    #endregion
    #region Core methods for marker/video/model handling 

    public void setCurrentMarker(GameObject target, Marker marker)
    {
        isBegin = false;
        isIstantiated = false;
        isOnfocus = false;

        audiosource = null;

        this.target = target.transform.GetChild(0).gameObject;

        //Analytics.instance.videoAction(2, currentMarker.name, 0, (int)currentPlayer.time);

        this.currentMarker = marker;
        Debug.Log($"🚀 ~ file: GameManager.cs:310 ~ marker: {marker}");

        if (!string.IsNullOrEmpty(currentMarker.is3D))
        {

            //Devo mostrare il modello 3d
            hasModel = true;

            //target.transform.GetChild(0).gameObject.SetActive(false);

        }
        else
        {
            //Devo mostrare il video
            hasModel = false;
            Debug.Log("🚀 ~ file: GameManager.cs:327 ~ setCurrentVideoPlayer");
            //setCurrentTargetSize();
            setCurrentVideoPlayer();
            
        }

    }

    private void setCurrentVideoPlayer()
    {

        if (isFullScreen)
        {
            exitFullScreen();
        }


        currentPlayer = target.transform.GetChild(0).GetComponentInChildren<UnityEngine.Video.VideoPlayer>();
        videoPanel = currentPlayer.transform.parent.GetComponent<RectTransform>();
        currentPlayer.targetCamera = Camera.main;


        if (currentMarker.mask != "")
        {
            panelImage = target.transform.GetChild(0).GetComponentInChildren<UnityEngine.UI.Image>();
            panelMask = target.transform.GetChild(0).GetComponentInChildren<Mask>();

            panelImage.color = new Color(1, 1, 1, 1);

            //panelImage.sprite = Resources.Load<Sprite>("Masks/" + currentMarker.mask);

            StartCoroutine(downloadMask());

            //Resources.Load("Prefabs/" + currentMarker.modelName, typeof(GameObject));

        }

        _yp = target.transform.GetComponentInChildren<YoutubePlayer>();
        _yp.videoQuality = YoutubePlayer.YoutubeVideoQuality.STANDARD;

        RenderTexture videoTexture = new RenderTexture(texturePrefab);

        currentPlayer.GetComponent<RawImage>().texture = videoTexture;
        currentPlayer.targetTexture = videoTexture;
        Debug.Log($"🚀 ~ file: GameManager.cs:369 ~ videoTexture: {videoTexture}");

        //setting the buttons
        //fullScreenButton = target.transform.GetChild(1).GetChild(0).GetChild(1).GetChild(0).gameObject;//3
        fullScreenButton.onClick.RemoveAllListeners();
        fullScreenButton.onClick.AddListener(goToFullScreen);

        //siteButton = target.transform.GetChild(1).GetChild(0).GetChild(0).GetChild(0).gameObject;//1
        siteButton.onClick.RemoveAllListeners();
        siteButton.onClick.AddListener(goToWebView);


    }

    private IEnumerator downloadMask()
    {
        using (var www = UnityWebRequestTexture.GetTexture(currentMarker.mask))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                panelMask.enabled = false;
            }
            else
            {
                if (www.isDone)
                {
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    panelImage.sprite = Sprite.Create(x, new Rect(0.0f, 0.0f, x.width, x.height), new Vector2(0.5f, 0.5f), 100.0f);
                    panelMask.enabled = true;
                }
            }
        }
    }

    public void setFullAndSite(bool status)
    {
        fullScreenButton.gameObject.SetActive(status);

        if (status)
        {
            if (!string.IsNullOrEmpty(currentMarker.site))
            {
                siteButton.gameObject.SetActive(true);
            }
        }

        else
        {
            siteButton.gameObject.SetActive(false);
        }

    }

    public void handleModelAudio(bool play)
    {
        if (audiosource != null)
        {
            if (play)
                audiosource.Play();
            else
                audiosource.Pause();
        }
    }


    public void playAndAppear(float ratio)
    {
        currentRatio = ratio;
        //Debug.Log("Online ratio: " + ratio);

        if (!string.IsNullOrEmpty(currentMarker.is3D))
        {
            Debug.Log("devo modellare");
            //Ha un modello, quindi gestisco il modello
            if (!isIstantiated)
            {

                instatiateModel();
                //Analytics.instance.recognize(currentMarker.name);
                isIstantiated = true;
            }
            else
            {
                handleModelAudio(true);
            }
        }
        else
        {
            setFullAndSite(true);
            Debug.Log($"🚀 ~ file: GameManager.cs:466 ~ isBegin: {isBegin}");
            //playPauseButton.SetActive(false);
            if (isBegin)
            {
                playPauseButton.SetActive(false);
                Debug.Log($"🚀 ~ file: GameManager.cs:470 ~ playVideo:");
                this.playVideo();
                
            }
            else
            {
                videoPanel.sizeDelta = new Vector2(1, 1 / ratio);
                Debug.Log($"🚀 ~ file: GameManager.cs:480 ~ currentMarker.contentID: {currentMarker.contentID}");
                Debug.Log($"🚀 ~ file: GameManager.cs:479 ~ askForDownload");
                StartCoroutine(askForDownload(currentMarker.contentID));
                
            }
        }

    }

    public void instatiateModel()
    {
        Debug.Log("Instanzio il modello");
        //Creo un istanza del prefab con il nome preso dal marker

        siteButton.gameObject.SetActive(false);
        fullScreenButton.gameObject.SetActive(false);

        Transform controller = target.transform.parent;
        Destroy(target.gameObject);

        GameObject model = null;

        if (currentMarker.is3D.Equals("vr46"))
        {
            model = Instantiate(Resources.Load("Prefabs/" + currentMarker.is3D, typeof(GameObject)), new Vector3(controller.position.x, controller.position.y, controller.position.z), Quaternion.Euler(-90, 0, 0), controller) as GameObject;
        }

        else
        {

            //GameObject model = Instantiate(Resources.Load("Prefabs/Ferrari", typeof(GameObject)),spawn.position,Quaternion.identity,spawn) as GameObject;
            model = Instantiate(Resources.Load("Prefabs/" + currentMarker.is3D, typeof(GameObject)), controller.position, Quaternion.Euler(90, 90, -90), controller) as GameObject;
            //GameObject model = Instantiate(Resources.Load("Prefabs/" + currentMarker.modelName, typeof(GameObject)), controller.position, Quaternion.identity, controller) as GameObject;
        }

        audiosource = model.GetComponentInChildren<AudioSource>();

        //Analytics.instance.model3D(currentMarker.name, currentMarker.modelName);

    }

    public void PlayPauseButton()
    {
        if (currentPlayer.isPlaying)
        {
            currentPlayer.Pause();
            playPauseButton.SetActive(true);
            loadingSpinner = null;
            //StartCoroutine(sendStats(currentPlayer.time, 2));
            Debug.Log("Pausa " + currentPlayer.time);
            //Analytics.instance.videoAction(1, currentMarker.name, 2, (int)currentPlayer.time);
        }

        else
        {
            currentPlayer.Play();
            playPauseButton.SetActive(false);
            //StartCoroutine(sendStats(currentPlayer.time, 3));
            Debug.Log("Resume " + currentPlayer.time);
            //Analytics.instance.videoAction(1, currentMarker.name, 1, (int)currentPlayer.time);
        }
    }


    public void playVideo()
    {

        fullScreenButton.gameObject.SetActive(true);

        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            siteButton.gameObject.SetActive(true);
        }
        else
        {
            siteButton.gameObject.SetActive(false);
        }


        if (isFullScreen)
        {
            fullScreenButton.gameObject.SetActive(false);
            siteButton.gameObject.SetActive(false);

        }
        
        Debug.Log($"🚀 ~ file: GameManager.cs:565 ~ play currentPlayer: {currentPlayer}");
        currentPlayer.Play();
        
        //Analytics.instance.videoAction(1, currentMarker.name, 1, (int)currentPlayer.time);
        //StartCoroutine(sendStats(currentPlayer.time, 3));
        Debug.Log("resume video " + currentPlayer.time);
    }

    //Chiamato dal target quando perde il focus sul target
    public void pauseVideo()
    {
        if (currentMarker != null && !hasModel)
        {
            if (!isFullScreen)
            {
                if (playPauseButton != null)
                {
                    playPauseButton.SetActive(true);
                }

                currentPlayer.Pause();
                Debug.Log("lost focus " + currentPlayer.time);
            }

            //Analytics.instance.videoAction(1, currentMarker.name, 2, (int)currentPlayer.time);
            //StartCoroutine(sendStats(currentPlayer.time, 4));

        }
    }


    public void goToFullScreen()
    {

        fullScreenButton.gameObject.SetActive(false);
        siteButton.gameObject.SetActive(false);
        closeFullScreenButton.SetActive(true);
        flashButton.SetActive(false);
        menuButton.SetActive(false);
        panelOptions.gameObject.SetActive(false);
        switchCameraButton.SetActive(false);
        bottomLogo.SetActive(false);

        isFullScreen = true;
        currentPlayer.renderMode = VideoRenderMode.CameraNearPlane;
        currentPlayer.gameObject.GetComponent<RawImage>().enabled = false;


        //Controllo sull'orientamento
        if (currentMarker.orientation == "L")
        {
            //mandare lo schermo in landscape
            Screen.orientation = ScreenOrientation.LandscapeLeft;
        }
    }

    public void exitFullScreen()
    {

        fullScreenButton.gameObject.SetActive(true);
        menuButton.SetActive(true);
        flashButton.SetActive(true);
        panelOptions.gameObject.SetActive(true);
        switchCameraButton.SetActive(true);

        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            siteButton.gameObject.SetActive(true);
        }
        else
        {
            siteButton.gameObject.SetActive(false);
        }

        closeFullScreenButton.SetActive(false);
        bottomLogo.SetActive(true);

        isFullScreen = false;
        currentPlayer.gameObject.GetComponent<RawImage>().enabled = true;
        currentPlayer.renderMode = VideoRenderMode.RenderTexture;

        if (!isOnfocus)
        {
            currentPlayer.Pause();
            fullScreenButton.gameObject.SetActive(false);
            siteButton.gameObject.SetActive(false);
        }

        Screen.orientation = ScreenOrientation.Portrait;

    }

#endregion
    #region VIDEO EVENT

    //chiamato quando la pubblicità finisce
    private void checkAdEnd(UnityEngine.Video.VideoPlayer vp)
    {

        fullScreenButton.gameObject.SetActive(true);

        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            siteButton.gameObject.SetActive(true);
        }

        else
        {
            siteButton.gameObject.SetActive(false);
        }

        //Gestisco il video
        vp.url = currentMarker.url;

        vp.Prepare();

        vp.prepareCompleted += checkVideoPrepared;

    }

    //chiamato quando finisce il video
    private void checkEndForRequest(UnityEngine.Video.VideoPlayer vp)
    {
        //StartCoroutine(sendStats(currentPlayer.time, 5));
        //Analytics.instance.videoAction(2, currentMarker.name, 0, (int)currentPlayer.time);
        Debug.Log("fine video " + currentPlayer.time);
    }

    //chiamato quando la preparazione del video è conclusa e lo si fa partire
    private void checkVideoPrepared(UnityEngine.Video.VideoPlayer vp)
    {
        Debug.Log($"🚀 ~ file: GameManager.cs:695 ~ vp: {vp}");   
        loadingSpinner.gameObject.SetActive(false);
        loadingSpinner = null;

        Debug.Log($"🚀 ~ file: GameManager.cs:701 ~ currentMarker.isYoutube: {currentMarker.isYoutube}");
        if (currentMarker.isYoutube)
        {
            _yp.Play(currentMarker.url);
        }
        else
        {
            vp.url = currentMarker.url; 
            Debug.Log($"🚀 ~ file: GameManager.cs:708 ~ url: {currentMarker.url}");
            vp.SetDirectAudioMute(0, false);
            // ANDREA
            this.target.transform.GetChild(0).GetComponent<CanvasGroup>().alpha = 1;
            vp.Play();
        }


        //StartCoroutine(sendStats(currentPlayer.time, 1));
        Debug.Log("inizio video " + currentPlayer.time);
        vp.loopPointReached += checkEndForRequest;
        //Analytics.instance.recognize(currentMarker.name);
        //Analytics.instance.videoAction(1, currentMarker.name, 1, (int)currentPlayer.time);
    }

    //chiamato quando il video della pubblicità è pronto per essere mandato in play
    private void checkAdVideoPrepared(UnityEngine.Video.VideoPlayer vp)
    {
        loadingSpinner.gameObject.SetActive(false);
        vp.Play();
        //StartCoroutine(sendStats(currentPlayer.time, 0));
        Debug.Log("pubblicità " + currentPlayer.time);
    }

    #endregion

    #region Download / bundle / backend

    private IEnumerator get3DModel(ImageTargetController controller, string modelLink)
    {

        string bundleURL = modelLink + "-";
        //string bundleURL = "www.moreglobe.com/be/upload/bundle/testbundle" + "-";

#if UNITY_ANDROID
        bundleURL += "Android";
#else
        bundleURL += "IOS";
#endif

        using (UnityWebRequest www = UnityWebRequestAssetBundle.GetAssetBundle(bundleURL))
        {

            yield return www.SendWebRequest();


            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }

            else
            {
                AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(www);
                if (bundle != null)
                {
                    string rootAssetPath = bundle.GetAllAssetNames()[0];
                    GameObject arObject = Instantiate(bundle.LoadAsset(rootAssetPath) as GameObject, controller.transform);
                    arObject.transform.rotation = Quaternion.Euler(90, 180, 0);
                    arObject.transform.LookAt(Camera.main.transform);
                    bundle.Unload(false);

                }
                else
                {
                    Debug.Log("No model");
                }
            }

        }
    }

    IEnumerator adRequest(string id)
    {
        Debug.Log($"🚀 ~ file: GameManager.cs:777 ~ playPauseButton:{playPauseButton}");
        playPauseButton = target.transform.GetChild(1).GetChild(0).GetChild(0).gameObject;
        
        playPauseButton.transform.parent.GetComponent<Button>().onClick.AddListener(PlayPauseButton);

        loadingSpinner = target.transform.GetChild(1).GetChild(1).GetComponent<RectTransform>();

        loadingSpinner.sizeDelta = new Vector2(0.5f / currentRatio, 0.5f / currentRatio);
        playPauseButton.transform.parent.GetComponent<RectTransform>().sizeDelta = new Vector2(0.5f / currentRatio, 0.5f / currentRatio);

        //Non ci sono pubblicità da mostrare

        fullScreenButton.gameObject.SetActive(true);

        if (!string.IsNullOrEmpty(currentMarker.site))
        {
            siteButton.gameObject.SetActive(true);
        }
        else
        {
            siteButton.gameObject.SetActive(false);
        }

        //Far partire il video
        if (currentMarker.isYoutube)
        {
            _yp.Play(currentMarker.url);
        }

        else
        {
            //Gestisco il video
            loadingSpinner.gameObject.SetActive(true);
            currentPlayer.url = currentMarker.url;

            currentPlayer.Prepare();

            currentPlayer.prepareCompleted += checkVideoPrepared;
        }

        yield return null;
        //Analytics.instance.recognize(currentMarker.name);
    }

   private IEnumerator takeShot()
{
    globalCanvas.enabled = false;

    fullScreenButton.gameObject.SetActive(false);
    siteButton.gameObject.SetActive(false);

    yield return new WaitForEndOfFrame();

    var preview = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
    preview.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
    preview.Apply();

    globalCanvas.enabled = true;

    if (currentMarker != null && !string.IsNullOrEmpty(currentMarker.site))
    {
        siteButton.gameObject.SetActive(true);
    }
    else
    {
        siteButton.gameObject.SetActive(false);
    }

    string screenName = "MoreGlobe_Screenshot_-" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".jpg";

    
    NativeGallery.SaveImageToGallery(preview, "Moreglobe", screenName, (success, path) =>
    {
        Debug.Log("Screenshot saved in gallery ");

        var popup = UIController.instance.CreateTutorialPopup();
        popup.initialize(
            UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[0]._title,
            GameData.instance.currentLanguage._popupTutorialJson[0]._message,
            2.5f
        );
    });

    yield return null;
}


    
    private IEnumerator askForDownload(string id)
    {
        if (string.IsNullOrEmpty(id)) //Non ha il contentID e quindi non si può scaricare
        {
            
            isBegin = true;
            Debug.Log($"🚀 ~ file: GameManager.cs:982 ~ isBegin:{currentMarker.name}");

            if (isFullScreen)
            {
                isFullScreen = false;
            }
            Debug.Log("🚀 ~ file: GameManager.cs:990 ~ StartCoroutine adRequest");
            StartCoroutine(adRequest(currentMarker.name));     
        }
        else
        {
            yield return getContentFromId(id);

            if (GameData.instance.loggedUser._associatedContent.Contains(id) && GameData.instance.availableDownloadedContent.containsDlc(id))
            {
                //l'ho già scaricato e lo avvio

                GameData.instance.selectedContentId = id;
                PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(tmpContent));
                PlayerPrefs.Save();

                if (tmpContent._isBrand)
                {
                    Debug.Log("is Brand");
                    CustomizationItem item = new CustomizationItem
                    {
                        _id = tmpContent._id,
                        _customPageLink = tmpContent._custom_page,
                        _footerImageLink = tmpContent._tabbar_logo,
                        _splashImageLink = tmpContent._splash_logo
                    };

                    handleCustomization(false, item);
                    yield return Utilities.donwloadLocallyImageAsBytes(tmpContent._splash_logo, Application.persistentDataPath, "customSplash.png");
                }
                else
                {
                    PlayerPrefs.DeleteKey("customContent");
                    PlayerPrefs.Save();
                }

                SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);

            }

            else
            {
                if (choice != null)
                {
                    Destroy(choice.gameObject);
                    choice = null;
                }

                choice = UIController.instance.CreateConnectPopup();
                choice.initialize(UIController.instance.mainCanvas,
                    tmpContent,
                    () =>
                    {
                        if (!PlayerPrefs.HasKey("framingTutorial"))
                        {
                            PlayerPrefs.SetInt("framingTutorial", 1);
                            PlayerPrefs.Save();
                        }
                        GameObject.Destroy(choice.gameObject);
                        cameraDevice.transform.parent.GetComponentInChildren<ImageTrackerFrameFilter>().enabled = false;
                        StartCoroutine(downloadDLC(tmpContent));
                    },
                    false
                );
            }
        }

    }

    private void handleCustomization(bool haveToDelete, CustomizationItem c = null)
    {
        if (haveToDelete)
        {
            if (PlayerPrefs.HasKey("customContent"))
            {
                GameData.instance.selectedCustomContent = null;
                PlayerPrefs.DeleteKey("customContent");
                PlayerPrefs.Save();
            }

            var file = Path.Combine(Application.persistentDataPath, "customSplash.png");
            if (File.Exists(file)) File.Delete(file);
        }

        else
        {
            if (c == null) return;

            GameData.instance.selectedCustomContent = c;
            PlayerPrefs.SetString("customContent", JsonUtility.ToJson(c));
            PlayerPrefs.Save();
            Debug.Log("custom salvato");
        }
    }

    private IEnumerator downloadDLC(Content c)
    {

        if (choice != null)
        {
            Destroy(choice.gameObject);
            choice = null;
        }

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._initializating);

        DLC dlc = new DLC(c._id);

        string requestData = GameData.instance.loggedUser._token + "/" + dlc._id + "/" + dlc._version;

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_AND_DOWNLOAD_DLC + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                Debug.LogError(www.error);
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }


            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    Content x = response._contents[0];

                    if (dlc._id.Equals(x._id))
                    {

                        waiting.destroy();

                        DownloadPopup downPopup = UIController.instance.CreateDownloadPopup();
                        downPopup.initialize(UIController.instance.mainCanvas);

                        yield return DownloadManager.downloadDLC(x, downPopup);

                        if (Directory.Exists(Path.Combine(SaveLoadManager.DLCPATH, dlc._id)))
                        {

                            dlc._version = x._version;
                            dlc._downloadDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                            if (!GameData.instance.loggedUser._associatedContent.Contains(dlc._id))
                                GameData.instance.loggedUser._associatedContent.Add(dlc._id);

                            if (!GameData.instance.availableDownloadedContent.containsDlc(dlc._id)) //Indica quali contenuti sono stati già scaricati e ne tiene traccia della versione
                            {
                                GameData.instance.availableDownloadedContent._dlcs.Add(dlc);

                                PlayerPrefs.SetString("availableContents", JsonUtility.ToJson(GameData.instance.availableDownloadedContent));
                                PlayerPrefs.Save();
                            }

                            yield return DownloadManager.UserDownloadDLC(dlc._id);

                            //GameData.instance.userDLCMap.Add(dlc._id, dlc);

                            //yield return GameData.instance.updateDLCAndSave();

                            //Analytics.instance.packageManaging(1,x._id);

                            GameData.instance.selectedContentId = x._id;
                            PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(x));
                            PlayerPrefs.Save();
                            OneSignal.User.AddTag("content-" + x._id, "1");

                            if (x._isBrand)
                            {
                                Debug.Log("is Brand");
                                CustomizationItem item = new CustomizationItem
                                {
                                    _id = x._id,
                                    _customPageLink = x._custom_page,
                                    _footerImageLink = x._tabbar_logo,
                                    _splashImageLink = x._splash_logo
                                };

                                handleCustomization(false, item);
                                yield return Utilities.donwloadLocallyImageAsBytes(x._splash_logo, Application.persistentDataPath, "customSplash.png");
                            }

                            SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);

                        }
                    }



                }

                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }

        }

        yield return null;
    }

    private IEnumerator getContentFromId(string id)
    {
        string requestData = GameData.instance.loggedUser._token + "/" + id + "/0";

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_AND_DOWNLOAD_DLC + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }


            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    tmpContent = response._contents[0];


                }

            }

        }
    }


    #endregion

    #region Getters

    //Getting methods
    public Marker getMarker()
    {
        return currentMarker;
    }

    public bool isInFullScreen()
    {
        return isFullScreen;
    }

    #endregion

    #region Extra / utility

    public void destroyChoicePanel()
    {
        if (choice != null)
        {
            Destroy(choice.gameObject);
            choice = null;
        }
    }

    public void setFocus(int status)
    {
        if (status == 0)
        {
            isOnfocus = false;
        }

        else
        {
            isOnfocus = true;
        }
    }

    public void makeFlash()
    {
        isFlashActive = !isFlashActive;
        cameraDevice.SetFlashTorch(isFlashActive);
    }


    public void goToMenu()
    {
        if (currentPlayer != null)
        {
            currentPlayer.Stop();
            _yp.Stop();
        }

        SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
    }

    public void goToWebView()
    {
        Analytics.instance.site(currentMarker.name, currentMarker.site, GameData.instance.sessionId + "");
        Application.OpenURL(currentMarker.site);
    }

    public void goToSpace3D()
    {
        if (!PlayerPrefs.HasKey("see3DSpaceTut"))
            PlayerPrefs.SetInt("see3DSpaceTut", 1);

        SceneManager.LoadScene("DemoSpaceVisualization", LoadSceneMode.Single);

    }

    public void switchCamera()
    {
        if (!cameraDevice || cameraDevice.Opened)
        {
            return;
        }
        if (CameraDeviceFrameSource.CameraCount == 0)
        {
            cameraDevice.Close();
            return;
        }
        Debug.Log("Aperta: " + cameraDevice.Index);

        var index = cameraDevice.Index;
        index = (index + 1) % CameraDeviceFrameSource.CameraCount;
        cameraDevice.CameraOpenMethod = CameraDeviceFrameSource.CameraDeviceOpenMethod.DeviceIndex;
        cameraDevice.CameraOpenIndex = index;

        cameraDevice.Close();
        cameraDevice.Open();

        Analytics.instance.cameraSwitch(index + 1, sessionId + "");
    }

    public void takeScreenshot()
    {

        StartCoroutine(takeShot());
    }


    #endregion  
#region iOS camera permission

    private IEnumerator getIosCameraPermission()
    {
        foreach (var device in WebCamTexture.devices) ;

        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
        if (Application.HasUserAuthorization(UserAuthorization.WebCam))
        {
            GameData.instance.appConfig._cameraPermission = true;
        }
        else
        {
            GameData.instance.appConfig._cameraPermission = false;
        }
    }

    #endregion
}
