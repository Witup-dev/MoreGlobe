﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.Networking;
using SimpleJSON;

public class JsonTest : MonoBehaviour
{



    // Start is called before the first frame update
    void Start()
    {

        string SAVINGPATH = Path.Combine(Application.persistentDataPath, "save");
        string THUMBNAILPATH = Path.Combine(Application.persistentDataPath, "thumbnail");
        string contentDataFile = "contents.txt";

        string link = "https://drive.google.com/uc?export=download&id=15ha3XhIMBqMj3epI4fKReneRX_AD8Z9F";

        string fullpath = Path.Combine(SAVINGPATH, contentDataFile);

        for (int i = 0; i < 50; i++)
        {
            Content c = new Content();
            c._id = "id"+i;
            c._downloadLink = link;

            StartCoroutine(downloadImage(c));
        }

        //MyUser x1 = new MyUser();
        //x1.nome = "alfonso";
        //x1.cognome = "menichino";
        //x1.eta = 26;

        //MyUser x2 = new MyUser();
        //x2.nome = "andrea";
        //x2.cognome = "palladio";
        //x2.eta = 26;

        //MyUser x3 = new MyUser();
        //x3.nome = "giovanni";
        //x3.cognome = "visone";
        //x3.eta = 33;

        //var n = new JSONObject();

        //var y = new JSONArray();
        //y.Add(JSONObject.Parse(JsonUtility.ToJson(x1)));
        //y.Add(JSONObject.Parse(JsonUtility.ToJson(x2)));
        //y.Add(JSONObject.Parse(JsonUtility.ToJson(x3)));
        

        //n["contents"] = y;


        //File.WriteAllText(fullpath, n.ToString());



        //if (File.Exists(fullpath))
        //{
        //    //load here
        //    string json = File.ReadAllText(fullpath);

        //    var list = new List<MyUser>();

        //    //JSONNode contents = JSONObject.Parse(json)["contents"];

        //    MyUserCollection z = JsonUtility.FromJson<MyUserCollection>(json);

        //    //for (int i = 0; i < z.contents.Count ; i++)
        //    //{

        //    //    list.Add(JsonUtility.FromJson<MyUser>(contents[i].ToString()));

        //    //}

        //    foreach(var x in z.contents)
        //    {
        //        Debug.Log(x.nome);
        //    }

        //}
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private IEnumerator downloadImage(Content c)
    {
        using (var www = UnityWebRequestTexture.GetTexture(c._downloadLink))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                if (www.isDone)
                {
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    File.WriteAllBytes(Path.Combine(SaveLoadManager.THUMBNAILPATH, c._id + ".jpg"), x.EncodeToJPG());
                }
            }
        }

        yield return null;
    }
}

[System.Serializable]
public class MyUserCollection
{
    public List<MyUser> contents;
}

[System.Serializable]
public class MyUser {

    public string nome;
    public string cognome;
    public int eta;

}

