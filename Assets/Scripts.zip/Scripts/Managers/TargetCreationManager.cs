using System.Collections;
using System.Collections.Generic;
using System;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using SimpleJSON;
using TMPro;
using easyar;
using Vuplex.WebView;
using OneSignalSDK;

public class TargetCreationManager : MonoBehaviour
{


    [Header("AR / Prefabs")]

    public ElementorModel elementorModel;
    private ImageTrackerFrameFilter tracker;
    public ARSession Session;
    public GameObject imageTargetPrefab;
    public GameObject webviewPrefab;
    public GameObject businessCardPrefab;
    public RenderTexture texturePrefab;



    [Header("Graphics / Sprites")]

    public Sprite loadingImage;
    public Sprite errorImage;
    private Sprite tmpMask;





    [Header("Content / Experience State")] 

    private string SelectedContentId;
    private Content tmpContent;
    private bool currentExperienceIsSpartial;
    PopupConnect choice;




    #region Unity Lifecycle

    private void Awake()
    {

        tracker = Session.GetComponentInChildren<ImageTrackerFrameFilter>();

        tmpMask = null;

        SelectedContentId = GameData.instance.selectedContentId;


    }

    // Start is called before the first frame update
    void Start()
    {
        tmpContent = null;
        OfflineGameManager.instance.targetManagerInstance = this;
        if (PlayerPrefs.HasKey("NFC_ID"))
        {
            if (!string.IsNullOrEmpty(PlayerPrefs.GetString("NFC_ID")))
            {
                Debug.Log("finalmente nfc experience!");
                StartCoroutine(buildNfcExperience(PlayerPrefs.GetString("NFC_ID")));
                // StartCoroutine(buildExperience(controller, controller.gameObject.name, null, GameData.instance.NfcTagId));
            }
        }
        StartCoroutine(createImageTargets());

    }

    //C: qui inizia la funzione da dove prende i marker
    private IEnumerator createImageTargets()
    {
        //C: SaveLoadManager.DLCPATH / SelectedContentId / marker
        DirectoryInfo dir = new DirectoryInfo(Path.Combine(SaveLoadManager.DLCPATH, SelectedContentId, "marker"));
        FileInfo[] info = dir.GetFiles();

        foreach (FileInfo x in info)
        {
            bool firstTime = true;

            string markerName = x.Name.Split('.')[0];


            var target = new GameObject(markerName);
            //C: for every img crea un ImageTargetController e lo usa come marker di EasyAR.
            target.AddComponent<ImageTargetController>();
            ImageTargetController controller = target.GetComponent<ImageTargetController>();
            
            //EasyAR 4.4
            //controller.ImageFileSource.Name = markerName;
            //controller.HorizontalFlip = false;
            //controller.ImageFileSource.PathType = PathType.Absolute;
            //controller.ImageFileSource.Path = Path.Combine(SaveLoadManager.DLCPATH, SelectedContentId, "marker", x.Name);
            //controller.ImageFileSource.Scale = 10;
            
            //EasyAR 4000.0.1 - inizio
            controller.Tracker = tracker;
            controller.Source = new ImageTargetController.ImageFileSourceData
            {
                PathType = PathType.Absolute,
                Path = Path.Combine(SaveLoadManager.DLCPATH, SelectedContentId, "marker", x.Name),
                Name = markerName,
                Scale = 10,
                
            };
            //EasyAR 4000.0.1 - fine

            //Build the correct marker. For Model or for VideoPlayer



            controller.TargetFound += () =>
            {

                if (firstTime)
                {
                    firstTime = false;
                    StartCoroutine(buildUpMaker(markerName, controller));
                }

                OfflineGameManager.instance.imageTargetController = controller;

            };

            // controller.TargetLost += () =>
            // {
            //     if (OfflineGameManager.instance.isExperience)
            //         OfflineGameManager.instance.MarkerToSpatial(currentExperienceIsSpartial);
            // };

            yield return null;
        }


    }

    #endregion
    #region Marker Creation

    public IEnumerator createTarget(ImageTargetController oldController)
    {
        bool firstTime = true;
        var target = new GameObject(oldController.gameObject.name);
        target.AddComponent<ImageTargetController>();

        ImageTargetController controller = target.GetComponent<ImageTargetController>();

        //EasyAR 4.4
        //controller.ImageFileSource.Name = oldController.gameObject.name;
        //controller.HorizontalFlip = false;
        //controller.ImageFileSource.PathType = PathType.Absolute;
        //controller.ImageFileSource.Path = oldController.ImageFileSource.Path;
        //controller.Tracker = oldController.Tracker;

        //EasyAR 4000.0.1 - inizio
        ImageTargetController.ImageFileSourceData file = (ImageTargetController.ImageFileSourceData)oldController.Source;
        string path = file.Path;
        Debug.Log(path);

        controller.Tracker = oldController.Tracker;
        controller.Source = new ImageTargetController.ImageFileSourceData
        {
            PathType = PathType.Absolute,
            Path = path,
            Name = oldController.gameObject.name,            
        };
        //EasyAR 4000.0.1 - fine

        Destroy(oldController.gameObject);

        controller.TargetFound += () =>
        {
            Debug.Log("createImageTarget: targetfound");

            if (firstTime)
            {
                firstTime = false;
                StartCoroutine(buildUpMaker(target.name, controller));
            }

        };

        yield return null;
    }


    IEnumerator buildUpMaker(string name, ImageTargetController controller)
    {

        Marker currentMarker = null;

        string os = "";

        #if UNITY_IOS
                os = "ios";
        #endif
        #if UNITY_ANDROID

                os = "android";
        #endif

  //C:  da qui prende i dati del marker(video ecc) facendo una chiamata  GET a APIs.TAKE_MARKER_METADATA,ricevendo un JSON MetadataResponse e poi in base al marker decide che caricare

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.TAKE_MARKER_METADATA + GameData.instance.loggedUser._token + "/" + name + Analytics.getCoordinate() + "?device=" + os))
        {
            Debug.Log($"Test {APIs.TAKE_MARKER_METADATA + GameData.instance.loggedUser._token + "/" + name + Analytics.getCoordinate() + "?device=" + os}");
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                //Video paracadute mp4
                currentMarker = Marker.getDefaultMarker(); // aggiungere il link mp4 paracadute nel metodo
            }


            else
            {
                Debug.Log($"www.downloadHandler.text {www.downloadHandler.text}");
                MetadataResponse response = JsonUtility.FromJson<MetadataResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    //Debug.Log("metadata: " + JsonUtility.ToJson(response._metadata));

                    currentMarker = response._metadata;

                    Debug.Log($"🚀 ~ file: TargetCreationManager.cs:163 ~ currentMarker.type: {currentMarker.type}");
                    if (!string.IsNullOrEmpty(currentMarker.type) && currentMarker.type.Equals("businesscard"))
                    {
                        StartCoroutine(buildBusinessCardExperience(controller, currentMarker));
                    }
                    else if (!string.IsNullOrEmpty(currentMarker.type) && currentMarker.type.Equals("experience"))
                    {
                        OfflineGameManager.instance.isExperience = true;
                        StartCoroutine(buildExperience(controller, currentMarker));
                    }
                    else if (currentMarker.isComboExperience) //Combo 3D + video   !string.IsNullOrEmpty(currentMarker.is3D) && !string.IsNullOrEmpty(currentMarker.url)
                    {
                        StartCoroutine(buildComboExperience(controller, currentMarker));
                    }

                    else if (!string.IsNullOrEmpty(currentMarker.is3D))
                    {
                        StartCoroutine(get3DModel(controller, currentMarker)); // Has a model so handle the model

                    }

                    else if (!string.IsNullOrEmpty(currentMarker.type) && currentMarker.type.Equals("webview"))
                    {
                        buildWebViewTesting(controller, currentMarker);

                    }

                    else
                    {
                        if (!string.IsNullOrEmpty(currentMarker.mask))
                        {
                            yield return downloadMask(currentMarker.mask); // Has a mask so I download the mask
                        }
                        else
                        {
                            tmpMask = null;
                        }

                        if (GameData.instance.webviewForVideo && currentMarker.isYoutube)
                        {
                            Debug.Log("🚀 ~ file: TargetCreationManager.cs:203 ~ buildWebViewPlayer");
                            buildWebViewPlayer(controller, currentMarker);
                        }

                        else
                        {
                            Debug.Log($"🚀 ~ file: TargetCreationManager.cs:208 ~ buildVideoPlayer");
                            buildVideoPlayer(controller, currentMarker);
                            
                        }

                    }


                }

            }

        }

        yield return null;
    }



    #endregion
    #region Marker Experiences

    private IEnumerator buildComboExperience(ImageTargetController controller, Marker currentMarker)
    {

        //Far apparire la webview

        if (!string.IsNullOrEmpty(currentMarker.mask))
        {
            yield return downloadMask(currentMarker.mask); // Has a mask so I download the mask
        }
        else
        {
            tmpMask = null;
        }

        if (currentMarker.isYoutube)
        {
            buildWebviewForCombo(controller, currentMarker);
        }

        else
        {
            buildVideoPlayerForCombo(controller, currentMarker);
        }

        yield return null;
    }

    private IEnumerator buildBusinessCardExperience(ImageTargetController controller, Marker marker)
    {
        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(marker.name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.GET_BUSINESS_CARD + marker.name))
        {

            yield return www.SendWebRequest();


            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log($"business error: {www.error}");
            }


            else
            {
                BusinessCardResponse response = JsonUtility.FromJson<BusinessCardResponse>(www.downloadHandler.text);


                if (response._success)
                {

                    var bc = response._data;

                    var prefab = Instantiate(businessCardPrefab as GameObject, controller.transform);

                    CanvasWebViewPrefab webview = null;

                    var behav = prefab.GetComponentInChildren<BusinessCardBehaviour>();
                    behav.first_line.text = bc._first_line;
                    behav.second_line.text = bc._second_line;

                    if (!string.IsNullOrEmpty(bc._video_url))
                    {
                        behav.player.url = bc._video_url;
                    }

                    yield return Utilities.getImageAndApply(bc._image, behav.profileImage, loadingImage, errorImage);

                    behav.webviewContainer.parent.GetComponent<Canvas>().worldCamera = Camera.main;

                    //setting the 5 buttons on bottom
                    for (var i = 0; i < bc._actions.Count; i++)
                    {
                        yield return Utilities.getImageAndApply(bc._actions[i]._image, behav.actionButtons[i].GetComponent<UnityEngine.UI.Image>(), loadingImage, errorImage);
                        behav.actionButtons[i].gameObject.SetActive(true);
                        assignBehaviourForBusinessCard(behav.actionButtons[i], bc._actions[i], false);
                    }

                    //setting the 3 buttons near the video
                    for (var i = 0; i < bc._functions.Count; i++)
                    {
                        yield return Utilities.getImageAndApply(bc._functions[i]._image, behav.functionButtons[i].GetComponent<UnityEngine.UI.Image>(), loadingImage, errorImage);
                        behav.functionButtons[i].gameObject.SetActive(true);
                        assignBehaviourForBusinessCard(behav.functionButtons[i], bc._functions[i], true, webview, behav);
                    }



                    controller.TargetFound += () =>
                    {
                        OfflineGameManager.instance.connectionPopupActivator = true;

                        if (!string.IsNullOrEmpty(behav.player.url) && !behav.isVideoPlaying && behav.isVideoReady)
                        {
                            behav.player.Play();
                        }

                    };

                    controller.TargetLost += () =>
                    {
                        OfflineGameManager.instance.connectionPopupActivator = false;
                        OfflineGameManager.instance.resetTimer();

                        if (!string.IsNullOrEmpty(behav.player.url))
                        {
                            behav.player.Pause();
                            behav.isVideoPlaying = false;
                        }
                    };

                    Analytics.instance.model3D(marker.name, string.Empty, GameData.instance.sessionId + "");

                    behav.initialize();

                }

            }

        }


        yield return null;
    }

    private IEnumerator buildExperience(ImageTargetController controller, Marker marker)
    {
        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(marker.name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }

        using (UnityWebRequest www = UnityWebRequest.Get($"https://arstudio.moreglobe.com/api/experience?id_experience={marker.id_experience}"))
        {

            yield return www.SendWebRequest();


            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log($"business error: {www.error}");
            }
            else
            {
                ElementorInfo response = ElementorInfo.CreateFromJSON(www.downloadHandler.text);

                if (response._success)
                {
                    OfflineGameManager.instance.isFrameSomething = true;

                    currentExperienceIsSpartial = response._switchSpatial;
                    Debug.Log($"experience id: {response.items[0].id_experience}");
                    elementorModel.EntityInstantiate(response.items, controller);
                    controller.TargetLost += () =>
                                        {
                                            if (currentExperienceIsSpartial)
                                                OfflineGameManager.instance.MarkerToSpatial(currentExperienceIsSpartial);
                                        };

                }
            }

        }


        yield return null;
    }

    private IEnumerator buildNfcExperience(string id)
    {
        WWWForm form = new WWWForm();

        form.AddField("id_bracelet", id);
        yield return new WaitForEndOfFrame();
        using (UnityWebRequest www = UnityWebRequest.Post($"https://arstudio.moreglobe.com/api/bracelet/288e51eef3bb57e77abbbb8ad7948fea", form))
        {

            yield return www.SendWebRequest();


            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log($"business error: {www.error}");
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    "NFC Tag Request Error",
                    www.error,
                    "Continue",
                    "error");
            }


            else
            {
                Debug.Log(($"nfc request {www.downloadHandler.text}"));
                ElementorInfo response = ElementorInfo.CreateFromJSON(www.downloadHandler.text);

                Debug.Log($"4");

                if (response._success)
                {

                    Debug.Log($"5");
                    OfflineGameManager.instance.isFrameSomething = true;

                    Debug.Log($"6");
                    currentExperienceIsSpartial = response._switchSpatial;

                    Debug.Log($"7");
                    elementorModel.EntityInstantiate(response.items, isNfc: true);

                    Debug.Log($"8");
                }
                else
                {
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        "NFC Tag Error",
                        response._message,
                        "Continue",
                        "error");
                }
            }

        }

        PlayerPrefs.DeleteKey("NFC_ID");
        yield return null;
    }



    #endregion
    #region Business Card / Embedded Webview

    private void createWebViewForBusinessCard(CanvasWebViewPrefab webview, BusinessCardBehaviour behav, string url)
    {

        if (webview == null)
        {
            Web.SetAutoplayEnabled(true);
            Web.SetUserAgent(true);

            webview = CanvasWebViewPrefab.Instantiate();
            webview.transform.SetParent(behav.webviewContainer);
            var rectTransform = webview.transform as RectTransform;
            rectTransform.anchoredPosition3D = Vector3.zero;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
            webview.Resolution = 13;
            webview.transform.localScale = Vector3.one;

            webview.Initialized += (sender, e) =>
            {
                Web.SetAutoplayEnabled(true);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif

webview.WebView.LoadUrl(url);


            };

            behav.openWebView();

        }

        else
        {
            webview.WebView.LoadUrl(url);

            behav.openWebView();
        }



    }


    private void assignBehaviourForBusinessCard(Button button, BusinessCardAction action, bool isFunction, CanvasWebViewPrefab webview = null, BusinessCardBehaviour behav = null)
    {
        if (isFunction)
        {
            button.gameObject.GetComponentInChildren<TextMeshProUGUI>().text = string.IsNullOrEmpty(action._text) ? string.Empty : action._text;
        }

        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() =>
        {

            switch (action._action)
            {
                case "whatsapp":
                    Application.OpenURL($"https://api.whatsapp.com/send?phone={action._value}&text={string.Empty}");
                    break;
                case "mail":
                    Application.OpenURL($"mailto:{action._value}");
                    break;
                case "dial":
                    Application.OpenURL($"tel://{action._value}");
                    break;
                case "maps":
#if UNITY_IOS
                    Application.OpenURL($"maps://maps.google.com/maps?daddr={action._value}&amp;ll=");
#endif
#if UNITY_ANDROID

                    Application.OpenURL($"https://maps.google.com/maps?daddr={action._value}&amp;ll=");
#endif
                    break;
                case "link":
                    bool external = action._external.Equals("0") ? false : true;
                    if (external)
                    {
                        Application.OpenURL(action._value);
                    }
                    else
                    {
                        createWebViewForBusinessCard(webview, behav, action._value);
                        behav.expandButton.onClick.RemoveAllListeners();
                        behav.expandButton.onClick.AddListener(() =>
                        {
                            Application.OpenURL(action._value);
                        });
                    }

                    break;
                case "project":
                    StartCoroutine(askForDownload(action._value));
                    break;
                default:
                    break;
            }


        });




    }

    
    #endregion
    #region Video / Webview (Combo & Single)



    private void buildVideoPlayerForCombo(ImageTargetController controller, Marker marker)
    {

        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(marker.name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }


        var prefab = Instantiate(imageTargetPrefab) as GameObject;
        prefab.transform.parent = controller.transform;
        prefab.transform.localPosition = new Vector3(0, 0, 0);
        prefab.transform.localScale = new Vector3(1, 1, 1);

        prefab.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

        if (marker.tvMode)
        {
            adjustScreen(prefab.transform, controller);
        }

        var info = prefab.AddComponent<TargetHandler>();
        info.setMarker(marker);
        info.texturePrefab = texturePrefab;

        var player = prefab.GetComponentInChildren<UnityEngine.Video.VideoPlayer>();

        player.targetCamera = Camera.main;

        if (marker.mask != "")
        {
            var panelImage = prefab.GetComponentInChildren<UnityEngine.UI.Image>();
            var panelMask = prefab.GetComponentInChildren<Mask>();

            panelImage.color = new Color(1, 1, 1, 1);

            panelImage.sprite = tmpMask;

            panelMask.enabled = true;
        }

        RenderTexture videoTexture = new RenderTexture(texturePrefab);
        player.GetComponent<RawImage>().texture = videoTexture;
        player.targetTexture = videoTexture;

        OfflineGameManager.instance.resetBadConnectionTimer();
        OfflineGameManager.instance.startToCountdownForBadConnection =
            OfflineGameManager.instance.connectionPopupActivator = true;



        info.initMarkerTarget();
        MuteMarker(controller, marker);
    }

    private void buildWebviewForCombo(ImageTargetController controller, Marker marker)
    {
        var prefab = Instantiate(webviewPrefab) as GameObject;
        prefab.transform.SetParent(controller.transform);
        prefab.transform.localPosition = new Vector3(0, 0, 0);
        prefab.transform.localScale = new Vector3(1, 1, 1);

        var info = prefab.AddComponent<TargetHandler>();
        info.setMarker(marker);

        CanvasWebViewPrefab webview = null;

        info.transform.GetChild(0).GetComponent<Canvas>().worldCamera = Camera.main;
        prefab.transform.GetChild(0).GetChild(0).gameObject.SetActive(false);

        webview = CanvasWebViewPrefab.Instantiate();

        webview.transform.SetParent(controller.transform.GetChild(0).GetChild(0).GetChild(1).transform);

        prefab.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

        if (marker.tvMode)
        {
            adjustScreen(prefab.transform, controller, webview);
        }

        var rectTransform = webview.transform as RectTransform;
        rectTransform.anchoredPosition3D = Vector3.zero;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        webview.Resolution = 1300;
        webview.transform.localScale = Vector3.one;

        OfflineGameManager.instance.resetBadConnectionTimer();
        OfflineGameManager.instance.startToCountdownForBadConnection =
            OfflineGameManager.instance.connectionPopupActivator = true;


        prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 0;

        webview.Initialized += (sender, e) =>
        {
            Web.SetAutoplayEnabled(true);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif

            //Gestione Maschera
            if (marker.mask != "")
            {
                var panelImage = prefab.transform.GetChild(0).GetChild(1).GetComponentInChildren<UnityEngine.UI.Image>();
                var panelMask = prefab.transform.GetChild(0).GetChild(1).GetComponentInChildren<Mask>();

                panelImage.color = new Color(1, 1, 1, 1);

                panelImage.sprite = tmpMask;

                panelMask.enabled = true;
            }



            //È una pagina web?
            if (!marker.isWebPage) //no
            {

                if (!controller.IsTracked)
                {
                    Debug.Log("entro in IsTracked");
                    StartCoroutine(createTarget(controller));
                    OfflineGameManager.instance.startToCountdownForBadConnection = false;
                    if (OfflineGameManager.instance.connectionPopup != null)
                    {
                        OfflineGameManager.instance.connectionPopup.destroy();
                    }


                    OfflineGameManager.instance.connectionPopupActivator = false;
                }

                else
                {
                    if (GameData.instance.fullScreenVideoMarker != null && (GameData.instance.fullScreenVideoMarker.url).Equals(marker.url))
                    {
                        var splitted = GameData.instance.fullScreenVideoMarker.url.Split(new char[] { '?', '&' }); //[1] = start, [2] = end, [3] = fullscreen, [4] = id

                        string newUri = splitted[0] + "?start=" + GameData.instance.fullScreenTimeToResume + "&" + splitted[2] + "&fullscreen=1&" + splitted[4];
                        webview.WebView.LoadUrl(newUri);
                    }

                    else
                    {
                        webview.WebView.LoadUrl(marker.url);
                    }
                }

                //Message emitted
                webview.WebView.MessageEmitted += (sender2, eventArgs2) =>
                {
                    //Debug.Log("received from WebView: " + eventArgs2.Value);

                    var jobj = JSON.Parse(eventArgs2.Value);


                    if (jobj["type"].Equals("play"))
                    {
                        //    Debug.Log("json ricevuto play: " + eventArgs2.Value);
                        //    Debug.Log("time ricevuto play: " + int.Parse(jobj["value"]));
                        OfflineGameManager.instance.buttonDoPlayPause(true);
                        Analytics.instance.videoAction(1, marker.name, 1, (int)jobj["value"], GameData.instance.sessionId + ""); //1 play - 2 pause
                    }

                    else if (jobj["type"].Equals("pause"))
                    {
                        //    Debug.Log("json ricevuto pause: " + eventArgs2.Value);
                        //    Debug.Log("time ricevuto pause: " + int.Parse(jobj["value"]));
                        OfflineGameManager.instance.buttonDoPlayPause(false);
                        Analytics.instance.videoAction(2, marker.name, 1, (int)jobj["value"], GameData.instance.sessionId + ""); //1 play - 2 pause
                    }

                    else if (jobj["type"].Equals("time"))
                    {
                        GameData.instance.fullScreenVideoMarker = marker;
                        GameData.instance.fullScreenTimeToResume = (int)jobj["value"];

                        prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 0;

                        StartCoroutine(loadAsyncScene("FullScreenVideoScene"));

                        //Debug.Log("time ricevuto: " + (int)jobj["value"]);
                    }

                    else if (jobj["type"].Equals("combo"))
                    {
                        if (!controller.IsTracked)
                        {
                            OfflineGameManager.instance.connectionPopupActivator = false;
                            if (OfflineGameManager.instance.connectionPopup != null)
                            {
                                OfflineGameManager.instance.connectionPopup.destroy();
                            }
                            StartCoroutine(createTarget(controller));
                        }

                        else
                        {
                            if (!PlayerPrefs.HasKey("framingTutorial"))
                            {
                                PlayerPrefs.SetInt("framingTutorial", 1);
                                PlayerPrefs.Save();
                            }

                            if (!info.initialized)
                            {
                                info.initialized = true;
                                StartCoroutine(OfflineGameManager.instance.targetManagerInstance.get3DModelForCombo(controller, marker));
                            }


                            OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                        }

                        OfflineGameManager.instance.startToCountdownForBadConnection = false;
                        OfflineGameManager.instance.connectionPopupActivator = false;

                        OfflineGameManager.instance.resetBadConnectionTimer();

                        if (OfflineGameManager.instance.connectionPopup != null)
                        {
                            OfflineGameManager.instance.connectionPopup.destroy();
                        }
                    }

                    else if (jobj["type"].Equals("status"))
                    {
                        //Debug.Log("status ricevuto: " + (int)jobj["value"]);

                        if ((int)jobj["value"] == 1)
                        {
                            //Debug.Log("status 1: attivo il canvas della combo");

                            //if (!controller.IsTracked)
                            //{
                            //    Debug.Log("status 1");
                            //    OfflineGameManager.instance.connectionPopupActivator = false;
                            //    if (OfflineGameManager.instance.connectionPopup != null)
                            //    {
                            //        OfflineGameManager.instance.connectionPopup.destroy();
                            //    }
                            //    StartCoroutine(createTarget(controller));
                            //}

                            //else
                            //{
                            //    if (!PlayerPrefs.HasKey("framingTutorial"))
                            //    {
                            //        PlayerPrefs.SetInt("framingTutorial", 1);
                            //        PlayerPrefs.Save();
                            //    }

                            //    if (!info.initialized)
                            //    {
                            //        info.initialized = true;
                            //        StartCoroutine(OfflineGameManager.instance.targetManagerInstance.get3DModelForCombo(controller, marker));
                            //    }


                            //    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                            //}

                            //OfflineGameManager.instance.startToCountdownForBadConnection = false;
                            //OfflineGameManager.instance.connectionPopupActivator = false;

                            //OfflineGameManager.instance.resetBadConnectionTimer();

                            //if (OfflineGameManager.instance.connectionPopup != null)
                            //{
                            //    OfflineGameManager.instance.connectionPopup.destroy();
                            //}

                        }


                    }

                };



            }

            else //si
            {

                Debug.Log("entro in isWebPage");
                webview.WebView.LoadUrl(marker.url);
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 1;

            }

        };



        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(info.getMarker().name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }

        info.initMarkerTarget();

        controller.TargetFound += () =>
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
            }
            OfflineGameManager.instance.connectionPopupActivator = true;

            //Se quello attuale è diverso da quello di prima distruggi il marker di prima
            if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(info.getMarker().name))
            {
                StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
            }

            if (webview.WebView.IsInitialized)
            {
                webview.WebView.SetRenderingEnabled(true);
            }

            webview.WebView.PostMessage(string.Format(
                    "{{ \"type\": \"play\"}}"));

            if (!info.getMarker().isWebPage)
            {
                OfflineGameManager.instance.sideMenu.show();
                OfflineGameManager.instance.buttonDoPlayPause(true);
            }


        };

        controller.TargetLost += () =>
        {

            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
                OfflineGameManager.instance.resetBadConnectionTimer();
            }


            OfflineGameManager.instance.connectionPopupActivator = false;

            OfflineGameManager.instance.sideMenu.hide();
            OfflineGameManager.instance.buttonDoPlayPause(false);

            if (info.getMarker().isWebPage)
            {
                StartCoroutine(createTarget(info.controller));
                return;
            }

            else
            {
                if (webview.WebView.IsInitialized)
                {
                    webview.WebView.SetRenderingEnabled(false);
                }

                webview.WebView.PostMessage(string.Format(
                                "{{ \"type\": \"pause\"}}"));
                webview.WebView.PostMessage(string.Format(
                                "{{ \"type\": \"pause\"}}"));
            }

        };
    }

    public IEnumerator get3DModelForCombo(ImageTargetController controller, Marker marker)
    {

        var associatedHandler = controller.GetComponentInChildren<TargetHandler>();

        OfflineGameManager.instance.sideMenu.hide();

        string bundleURL = marker.is3D + "-";

#if UNITY_ANDROID
        bundleURL += "Android";
#else
        bundleURL += "IOS";
#endif


        if (OfflineGameManager.instance.downloadInProgress) //Abort previous
        {
            OfflineGameManager.instance.inProgressRequest.webRequest.Abort();
        }


        using (UnityWebRequest www = UnityWebRequestAssetBundle.GetAssetBundle(bundleURL))
        {
            OfflineGameManager.instance.downloadAborted = false;

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success || OfflineGameManager.instance.downloadAborted)
            {
                Debug.Log(www.error);
                StartCoroutine(createTarget(controller));
            }

            else
            {
                AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(www);

                if (bundle != null)
                {
                    OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                    Analytics.instance.model3D(marker.name, string.Empty, GameData.instance.sessionId + "");

                    string rootAssetPath = bundle.GetAllAssetNames()[0];
                    GameObject arObject = Instantiate(bundle.LoadAsset(rootAssetPath) as GameObject, controller.transform);

                    if (!marker.isYoutube)
                    {
                        if (controller.transform.GetChild(0).childCount >= 5)
                            Destroy(controller.transform.GetChild(0).GetChild(4).gameObject);
                    }

                    else
                    {
                        if (controller.transform.GetChild(0).childCount >= 2)
                            Destroy(controller.transform.GetChild(0).GetChild(1).gameObject);
                    }

                    associatedHandler._anim = arObject.GetComponentInChildren<Animator>();

                    bundle.Unload(false);

                    OfflineGameManager.instance.isFrameSomething = true;

                    controller.TargetLost += () =>
                    {

                        if (arObject != null && arObject.GetComponentInChildren<AudioSource>() != null)
                        {
                            var audio = arObject.GetComponentInChildren<AudioSource>();

                            audio.Pause();
                            Destroy(audio);

                        }

                    };

                }
                else
                {
                    StartCoroutine(createTarget(controller));
                }
            }

        }
    }
    

    private void buildVideoPlayer(ImageTargetController controller, Marker marker)
    {

        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(marker.name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }


        var prefab = Instantiate(imageTargetPrefab) as GameObject;
        prefab.transform.parent = controller.transform;
        prefab.transform.localPosition = new Vector3(0, 0, 0);
        prefab.transform.localScale = new Vector3(1, 1, 1);

        prefab.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());
        Debug.Log($"🚀 ~ file: TargetCreationManager.cs:1079 ~ marker: {marker}");
        Debug.Log($"🚀 ~ file: TargetCreationManager.cs:1079 ~ marker URL: {marker.url}");
        if (marker.tvMode)
        {
            adjustScreen(prefab.transform, controller);
        }

        var info = prefab.AddComponent<TargetHandler>();
        info.setMarker(marker);
        info.texturePrefab = texturePrefab;

        var player = prefab.GetComponentInChildren<UnityEngine.Video.VideoPlayer>();

        MuteMarker(controller, marker);
        player.targetCamera = Camera.main;

        if (marker.mask != "")
        {
            var panelImage = prefab.GetComponentInChildren<UnityEngine.UI.Image>();
            var panelMask = prefab.GetComponentInChildren<Mask>();

            panelImage.color = new Color(1, 1, 1, 1);

            panelImage.sprite = tmpMask;

            panelMask.enabled = true;
        }

        RenderTexture videoTexture = new RenderTexture(texturePrefab);
        player.GetComponent<RawImage>().texture = videoTexture;
        player.targetTexture = videoTexture;

        OfflineGameManager.instance.resetBadConnectionTimer();
        OfflineGameManager.instance.startToCountdownForBadConnection =
        OfflineGameManager.instance.connectionPopupActivator = true;


        info.initMarkerTarget();

    }


    private void buildWebViewPlayer(ImageTargetController controller, Marker marker)
    {

        Debug.Log("entra in webb");
        var prefab = Instantiate(webviewPrefab) as GameObject;
        prefab.transform.SetParent(controller.transform);
        prefab.transform.localPosition = new Vector3(0, 0, 0);
        prefab.transform.localScale = new Vector3(1, 1, 1);

        var info = prefab.AddComponent<TargetHandler>();
        info.setMarker(marker);

        CanvasWebViewPrefab webview = null;

        info.transform.GetChild(0).GetComponent<Canvas>().worldCamera = Camera.main;
        prefab.transform.GetChild(0).GetChild(0).gameObject.SetActive(false);

        webview = CanvasWebViewPrefab.Instantiate();

        webview.transform.SetParent(controller.transform.GetChild(0).GetChild(0).GetChild(1).transform);

        prefab.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

        if (marker.tvMode)
        {
            adjustScreen(prefab.transform, controller, webview);
        }

        var rectTransform = webview.transform as RectTransform;
        rectTransform.anchoredPosition3D = Vector3.zero;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        webview.Resolution = 1300;
        webview.transform.localScale = Vector3.one;


        OfflineGameManager.instance.resetBadConnectionTimer();
        OfflineGameManager.instance.startToCountdownForBadConnection =
            OfflineGameManager.instance.connectionPopupActivator = true;

        webview.Initialized += (sender, e) =>
        {
            Web.SetAutoplayEnabled(true);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif

            //Gestione Maschera
            if (marker.mask != "")
            {
                var panelImage = prefab.transform.GetChild(0).GetChild(1).GetComponentInChildren<UnityEngine.UI.Image>();
                var panelMask = prefab.transform.GetChild(0).GetChild(1).GetComponentInChildren<Mask>();

                panelImage.color = new Color(1, 1, 1, 1);

                panelImage.sprite = tmpMask;

                panelMask.enabled = true;

            }



            //È una pagina web?
            if (!marker.isWebPage) //no
            {

                if (!controller.IsTracked)
                {
                    StartCoroutine(createTarget(controller));
                    OfflineGameManager.instance.startToCountdownForBadConnection = false;
                    if (OfflineGameManager.instance.connectionPopup != null)
                    {
                        OfflineGameManager.instance.connectionPopup.destroy();
                    }


                    OfflineGameManager.instance.connectionPopupActivator = false;
                }

                else
                {
                    if (GameData.instance.fullScreenVideoMarker != null && (GameData.instance.fullScreenVideoMarker.url).Equals(marker.url))
                    {
                        var splitted = GameData.instance.fullScreenVideoMarker.url.Split(new char[] { '?', '&' }); //[1] = start, [2] = end, [3] = fullscreen, [4] = id

                        string newUri = splitted[0] + "?start=" + GameData.instance.fullScreenTimeToResume + "&" + splitted[2] + "&fullscreen=1&" + splitted[4];
                        webview.WebView.LoadUrl(newUri);
                    }

                    else
                    {
                        webview.WebView.LoadUrl(marker.url);
                    }
                }


                webview.WebView.MessageEmitted += (sender2, eventArgs2) =>
                {
                    Debug.Log("received from WebView: " + eventArgs2.Value);

                    var jobj = JSON.Parse(eventArgs2.Value);


                    if (jobj["type"].Equals("play"))
                    {
                        //Debug.Log("json ricevuto play: " + eventArgs2.Value);
                        //Debug.Log("time ricevuto play: " + int.Parse(jobj["value"]));
                        OfflineGameManager.instance.buttonDoPlayPause(true);
                        Analytics.instance.videoAction(1, marker.name, 1, (int)jobj["value"], GameData.instance.sessionId + ""); //1 play - 2 pause
                    }

                    else if (jobj["type"].Equals("pause"))
                    {
                        //Debug.Log("json ricevuto pause: " + eventArgs2.Value);
                        //Debug.Log("time ricevuto pause: " + int.Parse(jobj["value"]));
                        OfflineGameManager.instance.buttonDoPlayPause(false);
                        Analytics.instance.videoAction(2, marker.name, 1, (int)jobj["value"], GameData.instance.sessionId + ""); //1 play - 2 pause
                    }

                    else if (jobj["type"].Equals("time"))
                    {
                        GameData.instance.fullScreenVideoMarker = marker;
                        GameData.instance.fullScreenTimeToResume = (int)jobj["value"];

                        prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 0;

                        StartCoroutine(loadAsyncScene("FullScreenVideoScene"));

                        //Debug.Log("time ricevuto: " + (int)jobj["value"]);
                    }

                    else if (jobj["type"].Equals("status"))
                    {
                        Debug.Log("status ricevuto: " + (int)jobj["value"]);

                        if ((int)jobj["value"] == 1)
                        {
                            Debug.Log($"status value {jobj["value"]}");
                            if (!controller.IsTracked)
                            {
                                OfflineGameManager.instance.connectionPopupActivator = false;
                                if (OfflineGameManager.instance.connectionPopup != null)
                                {
                                    OfflineGameManager.instance.connectionPopup.destroy();
                                }
                                StartCoroutine(createTarget(controller));
                            }

                            else
                            {
                                if (prefab.transform.GetChild(1).gameObject != null)
                                    Destroy(prefab.transform.GetChild(1).gameObject);

                                if (!PlayerPrefs.HasKey("framingTutorial"))
                                {
                                    PlayerPrefs.SetInt("framingTutorial", 1);
                                    PlayerPrefs.Save();
                                }

                                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                                OfflineGameManager.instance.sideMenu.show();
                                OfflineGameManager.instance.sideMenu.firstOpen();
                                OfflineGameManager.instance.buttonDoPlayPause(true);
                                prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 1;
                                //prefab.transform.GetChild(0).GetChild(0).gameObject.SetActive(false);
                                var can = webview.GetComponentInParent<Canvas>().GetComponent<RectTransform>();
                            }

                            OfflineGameManager.instance.startToCountdownForBadConnection = false;
                            OfflineGameManager.instance.connectionPopupActivator = false;

                            OfflineGameManager.instance.resetBadConnectionTimer();

                            if (OfflineGameManager.instance.connectionPopup != null)
                            {
                                OfflineGameManager.instance.connectionPopup.destroy();
                            }

                        }


                    }

                };



            }

            else //si
            {
                webview.WebView.LoadUrl(marker.url);
                OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(true);
                prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 1;

            }


        };



        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(info.getMarker().name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }

        info.initMarkerTarget();

        controller.TargetFound += () =>
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
            }
            OfflineGameManager.instance.connectionPopupActivator = true;

            //Se quello attuale è diverso da quello di prima distruggi il marker di prima
            if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(info.getMarker().name))
            {
                StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
            }

            if (webview.WebView.IsInitialized)
            {
                webview.WebView.SetRenderingEnabled(true);
            }

            webview.WebView.PostMessage(string.Format(
                    "{{ \"type\": \"play\"}}"));

            if (!info.getMarker().isWebPage)
            {
                OfflineGameManager.instance.sideMenu.show();
                OfflineGameManager.instance.buttonDoPlayPause(true);
            }


        };

        controller.TargetLost += () =>
        {

            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
                OfflineGameManager.instance.resetBadConnectionTimer();
            }


            OfflineGameManager.instance.connectionPopupActivator = false;

            OfflineGameManager.instance.sideMenu.hide();
            OfflineGameManager.instance.buttonDoPlayPause(false);

            if (info.getMarker().isWebPage)
            {
                StartCoroutine(createTarget(info.controller));
                return;
            }

            else
            {
                if (webview.WebView.IsInitialized)
                {
                    webview.WebView.SetRenderingEnabled(false);
                }
                webview.WebView.PostMessage(string.Format(
                                "{{ \"type\": \"pause\"}}"));
                webview.WebView.PostMessage(string.Format(
                                "{{ \"type\": \"pause\"}}"));
            }

        };


    }


    private void buildWebViewTesting(ImageTargetController controller, Marker marker)
    {

        Debug.Log("entra in webb");
        var prefab = Instantiate(webviewPrefab) as GameObject;
        prefab.transform.SetParent(controller.transform);
        prefab.transform.localPosition = new Vector3(0, 0, 0);
        prefab.transform.localScale = new Vector3(1, 1, 1);

        var info = prefab.AddComponent<TargetHandler>();
        info.setMarker(marker);

        CanvasWebViewPrefab webview = null;

        info.transform.GetChild(0).GetComponent<Canvas>().worldCamera = Camera.main;
        prefab.transform.GetChild(0).GetChild(0).gameObject.SetActive(false);

        webview = CanvasWebViewPrefab.Instantiate();

        webview.transform.SetParent(controller.transform.GetChild(0).GetChild(0).GetChild(1).transform);

        prefab.transform.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

        if (marker.tvMode)
        {
            adjustScreen(prefab.transform, controller, webview);
        }

        var rectTransform = webview.transform as RectTransform;
        rectTransform.anchoredPosition3D = Vector3.zero;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        webview.Resolution = 1300;
        webview.transform.localScale = Vector3.one;


        OfflineGameManager.instance.connectionPopupActivator = false;
        OfflineGameManager.instance.startToCountdownForBadConnection = false;
        OfflineGameManager.instance.resetBadConnectionTimer();

        webview.Initialized += (sender, e) =>
        {
            Web.SetAutoplayEnabled(true);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif

            //Gestione Maschera
            if (marker.mask != "")
            {
                var panelImage = prefab.transform.GetChild(0).GetChild(1).GetComponentInChildren<UnityEngine.UI.Image>();
                var panelMask = prefab.transform.GetChild(0).GetChild(1).GetComponentInChildren<Mask>();

                panelImage.color = new Color(1, 1, 1, 1);

                panelImage.sprite = tmpMask;

                panelMask.enabled = true;

            }



            //È una pagina web?

            webview.WebView.LoadUrl(marker.url);
            OfflineGameManager.instance.siteButton.gameObject.SetActive(true);
            OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
            prefab.transform.GetChild(0).GetChild(1).GetComponent<CanvasGroup>().alpha = 1;




        };



        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(info.getMarker().name))
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                Destroy(OfflineGameManager.instance.connectionPopup.gameObject);
            }
            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
        }

        info.initWebView();

        if (prefab.transform.GetChild(1))
            StartCoroutine(HideLoadingWeb(prefab));

        controller.TargetFound += () =>
        {
            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
            }
            // OfflineGameManager.instance.connectionPopupActivator = true;

            //Se quello attuale è diverso da quello di prima distruggi il marker di prima
            if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(info.getMarker().name))
            {
                StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
            }

            if (webview.WebView.IsInitialized)
            {
                webview.WebView.SetRenderingEnabled(true);
            }

            // webview.WebView.PostMessage(string.Format(
            //         "{{ \"type\": \"play\"}}"));

            // if (!info.getMarker().isWebPage)
            // {
            //     OfflineGameManager.instance.sideMenu.show();
            //     OfflineGameManager.instance.buttonDoPlayPause(true);
            // }


        };

        controller.TargetLost += () =>
        {

            if (OfflineGameManager.instance.connectionPopup != null)
            {
                OfflineGameManager.instance.connectionPopup.destroy();
                OfflineGameManager.instance.resetBadConnectionTimer();
            }


            // OfflineGameManager.instance.connectionPopupActivator = false;

            // OfflineGameManager.instance.sideMenu.hide();
            // OfflineGameManager.instance.buttonDoPlayPause(false);


            OfflineGameManager.instance.siteButton.gameObject.SetActive(false);
            // OfflineGameManager.instance.siteButton.onClick.AddListener(OfflineGameManager.instance.openWebsite);
            if (info.getMarker().isWebPage)
            {
                StartCoroutine(createTarget(info.controller));
                return;
            }

            else
            {
                if (webview.WebView.IsInitialized)
                {
                    webview.WebView.SetRenderingEnabled(false);
                }
                // webview.WebView.PostMessage(string.Format(
                //                 "{{ \"type\": \"pause\"}}"));
                // webview.WebView.PostMessage(string.Format(
                //                 "{{ \"type\": \"pause\"}}"));
            }

        };


    }

    #endregion
    #region Image Download / Visual Utils

        public void DownloadImage(string link, UnityEngine.UI.Image spriteImage)
    {
        spriteImage.sprite = OfflineGameManager.instance.targetManagerInstance.elementorModel.loading;
        StartCoroutine(downloadMask(link, spriteImage));
    }
    private IEnumerator downloadMask(string link, UnityEngine.UI.Image spriteImage = null)
    {
        using (var www = UnityWebRequestTexture.GetTexture(link))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                if (www.isDone)
                {
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    tmpMask = Sprite.Create(x, new Rect(0.0f, 0.0f, x.width, x.height), new Vector2(0.5f, 0.5f), 100.0f);
                    if (spriteImage != null)
                    {
                        spriteImage.sprite = tmpMask;
                    }
                }
            }
        }
    }

    private void adjustScreen(Transform prefab, ImageTargetController controller, CanvasWebViewPrefab webview = null)
    {
        var rect = prefab.transform.GetChild(0).GetComponent<RectTransform>();

        if (controller.Size.y > controller.Size.x)
            prefab.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1 / controller.Target.aspectRatio(), 1);
        else
            prefab.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());


        var pos = rect.position;
        pos.y += controller.Size.y - controller.Size.y / 4;
        pos.z -= controller.Size.y / 2;

        rect.rotation = Quaternion.Euler(new Vector3(-45, 0, 0));


        rect.position = pos;

        if (webview != null)
        {
            if (controller.Size.y > controller.Size.x)
            {
                prefab.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1 / controller.Target.aspectRatio(), 1);
            }
            else
                prefab.GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(1, 1 / controller.Target.aspectRatio());

            webview.transform.GetChild(1).GetComponent<RectTransform>().rotation = Quaternion.Euler(new Vector3(-45, 0, 0));
        }


    }

    IEnumerator HideLoadingWeb(GameObject prefab)
    {
        yield return new WaitForSeconds(3f);
        prefab.transform.GetChild(1).gameObject.SetActive(false);
    }

    #endregion
    #region Scene / DLC / Content

       private IEnumerator askForDownload(string id)
    {
        if (choice != null)
        {
            Destroy(choice.gameObject);
            choice = null;
        }

        yield return getContentFromId(id);

        if (GameData.instance.loggedUser._associatedContent.Contains(id) && GameData.instance.availableDownloadedContent.containsDlc(id))
        {
            //l'ho già scaricato e lo avvio

            GameData.instance.selectedContentId = id;
            PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(tmpContent));
            PlayerPrefs.Save();
            SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);

        }

        else
        {

            choice = UIController.instance.CreateConnectPopup();
            choice.initialize(UIController.instance.mainCanvas,
                tmpContent,
                () =>
                {
                    if (!PlayerPrefs.HasKey("framingTutorial"))
                    {
                        PlayerPrefs.SetInt("framingTutorial", 1);
                        PlayerPrefs.Save();
                    }
                    GameObject.Destroy(choice.gameObject);
                    StartCoroutine(downloadDLC(tmpContent));
                },
                true
            );
        }

    }

    private IEnumerator getContentFromId(string id)
    {
        string requestData = GameData.instance.loggedUser._token + "/" + id + "/0";

        //C: QUA SCARICA l asset bundle + marker chiamando un’altra API (CHECK_AND_DOWNLOAD_DLC) e poi salva i file in SaveLoadManager.DLCPATH/ID_DLC/...
        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_AND_DOWNLOAD_DLC + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }


            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    tmpContent = response._contents[0];


                }

            }

        }
    }

    private IEnumerator downloadDLC(Content c)
    {
        if (choice != null)
        {
            Destroy(choice.gameObject);
            choice = null;
        }

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._initializating);

        DLC dlc = new DLC(c._id);

        string requestData = GameData.instance.loggedUser._token + "/" + dlc._id + "/" + dlc._version;

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_AND_DOWNLOAD_DLC + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                Debug.LogError(www.error);
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }


            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    Content x = response._contents[0];

                    if (dlc._id.Equals(x._id))
                    {

                        waiting.destroy();

                        DownloadPopup downPopup = UIController.instance.CreateDownloadPopup();
                        downPopup.initialize(UIController.instance.mainCanvas);

                        yield return DownloadManager.downloadDLC(x, downPopup);

                        if (Directory.Exists(Path.Combine(SaveLoadManager.DLCPATH, dlc._id)))
                        {

                            dlc._version = x._version;
                            dlc._downloadDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                            if (!GameData.instance.loggedUser._associatedContent.Contains(dlc._id))
                                GameData.instance.loggedUser._associatedContent.Add(dlc._id);

                            if (!GameData.instance.availableDownloadedContent.containsDlc(dlc._id)) //Indica quali contenuti sono stati già scaricati e ne tiene traccia della versione
                            {
                                GameData.instance.availableDownloadedContent._dlcs.Add(dlc);

                                PlayerPrefs.SetString("availableContents", JsonUtility.ToJson(GameData.instance.availableDownloadedContent));
                                PlayerPrefs.Save();
                            }

                            yield return DownloadManager.UserDownloadDLC(dlc._id);

                            //GameData.instance.userDLCMap.Add(dlc._id, dlc);

                            //yield return GameData.instance.updateDLCAndSave();

                            //Analytics.instance.packageManaging(1,x._id);

                            GameData.instance.selectedContentId = x._id;
                            PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(x));
                            PlayerPrefs.Save();
                            OneSignal.User.AddTag("content-" + x._id, "1");

                            SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);

                        }
                    }



                }

                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }

        }

        yield return null;
    }


    private IEnumerator loadAsyncScene(string sceneName)
    {
        // The Application loads the Scene in the background as the current Scene runs.
        // This is particularly good for creating loading screens.
        // You could also load the Scene by using sceneBuildIndex. In this case Scene2 has
        // a sceneBuildIndex of 1 as shown in Build Settings.

        yield return new WaitForSeconds(0.3f);
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);

        yield return null;
    }

    #endregion
    #region 3D / Elementor


    private IEnumerator get3DModel(ImageTargetController controller, Marker marker)
    {

        if (OfflineGameManager.instance.connectionPopup != null)
        {
            OfflineGameManager.instance.connectionPopup.destroy();
        }


        OfflineGameManager.instance.connectionPopupActivator = false;
        OfflineGameManager.instance.startToCountdownForBadConnection = false;
        OfflineGameManager.instance.resetBadConnectionTimer();

        OfflineGameManager.instance.sideMenu.hide();

        string bundleURL = marker.is3D + "-";
        Debug.Log($"bundleURL = marker.is3D {marker.is3D}");
#if UNITY_ANDROID
        bundleURL += "Android";
#else
        bundleURL += "IOS";
#endif


        if (OfflineGameManager.instance.downloadInProgress)
        {
            OfflineGameManager.instance.inProgressRequest.webRequest.Abort();
        }


        using (UnityWebRequest www = UnityWebRequestAssetBundle.GetAssetBundle(bundleURL))
        {
            OfflineGameManager.instance.downloadAborted = false;

            DownloadPopup downPopup = UIController.instance.CreateDownloadPopup();
            downPopup.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._downloading);

            UnityWebRequestAsyncOperation download = www.SendWebRequest();

            OfflineGameManager.instance.downloadInProgress = true;
            OfflineGameManager.instance.inProgressRequest = download;


            yield return DownloadManager.handleBundleDownloadProgressBar(controller, www, download, downPopup);

            OfflineGameManager.instance.downloadInProgress = false;

            if (www.result != UnityWebRequest.Result.Success || OfflineGameManager.instance.downloadAborted)
            {
                Debug.Log(www.error);
                StartCoroutine(createTarget(controller));

                if (downPopup != null)
                    downPopup.destroy();

            }

            else
            {
                Debug.Log("get3DModel: richiesta buon fine");

                AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(www);

                if (bundle != null)
                {
                    if (!PlayerPrefs.HasKey("framingTutorial"))
                    {
                        PlayerPrefs.SetInt("framingTutorial", 1);
                        PlayerPrefs.Save();
                    }

                    Analytics.instance.model3D(marker.name, string.Empty, GameData.instance.sessionId + "");
                    OfflineGameManager.instance.fetch3DModel();


                    TargetHandler target = new TargetHandler();
                    target.controller = controller;
                    target.setMarker(marker, true);

                    if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(marker.name))
                    {
                        StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
                    }

                    OfflineGameManager.instance.setCurrentTarget(target);

                    string rootAssetPath = bundle.GetAllAssetNames()[0];
                    GameObject arObject = Instantiate(bundle.LoadAsset(rootAssetPath) as GameObject, controller.transform);

                   // arObject.AddComponent<Lean.Touch.LeanPinchScale>();
                    bundle.Unload(false);

                    OfflineGameManager.instance.isFrameSomething = true;

                    controller.TargetFound += () =>
                    {

                        if (OfflineGameManager.instance.connectionPopup != null)
                        {
                            OfflineGameManager.instance.connectionPopup.destroy();
                        }


                        OfflineGameManager.instance.connectionPopupActivator = false;
                        OfflineGameManager.instance.startToCountdownForBadConnection = false;


                        if (OfflineGameManager.instance.getCurrentTarget() != null && !OfflineGameManager.instance.getCurrentTarget().getMarker().name.Equals(marker.name))
                        {
                            StartCoroutine(createTarget(OfflineGameManager.instance.getCurrentTarget().controller));
                        }

                        OfflineGameManager.instance.sideMenu.hide();

                        OfflineGameManager.instance.setCurrentTarget(target);

                        OfflineGameManager.instance.fullScreenButton.gameObject.SetActive(false);
                        OfflineGameManager.instance.siteButton.gameObject.SetActive(false);

                        OfflineGameManager.instance.isFrameSomething = true;

                        if (arObject != null && arObject.GetComponentInChildren<AudioSource>())
                        {
                            arObject.GetComponentInChildren<AudioSource>().Play();
                        }

                        //arObject.GetComponent<Lean.Touch.LeanPinchScale>().enabled = true;

                    };


                    MuteMarker(controller, marker);
                    controller.TargetLost += () =>
                    {
                        OfflineGameManager.instance.downloadInProgress = false;

                        // arObject.GetComponent<Lean.Touch.LeanPinchScale>().enabled = false;

                        OfflineGameManager.instance.isFrameSomething = false;

                        if (arObject.GetComponentInChildren<AudioSource>())
                        {
                            arObject.GetComponentInChildren<AudioSource>().Pause();
                        }

                    };

                    //Analytics.instance.model3D(controller.ImageFileSource.Name, rootAssetPath);

                }
                else
                {
                    if (downPopup != null)
                        downPopup.destroy();

                    StartCoroutine(createTarget(controller));
                }
            }

        }
    }

    public void Get3DModelElement(Transform controller, DataRequest response)
    {
        StartCoroutine(get3DModelElement(controller, response));
    }

    IEnumerator get3DModelElement(Transform controller, DataRequest response)
    {

        if (OfflineGameManager.instance.connectionPopup != null)
        {
            OfflineGameManager.instance.connectionPopup.destroy();
        }

        string bundleURL = response.url + "-";
        Debug.Log("entro nel 3d");
#if UNITY_ANDROID
        bundleURL += "Android";
#else
        bundleURL += "IOS";
#endif


        using (UnityWebRequest www = UnityWebRequestAssetBundle.GetAssetBundle(bundleURL))
        {

            yield return www.SendWebRequest();


            // yield return DownloadManager.handleBundleDownloadProgressBar(controller, www, download, downPopup);

            if (www.result != UnityWebRequest.Result.Success || OfflineGameManager.instance.downloadAborted)
            {
                Debug.Log(www.error);

            }

            else
            {
                Debug.Log("get3DModel: richiesta buon fine");

                AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(www);

                if (bundle != null)
                {
                    if (!PlayerPrefs.HasKey("framingTutorial"))
                    {
                        PlayerPrefs.SetInt("framingTutorial", 1);
                        PlayerPrefs.Save();
                    }

                    string rootAssetPath = bundle.GetAllAssetNames()[0];
                    GameObject arObject = Instantiate(bundle.LoadAsset(rootAssetPath) as GameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, controller);
                    arObject.AddComponent<ModelEntity>().Constructor(response);
                    // arObject.transform.localScale = new Vector3(response.width, response.height, response.deep);
                    // Vector3 rot = new Vector3(response.rotation_x, response.rotation_y, response.rotation_z);
                    // arObject.transform.localRotation = Quaternion.Euler(rot);
                    // arObject.transform.localPosition = new Vector3(response.x, response.y, response.z);
                    // arObject.AddComponent<Lean.Touch.LeanPinchScale>();
                    bundle.Unload(false);
                }
                else
                {
                    Debug.Log("Bungle empty");
                }
            }

        }
    }

    #endregion
    #region Audio



    private void MuteMarker(ImageTargetController controller, Marker marker)
    {
        if (marker.mute)
        {
            AudioSource[] soundsToMute = controller.GetComponentsInChildren<AudioSource>();
            for (int i = 0; i < soundsToMute.Length; i++)
            {
                soundsToMute[i].volume = 0;
            }

            UnityEngine.Video.VideoPlayer[] videoToMute = controller.GetComponentsInChildren<UnityEngine.Video.VideoPlayer>();
            for (int i = 0; i < videoToMute.Length; i++)
            {
                videoToMute[i].EnableAudioTrack(0, false);
            }
        }
    }

    #endregion
    
}

