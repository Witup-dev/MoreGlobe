﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public static class SaveLoadManager
{

    public static readonly string DLCPATH = Path.Combine(Application.persistentDataPath, "dlc");
    public static readonly string THUMBNAILPATH = Path.Combine(Application.persistentDataPath, "thumbnail");
    public static readonly string SAVINGPATH = Path.Combine(Application.persistentDataPath, "save");

}
