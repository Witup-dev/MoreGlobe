﻿using UnityEngine;
using OneSignalSDK;   

public class NotificationInitializer : MonoBehaviour
{
    
    [SerializeField]
    private string oneSignalAppId = "3ff3c109-b6c5-481f-b6d7-1406b0db2f9d";

    
    private void Awake()
    {
        // l oggetto non venie distrutto cambiando scena
        DontDestroyOnLoad(gameObject);
    }

    
    private async void Start()
    {
      
        // OneSignal.Debug.LogLevel  = LogLevel.Verbose;   --> serve solo per il log (non serve)   ??
       //  OneSignal.Debug.AlertLevel = LogLevel.None;    --> serve solo per il log (non serve)   ?

      
        OneSignal.Initialize(oneSignalAppId);

      
        await OneSignal.Notifications.RequestPermissionAsync(true);

        // FUTURO ---> SE si vuole reagire all’apertura notifiche, da agg:
        // OneSignal.Notifications.Clicked += OnNotificationClicked;
    }

   
}
