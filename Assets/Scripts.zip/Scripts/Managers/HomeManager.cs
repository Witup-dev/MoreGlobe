﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;
using UnityEngine.EventSystems;

public class HomeManager : MonoBehaviour
{


[Header("UI GameObjects principali")]

    public GameObject startButton;
    public GameObject menu;
    public GameObject tutorial;
    public GameObject credits;
    public GameObject notification;
    public GameObject demoAR;
    public GameObject loading;



[Header("Loading spinner & text")]

    public RectTransform _spinner;
    public Text sliderText;




[Header("Tutorial")] 

    public ScrollPanel tutorialScroll;
    public Toggle tutorialToggle;
    public CanvasGroup tutorialCanvasGroup;
    public CanvasGroup startButtonCanvasGroup;




[Header("Altra UI")] 

    public Text internetConnection;
    public Button startArButton;




[Header("Parameters for UI animations")]  

    public float fadeDuration = 0.5f;


#region Unity Lifecycle

    // Start is called before the first frame update
    void Start()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        //checkInternetConnection();

        Screen.orientation = ScreenOrientation.Portrait;
        // menu = 1 -> sto venendo dall'ar

        if (PlayerPrefs.HasKey("menu"))
        {
            if (PlayerPrefs.GetInt("menu") == 0)
            {
                showTutorial(0);
            }

            else
            {
                PlayerPrefs.SetInt("menu", 0);
                showMenu();
            }
        }

        else
        {
            showTutorial(0);
        }


    }

    void Update()
    {

    }

#endregion
#region Main panels visibility management

    public void disableAll()
    {
        startButton.SetActive(false);
        menu.SetActive(false);
        tutorial.SetActive(false);
    }

    public void disableMenuAll()
    {
        notification.SetActive(false);
        credits.SetActive(false);
        tutorial.SetActive(false);
        demoAR.SetActive(false);
    }


    public void showTutorial(int action)
    {
        disableAll();

        //Action:
        // 0: tutorial allo start
        // 1: tutorial richiamato

        //tutorial == 1 -> non devo vedere tutorial

        if(action == 0)
        {
            if (PlayerPrefs.HasKey("tutorial"))
            {
                if (PlayerPrefs.GetInt("tutorial") == 0)
                {
                    tutorialToggle.isOn = false;
                    tutorialScroll.resetTutorial();
                    tutorial.SetActive(true);
                    StartCoroutine(doFade(tutorialCanvasGroup));
                    
                }

                else
                {
                    tutorialToggle.isOn = true;
                    showStartButton();
                    StartCoroutine(doFade(startButtonCanvasGroup));
                }


            }

            else
            {
                tutorialToggle.isOn = false;
                tutorialScroll.resetTutorial();
                tutorial.SetActive(true);
                
            }
        }

        else
        {
            if (PlayerPrefs.GetInt("tutorial") == 0)
            {
                tutorialToggle.isOn = false;
            }
            else
            {
                tutorialToggle.isOn = true;
            }


            tutorialScroll.resetTutorial();
            tutorial.SetActive(true);
        }
        


    }


    public void showStartButton()
    {
        startButton.SetActive(true);
    }

    public void showMenu()
    {
        disableMenuAll();
        menu.SetActive(true);
        
    }


    #endregion
#region Navigation / Scene

   

    public void goToAR()
    {
        StartCoroutine(loadAsyncScene("ARScene"));
    }

    public void goToLocalAR()
    {
        StartCoroutine(loadAsyncScene("LocalMarkerScene"));
    }

        public void goToMenu() //go to menu from credits
    {
        disableMenuAll();
        menu.SetActive(true);
    }



     #endregion
#region Menu sub-pages


    public void showNotification()
    {
        menu.SetActive(false);
        notification.SetActive(true);
    }

    public void showDemoAR()
    {
        menu.SetActive(false);
        demoAR.SetActive(true);
    }

    public void openWebDemo()
    {
        Application.OpenURL("https://www.creatiwa.eu/wp-content/uploads/2020/07/File_AR_DEMO_A4_Printable.pdf");
    }

    public void showCredits()
    {
        menu.SetActive(false);
        credits.SetActive(true);
    }


    IEnumerator spinLoader(){
        while(true){
            _spinner.Rotate( new Vector3( 0, 0, -45 * 5 * Time.deltaTime ) );
            yield return null;
        }
    }

    IEnumerator loadAsyncScene(string sceneName)
    {

        loading.SetActive(true);
        StartCoroutine(spinLoader());
        // The Application loads the Scene in the background as the current Scene runs.
        // This is particularly good for creating loading screens.
        // You could also load the Scene by using sceneBuildIndex. In this case Scene2 has
        // a sceneBuildIndex of 1 as shown in Build Settings.

        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Single);

        // Wait until the asynchronous scene fully loads
        while (!asyncLoad.isDone)
        {
            
            float progress = Mathf.Clamp01(asyncLoad.progress / 0.9f);

            sliderText.text = (int)(progress * 100) + "%";

            yield return null;
        }
    }



    private IEnumerator doFade(CanvasGroup group){

        float counter = 0f;

        while(counter < fadeDuration){
            counter += Time.deltaTime;
            group.alpha = Mathf.Lerp(0,1, counter/fadeDuration);

            yield return null;
        }

        //SceneManager.LoadScene(1,LoadSceneMode.Single);
    }


    #endregion
    #region Social Button and exit

    public void goOnFacebook()
    {
        Application.OpenURL("https://www.facebook.com/creatiwastudio");
    }

    public void goOnTwitter()
    {
        Application.OpenURL("https://twitter.com/creatiwastudio");
    }

    public void goOnInstagram()
    {
        Application.OpenURL("https://www.instagram.com/creatiwastudio/?hl=it");
    }



    public void exit()
    {
        Application.Quit();
    }

        #endregion
}
