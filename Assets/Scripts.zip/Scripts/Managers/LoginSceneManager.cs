﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;
using System.Text.RegularExpressions;
using UnityEngine.Networking;
using TMPro;
using UnityEngine;
using UnityEngine.SignInWithApple;
using System.Threading.Tasks;
using Google;
using UnityEngine.Android;
using OneSignalSDK;


public class LoginSceneManager : MonoBehaviour 
{   
     // --- SINGLETON  ---
    public static LoginSceneManager instance { get; private set; }



    [Header("Config & stato")]

    private GoogleSignInConfiguration configuration;
    private string webClientId = "664123666593-67tdbpvl3bhsg1a1uobjce8mjns1jfe8.apps.googleusercontent.com";
    private const string MatchEmailPattern =
        @"^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@"
        + @"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\."
        + @"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
        + @"([a-zA-Z]+[\w-]+\.)+[a-zA-Z]{2,4})$";
    private string privacyLink = "https://www.moreglobe.com/terms-and-conditions";
    private bool _skipLogin;
    private bool mailAndUsernameAreValid;


     // --- UI ELEMENTS ---
    [Header("Providers")]

    public GameObject appleLoginButton;
    public GameObject googleLoginButton;


    

    [Header("Panels")]

    public GameObject entryPanel;
    public GameObject loginPanel;
    public GameObject joinPanel;
    public GameObject passwordRecoverPanel;


    
    [Header("Sub Panels")]

    public GameObject recoverPart1;
    public GameObject recoverPart2;
    public GameObject registrationFormPanel;
    public GameObject registrationCompletePanel;




    [Header("UI Texts")]

    public Toggle privacyToggle;
    public TextMeshProUGUI notAMember;
    public TextMeshProUGUI createAccount;
    public TextMeshProUGUI passwordForgotten;
    public TextMeshProUGUI usernameInstruction;
    public TextMeshProUGUI passwordInstruction;
    public TextMeshProUGUI confirmPassword;
    public TextMeshProUGUI TermsAndCondition;
    public TextMeshProUGUI checkYourEmailForSignUp;
    public TextMeshProUGUI checkYourEmailForPasswordRecover;
    public TextMeshProUGUI recoverPasswordText;
    public TextMeshProUGUI confirmButtonRecoverPassword;
    public TextMeshProUGUI continueWithMoreglobeText;
    public TextMeshProUGUI continueWithGoogleText;
    //public TextMeshProUGUI continueWithFacebookText;
    public TextMeshProUGUI continueWithAppleText;
    public TextMeshProUGUI createNewAccountText;
    public TextMeshProUGUI confirmRegistrationText;



    [Header("Form Input Field")]

    public TMP_InputField usernameInput;
    public TMP_InputField emailInput;
    public TMP_InputField passwordInput;
    public TMP_InputField confirmPasswordInput;
    public TMP_InputField recoverEmailInput;
    public TMP_InputField loginEmailInput;
    public TMP_InputField loginPasswordInput;
    public TextMeshProUGUI loginText;
    public TextMeshProUGUI homeText;
    public TextMeshProUGUI confirmMailForRecover;
    public TextMeshProUGUI recoverPasswordHome;


// --- UNITY LIFECYCLE ---
#region UNITY LIFECYCLE
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        mailAndUsernameAreValid = false;

        configuration = new GoogleSignInConfiguration { WebClientId = webClientId, RequestEmail = true, RequestIdToken = true };



        notAMember.text = GameData.instance.currentLanguage._notAMemberYet;
        createAccount.text = GameData.instance.currentLanguage._createAccount;
        passwordForgotten.text = GameData.instance.currentLanguage._passwordForgotten;
        usernameInstruction.text = GameData.instance.currentLanguage._usernameInstruction;
        passwordInstruction.text = GameData.instance.currentLanguage._passwordInstruction;
        confirmPassword.text = GameData.instance.currentLanguage._confirmPassword;
        TermsAndCondition.text = GameData.instance.currentLanguage._termsAndServices;
        checkYourEmailForSignUp.text = GameData.instance.currentLanguage._checkEmailForSignUp;
        checkYourEmailForPasswordRecover.text = GameData.instance.currentLanguage._checkEmailForPasswordRecover;
        recoverPasswordText.text = GameData.instance.currentLanguage._passwordRecoverText;
        confirmButtonRecoverPassword.text = GameData.instance.currentLanguage._confirm;
        loginText.text = GameData.instance.currentLanguage._loginAction;
        homeText.text = GameData.instance.currentLanguage._homeFooter;
        confirmMailForRecover.text = GameData.instance.currentLanguage._confirm;
        recoverPasswordHome.text = GameData.instance.currentLanguage._homeFooter;
        continueWithMoreglobeText.text = GameData.instance.currentLanguage._continueWith + "<b>Moreglobe<sup>\u00AE</sup></b>";
        continueWithGoogleText.text = GameData.instance.currentLanguage._continueWith + "<b>Google</b>";
        //continueWithFacebookText.text = GameData.instance.currentLanguage._continueWith + "<b>Facebook</b>";
        continueWithAppleText.text = GameData.instance.currentLanguage._continueWith + "<b>Apple</b>";
        createNewAccountText.text = GameData.instance.currentLanguage._createNewAccount;
        confirmRegistrationText.text = GameData.instance.currentLanguage._confirm;


    }


    // Start is called before the first frame update
   
    void Start()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.Portrait;
        var distance = Screen.height - Screen.safeArea.size.y;
        registrationFormPanel.GetComponent<RectTransform>().offsetMax = new Vector2(registrationFormPanel.GetComponent<RectTransform>().offsetMax.x, -distance - 75);

        //GoogleSignIn.Configuration = new GoogleSignInConfiguration
        //{
        //    RequestIdToken = true,
        //    // Copy this value from the google-service.json file.
        //    // oauth_client with type == 3

        //};

#if UNITY_IOS
            appleLoginButton.SetActive(true);
            googleLoginButton.SetActive(false);

#elif UNITY_ANDROID
        googleLoginButton.SetActive(true);
        appleLoginButton.SetActive(false);
#endif

        checkPrefs();


        if (!GameData.instance.hasStarted)
        {
            GameData.instance.hasStarted = true;
            StartCoroutine(checkForApplicationUpdate());
        }

    }

#endregion

#region FIELD VALIDATION

    private void checkPrefs()
    {
        
        if (!string.IsNullOrEmpty(GameData.instance.loggedUser._token))
        {

            if(GameData.instance.loggedUser._loginType == "a")
            {
                var siwa = gameObject.GetComponent<SignInWithApple>();
                siwa.GetCredentialState(GameData.instance.loggedUser._aID, isAppleIDAuthorized);
            }

            else
            {
                _skipLogin = true;
            }

            
        }

        else
        {
            _skipLogin = false;
        }
    }

    public void isAppleIDAuthorized(SignInWithApple.CallbackArgs args)
    {
        if(args.credentialState == UserCredentialState.Authorized)
        {
            _skipLogin = true;
        }

        else
        {
            GameData.instance.loggedUser = new User();
            PlayerPrefs.DeleteKey("loggedUser");
            PlayerPrefs.Save();

            _skipLogin = false;
        }
    }

    private bool checkLoginField()
    {
        string emailField = loginEmailInput.text.Trim();
        string passField = loginPasswordInput.text.Trim();

        if (string.IsNullOrEmpty(emailField))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[5]._title,
                GameData.instance.currentLanguage._popupInfoJson[5]._message,
                GameData.instance.currentLanguage._popupInfoJson[5]._buttonText,
                "error");
            return false;
        }

        if (!Regex.IsMatch(emailField, MatchEmailPattern))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[6]._title,
                GameData.instance.currentLanguage._popupInfoJson[6]._message,
                GameData.instance.currentLanguage._popupInfoJson[6]._buttonText,
                "error");
            return false;
        }

        if (string.IsNullOrEmpty(passField))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[7]._title,
                GameData.instance.currentLanguage._popupInfoJson[7]._message,
                GameData.instance.currentLanguage._popupInfoJson[7]._buttonText,
                "error");
            return false;
        }

        return true;
    }

    private bool validatePassword(string pass, string confirmPass)
    {
        bool hasCondition = false;

        char curChar;

        if (string.IsNullOrEmpty(pass))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[7]._title,
                GameData.instance.currentLanguage._popupInfoJson[7]._message,
                GameData.instance.currentLanguage._popupInfoJson[7]._buttonText,
                "error");
            return false;
        }

        if (pass.Length < 8)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[8]._title,
                GameData.instance.currentLanguage._popupInfoJson[8]._message,
                GameData.instance.currentLanguage._popupInfoJson[8]._buttonText,
                "error");
            return false;
        }

        for (int i = 0; i < pass.Length; i++)
        {
            curChar = pass[i];

            if (char.IsNumber(curChar) || char.IsSymbol(curChar) || char.IsPunctuation(curChar))
                hasCondition = true;
        }

        if (!hasCondition)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[9]._title,
                GameData.instance.currentLanguage._popupInfoJson[9]._message,
                GameData.instance.currentLanguage._popupInfoJson[9]._buttonText,
                "error");
            return false;
        }

        if (string.IsNullOrEmpty(confirmPass))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[10]._title,
                GameData.instance.currentLanguage._popupInfoJson[10]._message,
                GameData.instance.currentLanguage._popupInfoJson[10]._buttonText,
                "error");
            return false;
        }

        if (!pass.Equals(confirmPass))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[11]._title,
                GameData.instance.currentLanguage._popupInfoJson[11]._message,
                GameData.instance.currentLanguage._popupInfoJson[11]._buttonText,
                "error");
            return false;
        }

        return true;
    }

    private bool validateUsername(string username)
    {
        bool hasLower = true;
        bool hasUnderscore = true;

        char curChar;

        if (string.IsNullOrEmpty(username))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[12]._title,
                GameData.instance.currentLanguage._popupInfoJson[12]._message,
                GameData.instance.currentLanguage._popupInfoJson[12]._buttonText,
                "error");
            return false;
        }

        if (username.Length < 4 || username.Length > 15)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[13]._title,
                GameData.instance.currentLanguage._popupInfoJson[13]._message,
                GameData.instance.currentLanguage._popupInfoJson[13]._buttonText,
                "error");
            return false;
        }

        for (int i = 0; i < username.Length; i++)
        {
            curChar = username[i];

            if (char.IsUpper(curChar))
            {
                hasLower = false;
                break;
            }

            if ((char.IsSymbol(curChar) || char.IsPunctuation(curChar)) && curChar != '_')
            {
                hasUnderscore = false;
                break;
            }
        }


        if (!hasLower)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[14]._title,
                GameData.instance.currentLanguage._popupInfoJson[14]._message,
                GameData.instance.currentLanguage._popupInfoJson[14]._buttonText,
                "error");
            return false;
        }
        if (!hasUnderscore)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[15]._title,
                GameData.instance.currentLanguage._popupInfoJson[15]._message,
                GameData.instance.currentLanguage._popupInfoJson[15]._buttonText,
                "error");
            return false;
        }

        return true;
    }

    private bool validateEmail(string email)
    {

        if (string.IsNullOrEmpty(email))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[5]._title,
                GameData.instance.currentLanguage._popupInfoJson[5]._message,
                GameData.instance.currentLanguage._popupInfoJson[5]._buttonText,
                "error");
            return false;
        }

        if (!Regex.IsMatch(email, MatchEmailPattern))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[6]._title,
                GameData.instance.currentLanguage._popupInfoJson[6]._message,
                GameData.instance.currentLanguage._popupInfoJson[6]._buttonText,
                "error");
            return false;
        }

        return true;
    }

    private void cleanRegField()
    {
        
        usernameInput.text = string.Empty;
        emailInput.text = string.Empty;
        passwordInput.text = string.Empty;
        confirmPasswordInput.text = string.Empty;
        privacyToggle.isOn = false;
    }


#endregion

// --- UI SETTINGS ---
#region UI SETTINGS

    private void disableAll()
    {
        setEntryPanel(false);
        setLoginPanel(false);
        setJoinPanel(false);
        setPasswordRecoverPanel(false);
    }

    public void setEntryPanel(bool status)
    {
        entryPanel.SetActive(status);
    }

    public void setLoginPanel(bool status)
    {
        loginPanel.SetActive(status);
    }

    public void setJoinPanel(bool status)
    {
        if (!status)
        {
            registrationCompletePanel.SetActive(false);
            registrationFormPanel.SetActive(true);
        }

        joinPanel.SetActive(status);        
    }

    public void setPasswordRecoverPanel(bool status)
    {
        if (status)
        {
            setRecoverPart1(true);
            setRecoverPart2(false);
        }

        passwordRecoverPanel.SetActive(status);
    }


    public void setRecoverPart1(bool status)
    {
        recoverPart1.SetActive(status);
    }

    public void setRecoverPart2(bool status)
    {
        recoverPart2.SetActive(status);
    }





#endregion

// --- BUTTON BEHAVIOURS ---
#region BUTTON BEHAVIOURS

    public void menuLoginButton()
    {
        setLoginPanel(true);
    }

    public void menuSignUpButton()
    {
        setJoinPanel(true);
    }

    public void menuRecoverPasswordButton()
    {
        setPasswordRecoverPanel(true);
    }

    public void signIn()
    {

        if (checkLoginField())
        {
            StartCoroutine(_signIn());
        }
        
        
    }

    public void validateAndRegister()
    {

        if(validateUsername(usernameInput.text.Trim()) && validateEmail(emailInput.text.Trim()) && validatePassword(passwordInput.text.Trim(), confirmPasswordInput.text.Trim())) {


            if (!privacyToggle.isOn)
            {
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[16]._title,
                    GameData.instance.currentLanguage._popupInfoJson[16]._message,
                    GameData.instance.currentLanguage._popupInfoJson[16]._buttonText,
                    "error");
            }
            else
            {
                StartCoroutine(_signUp());
            }

        }

        
    }
    
    public void goToEntry()
    {
        disableAll();
        setEntryPanel(true);
        
    }

    public void goToLogin()
    {
        disableAll();
        setLoginPanel(true);
    }

    public void logOut()
    {
        StartCoroutine(_logout());
    }

    public void recoverPassword()
    {
        string emailField = recoverEmailInput.text.Trim();

        if (string.IsNullOrEmpty(emailField))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[5]._title,
                GameData.instance.currentLanguage._popupInfoJson[5]._message,
                GameData.instance.currentLanguage._popupInfoJson[5]._buttonText,
                "error");
            return;
        }

        if (!Regex.IsMatch(emailField,MatchEmailPattern))
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[6]._title,
                GameData.instance.currentLanguage._popupInfoJson[6]._message,
                GameData.instance.currentLanguage._popupInfoJson[6]._buttonText,
                "error");
            return;
        }

        StartCoroutine(_recoverPassowrd());
    }

    public void openPrivacyLink()
    {
        Application.OpenURL(privacyLink);
    }


    #endregion

  // --- ASYNC METHODS --
#region ASYNC METHODS

    public void SignInWithGoogle() {

        if(GoogleSignIn.Configuration == null)
        {
            GoogleSignIn.Configuration = configuration;
            GoogleSignIn.Configuration.UseGameSignIn = false;
            GoogleSignIn.Configuration.RequestIdToken = true;
        }
        
        Debug.Log("Calling SignIn");

        GoogleSignIn.DefaultInstance.SignIn().ContinueWith(OnAuthenticationFinished);

        //if (GameData.instance.loginMode != null)
        //{

        //    GameData.instance.loginMode.destroy();
        //    GameData.instance.loginMode = null;
        //}

        //GameData.instance.loginMode = GameData.instance.gameObject.AddComponent<GoogleLogin>();
        //GameData.instance.loginMode.init();
        //GameData.instance.loginMode.login();

    }


internal void OnAuthenticationFinished(Task<GoogleSignInUser> task)
    {
        if (task.IsFaulted)
        {
            using (IEnumerator<Exception> enumerator = task.Exception.InnerExceptions.GetEnumerator())
            {
                if (enumerator.MoveNext())
                {
                    GoogleSignIn.SignInException error = (GoogleSignIn.SignInException)enumerator.Current;
                    Debug.Log("Got Error: " + error.Status + " " + error.Message);
                }
                else
                {
                    Debug.Log("Got Unexpected Exception?!?" + task.Exception);
                }
            }
        }
        else if (task.IsCanceled)
        {
            Debug.Log("Canceled");
        }
        else
        {
            Debug.Log("GLogin Welcome: " + task.Result.DisplayName + "!");
            Debug.Log("GLogin Email = " + task.Result.Email);
            Debug.Log("GLogin Google ID Token = " + task.Result.IdToken);

            loginWithGoogle(task.Result);
            //SignInWithGoogleOnFirebase(task.Result.IdToken);
        }
    }

    private void loginWithGoogle(GoogleSignInUser user)
    {
        StartCoroutine(_loginWithGoogle(user));
    }
    private IEnumerator _loginWithGoogle(GoogleSignInUser user)
    {
        
        yield return new WaitForEndOfFrame();

        WWWForm form = new WWWForm();
        form.AddField("googleid", user.UserId);
        form.AddField("google_email", user.Email);
        form.AddField("name", user.DisplayName);

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingIn);

        using (UnityWebRequest www = UnityWebRequest.Post(APIs.LOGIN_GOOGLE_SERVICE, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");

            }

            else
            {
                LoginResponse response = JsonUtility.FromJson<LoginResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    waiting.destroy();
                    GameData.instance.loggedUser._token = response._token;
                    GameData.instance.loggedUser._username = user.DisplayName;
                    GameData.instance.loggedUser._email = user.Email;
                    GameData.instance.loggedUser._fbID = string.Empty;
                    GameData.instance.loggedUser._aID = string.Empty;
                    GameData.instance.loggedUser._gID = user.UserId;
                    GameData.instance.loggedUser._loginType = "g";

                    PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
                    PlayerPrefs.Save();
                    goNext();

                }
                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }
        }
    }

   private IEnumerator _signUp()
{
    yield return _checkUsernameAndEmail();

    // *** MODIFICA IMPORTANTE ***
    // Se username/email NON sono validi, mi fermo qui.
    if (!mailAndUsernameAreValid)
    {
        yield break;
    }
    // *** FINE MODIFICA ***

    WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
    waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loading);

    string usernameField = usernameInput.text.Trim();
    string emailField = emailInput.text.Trim();
    string passField = passwordInput.text.Trim();
    //string birthday = yearInput.text.Trim() + "/" + monthInput.text.Trim() + "/" + dayInput.text.Trim();


    WWWForm form = new WWWForm();
    form.AddField("username", usernameField);
    form.AddField("email", emailField);
    form.AddField("password", passField);
    form.AddField("confirm", passField);
    form.AddField("privacy", (privacyToggle.isOn ? 1 : 0));
    form.AddField("language", GameData.instance.selectedLanguage);


    using (UnityWebRequest www = UnityWebRequest.Post(APIs.REGISTRATION_SERVICE, form))
    {
        yield return www.SendWebRequest();

        waiting.destroy();

        if (www.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Signup network error: " + www.error + " | code: " + www.responseCode);
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                "error");
        }

        else
        {
            Debug.Log("Signup response: " + www.downloadHandler.text);
            Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

            if (response._success)
            {
                loginEmailInput.text = emailField;
                loginPasswordInput.text = passField;

                registrationFormPanel.SetActive(false);
                registrationCompletePanel.SetActive(true);
                cleanRegField();
            }
            else
            {
                Debug.LogWarning("Signup _success = false, message: " + response._message);
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }
        }
    }

    yield return null;
}


    private IEnumerator _signIn()
    {

         Debug.Log("LOGIN: inizio coroutine");
        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingIn);

        yield return new WaitForSeconds(2);

        string emailField = loginEmailInput.text.Trim();
        string passField = loginPasswordInput.text.Trim();


        WWWForm form = new WWWForm();
        form.AddField("email", emailField);
        form.AddField("password", passField);
        form.AddField("language", GameData.instance.selectedLanguage);

         Debug.Log("LOGIN: mando richiesta a " + APIs.LOGIN_SERVICE);

        using (UnityWebRequest www = UnityWebRequest.Post(APIs.LOGIN_SERVICE, form))
        {

            yield return www.SendWebRequest();

            Debug.Log("LOGIN: risposta arrivata, result = " + www.result);

            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                 Debug.LogError("LOGIN: errore rete = " + www.error);
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");

            }

            else
            {
                Debug.Log("LOGIN: response raw = " + www.downloadHandler.text);

                LoginResponse response = JsonUtility.FromJson<LoginResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    waiting.destroy();
                      Debug.Log("LOGIN: success, chiamo goNext()");
                       
                    GameData.instance.loggedUser._token = response._token;
                    GameData.instance.loggedUser._username = response._username;
                    GameData.instance.loggedUser._email = emailField;
                    GameData.instance.loggedUser._fbID = string.Empty;
                    GameData.instance.loggedUser._aID = string.Empty;
                    GameData.instance.loggedUser._gID = string.Empty;
                    GameData.instance.loggedUser._loginType = "m";

                    PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
                    PlayerPrefs.Save();

                    Debug.Log("Utente facebook salvato: " + PlayerPrefs.HasKey("loggedUser"));

                    goNext();
                    
                }
                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        response._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }
                
            }
        }



    }

    /* public void signInWithFacebookButton()
    {        
        if(GameData.instance.loginMode != null)
        {

            GameData.instance.loginMode.destroy();
            GameData.instance.loginMode = null;
        }

        GameData.instance.loginMode = GameData.instance.gameObject.AddComponent<FacebookLogin>();
        GameData.instance.loginMode.init();
    } */

    public void signInWithAppleButton()
    {
        if (GameData.instance.loginMode != null)
        {
            GameData.instance.loginMode.destroy();
            GameData.instance.loginMode = null;
        }

        GameData.instance.loginMode = GameData.instance.gameObject.AddComponent<AppleLogin>();
        GameData.instance.loginMode.init();
        GameData.instance.loginMode.login();

    }


    private IEnumerator _tokenLogin()
    {
        if (_skipLogin)
        {
            WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
            waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingIn);

            yield return new WaitForSeconds(2);

            goNext();

            waiting.destroy();
        }
    }

    private IEnumerator _logout()
    {

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingOut);

        yield return new WaitForSeconds(2);

        if (GameData.instance.loggedUser._loginType.Equals("f"))
        {
            //GameData.instance.facebookLogout();
            GameData.instance.loginMode.logout();
            Destroy(GameData.instance.loginMode.gameObject);
        }

        GameData.instance.loggedUser = new User();
        PlayerPrefs.DeleteKey("loggedUser");
        setEntryPanel(true);
        PlayerPrefs.Save();
        waiting.destroy();

    }

    private IEnumerator _recoverPassowrd()
    {
        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loading);

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.PASSWORD_RECOVER_SERVICE + recoverEmailInput.text.Trim()))
        {

            yield return www.SendWebRequest();

            waiting.destroy();
            

            if (www.result != UnityWebRequest.Result.Success)
            {
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);
                
                if (response._success)
                {

                    setRecoverPart1(false);
                    setRecoverPart2(true);

                }
                else
                {
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }
        }
    
}

    private IEnumerator _checkUsernameAndEmail()
    {
        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loading);

        string user = "username="+usernameInput.text.Trim();
        string mail = "email="+emailInput.text.Trim();
        string language = "language="+ GameData.instance.selectedLanguage;

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_USERNAME_AND_EMAIL_SERVICE + user + "&"+mail+"&"+language))
        {

            yield return www.SendWebRequest();

            waiting.destroy();


            if (www.result != UnityWebRequest.Result.Success)
            {
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (response._success)
                {
                    mailAndUsernameAreValid = true;

                }
                else
                {
                    mailAndUsernameAreValid = false;
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        response._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }
        }

    }

    private IEnumerator checkForApplicationUpdate()
    {       
        yield return _tokenLogin();
    }


    private void goNext()
    {
        StartCoroutine(Utilities.handleOnesignalPlayerID(false));

        if (GameData.instance.gameObject.GetComponent<Analytics>() == null)
        {
            GameData.instance.gameObject.AddComponent<Analytics>();
        }

#if UNITY_IOS

        GameData.instance.gameObject.AddComponent<AppTrackingTransparencyBehaviour>();

#elif UNITY_ANDROID
        
        SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
#endif
    }


    #endregion


       #region APPLE_LOGIN

    //private void onAppleLogin(SignInWithApple.CallbackArgs args)
    //{
    //    UserInfo userInfo = args.userInfo;
    //    Debug.Log(
    //        string.Format("Display Name: {0}\nEmail: {1}\nUser ID: {2}\nID Token: {3}", userInfo.displayName ?? "",
    //            userInfo.email ?? "", userInfo.userId ?? "", userInfo.idToken ?? ""));


    //    StartCoroutine(_signInWithApple(userInfo));
    //}

    //public void onAppleLoginError()
    //{
    //    PopupInfo popup = UIController.instance.CreateInfoPopup();
    //    popup.initialize(UIController.instance.mainCanvas,
    //        GameData.instance.currentLanguage._popupInfoJson[1]._title,
    //        GameData.instance.currentLanguage._popupInfoJson[1]._message,
    //        GameData.instance.currentLanguage._popupInfoJson[1]._buttonText,
    //        "error",
    //        () => {
    //            GameObject.Destroy(popup.gameObject);
    //            signInWithAppleButton();
    //        });
    //}

    //private IEnumerator _signInWithApple(UserInfo userInfo)
    //{

    //    WWWForm form = new WWWForm();
    //    form.AddField("appleid", userInfo.userId);
    //    form.AddField("email", userInfo.email);
    //    form.AddField("name", userInfo.displayName);

    //    WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
    //    waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingIn);

    //    using (UnityWebRequest www = UnityWebRequest.Post(APIs.LOGIN_APPLE_SERVICE, form))
    //    {

    //        yield return www.SendWebRequest();

    //        if (www.result != UnityWebRequest.Result.Success)
    //        {
    //            waiting.destroy();
    //            PopupInfo popup = UIController.instance.CreateInfoPopup();
    //            popup.initialize(UIController.instance.mainCanvas,
    //                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
    //                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
    //                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
    //                "error");

    //        }

    //        else
    //        {


    //            LoginResponse response = JsonUtility.FromJson<LoginResponse>(www.downloadHandler.text);

    //            Debug.Log("ricevuta response Apple: " + response);

    //            if (response._success)
    //            {
    //                waiting.destroy();
    //                GameData.instance.loggedUser._token = response._token;
    //                GameData.instance.loggedUser._username = userInfo.displayName;
    //                GameData.instance.loggedUser._email = userInfo.email;
    //                GameData.instance.loggedUser._fbID = string.Empty;
    //                GameData.instance.loggedUser._aID = userInfo.userId;
    //                GameData.instance.loggedUser._gID = string.Empty;
    //                GameData.instance.loggedUser._loginType = "a";

    //                PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
    //                PlayerPrefs.Save();

    //                Debug.Log("Utente Apple salvato: " + PlayerPrefs.HasKey("loggedUser"));

    //                OneSignal.SendTag("id_user", GameData.instance.loggedUser._token);
    //                goNext();

    //            }
    //            else
    //            {
    //                waiting.destroy();
    //                PopupInfo popup = UIController.instance.CreateInfoPopup();
    //                popup.initialize(UIController.instance.mainCanvas,
    //                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
    //                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
    //                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
    //                    "error");
    //            }

    //        }
    //    }

    //    yield return null;
    //}


    #endregion


    /* #region FACEBOOK_LOGIN
    public void signInWithFacebook(WaitingPopup waiting)
    {
        StartCoroutine(_signInWithFacebook(waiting));
    }

    private IEnumerator _signInWithFacebook(WaitingPopup waiting)
    {

        WWWForm form = new WWWForm();
        form.AddField("fbid", GameData.instance.loggedUser._fbID);
        form.AddField("email", GameData.instance.loggedUser._email);
        form.AddField("name", GameData.instance.loggedUser._username);

        using (UnityWebRequest www = UnityWebRequest.Post(APIs.LOGIN_FB_SERVICE, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");

            }

            else
            {
                LoginResponse response = JsonUtility.FromJson<LoginResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    waiting.destroy();
                    GameData.instance.loggedUser._token = response._token;

                    PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(GameData.instance.loggedUser));
                    PlayerPrefs.Save();

                    Debug.Log("Utente facebook salvato: " + PlayerPrefs.HasKey("loggedUser"));

                  OneSignal.User.AddTag("id_user", GameData.instance.loggedUser._token);
                    goNext();

                }
                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }
        }
    }


    #endregion */



}
