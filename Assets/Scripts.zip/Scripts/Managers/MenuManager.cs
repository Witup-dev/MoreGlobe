﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using UnityEngine;
using System.IO;
using System;
using PullToRefresh;
using TMPro;
using Vuplex.WebView;
using SimpleJSON;
using Google;
using OneSignalSDK;
#if UNITY_IOS
using Unity.Notifications.iOS;
#elif UNITY_ANDROID
using UnityEngine.Android;
#endif


public class MenuManager : MonoBehaviour
{

[Header("Singleton")]

    public static MenuManager instance { get; private set; }

[Header("Stato / colori UI")]
    private Color32 notSelectedImage = new Color32(255, 255, 255, 145); //#585858
    private Color32 selectedImage = Color.white;
    private Color32 notSelectedBackground = new Color32(20, 16, 16, 0);//Sfondo notSelected
    private Color32 selectedBackground = new Color32(20, 16, 16, 255);//Sfondo selezionato
    public Sprite defaultImageCamera;
    public Sprite defaultBrandFooterImage;
    private string defaultCameraTxt = "You haven't seen any content yet. Use the option above to discover new ones";
    private Content tmpContent;



[Header("WebView profilo / link esterni")]

    public Transform webViewContainer;
    public Transform webViewExternalLinkContainer;
    private CanvasWebViewPrefab profileView;
    private CanvasWebViewPrefab externalLinkView;
    public GameObject externalLinkLoadingContainer;
    public TextMeshProUGUI loadingExternalLinkText;
    public Sprite loadingImage;
    public Sprite errorImage;



    [Header("PermissionsVariable")]
    public GameObject permissionPanel;
    public GameObject notificationPermission;
    public TextMeshProUGUI installationText;
    public TextMeshProUGUI internetPermissionText;
    public TextMeshProUGUI cameraPermissionText;
    public TextMeshProUGUI gpsPermissionText;
    public TextMeshProUGUI notificationPermissionText;
    public TextMeshProUGUI permissionContinueText;
    public Toggle cameraPermissionToggle;
    public Toggle gpsPermissionToggle;
    public Toggle notificationPermissionToggle;



    [Header("Footer Menu")]

    //public Image homeFooterPanel;
    //public Image brandFooterPanel;
    //public Image libraryFooterPanel;
    //public Image noticeFooterPanel;
    //public Image cameraFooterPanel;
    public Image homeFooterImage;
    public Image brandFooterImage;
    public Image libraryFooterImage;
    public Image noticeFooterImage;
    public Image cameraFooterImage;
    public Image homeSelectedFooterImage;
    public Image brandSelectedFooterImage;
    public Image librarySelectedFooterImage;
    public Image noticeSelectedFooterImage;
    public Image cameraSelectedFooterImage;
    public TextMeshProUGUI homeText;
    public TextMeshProUGUI brandText;
    public TextMeshProUGUI cameraText;
    public TextMeshProUGUI libraryText;
    public TextMeshProUGUI noticeText;




    [Header("Menu Page Container")]

    public GameObject homeContainer;
    public GameObject profileContainer;
    public GameObject libraryContainer;
    public GameObject noticeContainer;




    [Header("Content Page Sections")]

    public GameObject choiceBackButton;
    public GameObject choicePanel;
    public GameObject sportPanel;
    public GameObject newsPanel;
    public GameObject eventsPanel;
    public GameObject profileButton;
    public TextMeshProUGUI sportSectionText;
    public TextMeshProUGUI partnersSectionText;
    public TextMeshProUGUI eventsSectionText;



    [Header("Content grid")]

    public Transform sportGrid;
    public Transform newsList;
    public Transform eventsGrid;
    public TextMeshProUGUI noContentSport;
    public TextMeshProUGUI noContentNews;
    public TextMeshProUGUI noContentEvents;
    public TextMeshProUGUI noContentDownload;
    [SerializeField]
    private bool hasSportLoaded;
    [SerializeField]
    private bool hasEventsLoaded;
    [SerializeField]
    private bool hasNewsLoaded;





    [Header("Library")]

    public Transform libraryList;
    public TextMeshProUGUI libraryTitle;
    private bool hasLibraryPopulated;



    [Header("Notices")]

    public UIRefreshControl m_UIRefreshControl;
    public TextMeshProUGUI noNotice;
    public Transform noticeList;
    public Texture2D defaultNoticeIcon;
    public Sprite newNoticeIcon;
    public Sprite noNewNoticeIcon;
    public TextMeshProUGUI noticeTitle;




    [Header("Project Schema(dettaglio contenuto)")]

    public GameObject projectSchemaContainer;
    public RectTransform schemaContentView;
    public Button projSchemaBackButton;
    public Button projSchemaLogoButton;
    public Image fullScreenAlbum;
    public TextMeshProUGUI contentName;
    public TextMeshProUGUI contentType;
    public TextMeshProUGUI lastedVersion;
    public TextMeshProUGUI detailsText;
    public TextMeshProUGUI connectText;
    public TextMeshProUGUI buyText;
    public TextMeshProUGUI websiteText;
    public TextMeshProUGUI projectName;
    public TextMeshProUGUI projectType;
    public TextMeshProUGUI projectPublishingDate;
    public TextMeshProUGUI projectDescription;
    public Image contentImage;
    public Image projectImage;
    public Sprite defaultLoadImage;
    public Button connect;
    public Button buyProject;
    public Button website;
    public Button extras;




    [Header("Camera tab")]

    public GameObject cameraChoicePanel;
    public Image lastContentImage;
    public TextMeshProUGUI lastTextMsg;
    public TextMeshProUGUI lastTextTitle;
    public TextMeshProUGUI findNewContentTitle;
    public TextMeshProUGUI findNewContentBody;
    public TextMeshProUGUI orText;





    [Header("Profile")]

    public GameObject profileMainBody;
    public GameObject profileBackButton;
    public GameObject logoutButtonPanel;
    public GameObject aboutPage;
    public GameObject tutorialPage;
    public GameObject demoPage;
    public GameObject explainPage;
    public Toggle tutorialToggle;
    public TextMeshProUGUI emailLabel;
    public TextMeshProUGUI usernameLabel;
    public TextMeshProUGUI versionLabel;
    public GameObject loadingProfile;
    public TextMeshProUGUI loadingProfileText;





    [Header("Brand")]
    
    public GameObject brandContainer;
    public Transform brandGrid;
    public TextMeshProUGUI noBrandAvailable;
    private CanvasWebViewPrefab brandView;
    public Transform webViewBrandContainer;
    public GameObject brandLoadingContainer;
    public TextMeshProUGUI loadingBrandText;
    [SerializeField]
    private bool hasBrandLoaded;



    [Header("Prefab UI")]
    public GridListItem gridPrefab;
    public GridListItem listPrefab;
    public InteractiveLibraryItem libraryPrefab;
    public NoticeItem noticePrefab;





 [Header("Notifiche lette")]

    public static List<string> noticesIds;



#region Unity Lifecycle

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        noticesIds = new List<string>();

        resetAllTextForLanguage();

    }

    // Start is called before the first frame update
    void Start()
    {
        hasEventsLoaded = false;
        hasSportLoaded = false;
        hasNewsLoaded = false;
        hasBrandLoaded = false;

        hasLibraryPopulated = false;

        tmpContent = null;

        if (GameData.instance.loggedUser._loginType == "a")//login with apple
        {
            logoutButtonPanel.SetActive(false);
        }



        // if (GameData.instance.selectedCustomContent != null && !string.IsNullOrEmpty(GameData.instance.selectedCustomContent._id))
        // {

        //     if (!string.IsNullOrEmpty(GameData.instance.selectedContentId) && GameData.instance.selectedCustomContent._id.Equals(GameData.instance.selectedContentId))
        //     {
        //         StartCoroutine(Utilities.getImageAndApply(GameData.instance.selectedCustomContent._footerImageLink, brandFooterImage, loadingImage, errorImage));
        //         onBrandPressed();
        //     }

        // }
       
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.Portrait;

        versionLabel.text = Application.version;


        m_UIRefreshControl.OnRefresh.AddListener(refreshNotice);

        populateContentGrids();
        initializeWebView();

        if (DeepLinkManager.instance.hasAction)
        {
            if (DeepLinkManager.instance.actionType == DeepLinkManager.Actions.Content)
            {
                var value = DeepLinkManager.instance.actionValue;

                DeepLinkManager.instance.reset();

                StartCoroutine(askForDownload(value));
            }
        }

        StartCoroutine(fetchNotice());

        OneSignal.User.AddTag("user_lang", GameData.instance.selectedLanguage);

    }


    #endregion
        #region UI / navigazione

    private void disableAll()
    {
        setHomeContainer(false);
        setProfileContainer(false);
        setLibraryContainer(false);
        setNoticeContainer(false);
        setCameraContainer(false);
        setProjectSchemaPanel(false);
        setBrandContainer(false);

        if (permissionPanel.activeInHierarchy)
        {
            webViewContainer.gameObject.SetActive(true);
        }
        permissionPanel.SetActive(false);
    }

        private void disableAllFooter()
    {
        /* homeFooterPanel.color = notSelectedBackground;
        brandFooterPanel.color = notSelectedBackground;
        libraryFooterPanel.color = notSelectedBackground;
        noticeFooterPanel.color = notSelectedBackground;
        cameraFooterPanel.color = notSelectedBackground; */

        homeFooterImage.enabled = true;
        brandFooterImage.enabled = true;
        libraryFooterImage.enabled = true;
        noticeFooterImage.enabled = true;
        cameraFooterImage.enabled = true;

        homeFooterImage.color = notSelectedImage;
        brandFooterImage.color = notSelectedImage;
        libraryFooterImage.color = notSelectedImage;
        noticeFooterImage.color = notSelectedImage;
        cameraFooterImage.color = notSelectedImage;

        homeText.color = notSelectedImage;
        brandText.color = notSelectedImage;
        cameraText.color = notSelectedImage;
        libraryText.color = notSelectedImage;
        noticeText.color = notSelectedImage;

        homeSelectedFooterImage.enabled = false;
        brandSelectedFooterImage.enabled = false;
        librarySelectedFooterImage.enabled = false;
        noticeSelectedFooterImage.enabled = false;
        cameraSelectedFooterImage.enabled = false;

        destroyExternalLInkWebView();
        destroyBrandWebView();

    }

    private void disableAllCategory()
    {
        setSportContainer(false);
        setNewsContainer(false);
        setEventsContainer(false);
    }

    private void disableAllProfilePage()
    {
        setAboutPage(false);
        setTutorialPage(false);
        setDemoPage(false);
        setExplainPage(false);
    }


    //New
    private void setHomeContainer(bool status)
    {
        homeContainer.SetActive(status);
    }

    private void setProfileContainer(bool status)
    {

        profileContainer.SetActive(status);
    }

    private void setLibraryContainer(bool status)
    {
        libraryContainer.SetActive(status);
    }

    private void setBrandContainer(bool status)
    {
        brandContainer.SetActive(status);
    }

    private void setNoticeContainer(bool status)
    {
        noticeContainer.SetActive(status);
    }

    private void setCameraContainer(bool status)
    {
        cameraChoicePanel.SetActive(status);
    }

    private void setChoicePanel(bool status)
    {
        choicePanel.SetActive(status);
    }

    private void setProjectSchemaPanel(bool status)
    {
        if (status)
        {
            disableAll();
        }

        projectSchemaContainer.SetActive(status);
    }

    //Home sub Pages
    private void setSportContainer(bool status)
    {
        sportPanel.SetActive(status);
    }

    private void setNewsContainer(bool status)
    {
        newsPanel.SetActive(status);
    }

    private void setEventsContainer(bool status)
    {
        eventsPanel.SetActive(status);
    }

    private void setChoiceBackButton(bool status)
    {
        choiceBackButton.SetActive(status);
    }

    //Profile sub pages
    private void setProfileBackButton(bool status)
    {
        profileBackButton.SetActive(status);
    }

    private void setMainProfileBody(bool status)
    {
        //profileMainBody.SetActive(status);
    }

    private void setAboutPage(bool status)
    {
        aboutPage.SetActive(status);
    }

    private void setTutorialPage(bool status)
    {
        tutorialPage.SetActive(status);
    }

    private void setDemoPage(bool status)
    {
        demoPage.SetActive(status);
    }

    private void setExplainPage(bool status)
    {
        explainPage.SetActive(status);
    }


    //New

    public void onHomePressed()
    {
        disableAllFooter();
        disableAll();
        disableAllCategory();

        setHomeContainer(true);
        setChoicePanel(true);
        setChoiceBackButton(false);

        //homeFooterPanel.color = selectedBackground;
        homeFooterImage.enabled = false;
        homeSelectedFooterImage.enabled = true;
        homeFooterImage.color = selectedImage;
        homeText.color = selectedImage;
    }


    public void onSportPressed()
    {
        setChoicePanel(false);
        setChoiceBackButton(true);
        setSportContainer(true);

        if (!hasSportLoaded)
        {
            hasSportLoaded = true;
            StartCoroutine(getSportContent());
        }


    }

    public void onNewsPressed()
    {
        setChoicePanel(false);
        setChoiceBackButton(true);
        setNewsContainer(true);

        if (!hasNewsLoaded)
        {
            hasNewsLoaded = true;
            StartCoroutine(getNewsContent());
        }
    }

    public void onEventsPressed()
    {
        setChoicePanel(false);
        setChoiceBackButton(true);
        setEventsContainer(true);

        if (!hasEventsLoaded)
        {
            hasEventsLoaded = true;
            StartCoroutine(getEventContent());
        }

    }


    public void onProfilePressed()
    {
        disableAllFooter();
        disableAll();
        setProfileContainer(true);

        brandSelectedFooterImage.enabled = true;
        brandFooterImage.enabled = false;
        brandFooterImage.color = selectedImage;
        brandText.color = selectedImage;
    }

  public void onCameraPressed()
    {
        disableAllFooter();
        disableAll();

        setCameraContainer(true);
        //cameraFooterPanel.color = selectedBackground;
        cameraSelectedFooterImage.enabled = true;
        cameraFooterImage.enabled = false;
        cameraFooterImage.color = selectedImage;
        cameraText.color = selectedImage;
    }

    public void onLibraryPressed()
    {
        disableAllFooter();
        disableAll();

        setLibraryContainer(true);
        //libraryFooterPanel.color = selectedBackground;
        libraryFooterImage.enabled = false;
        librarySelectedFooterImage.enabled = true;
        libraryFooterImage.color = selectedImage;
        libraryText.color = selectedImage;

        if (!hasLibraryPopulated)
        {
            hasLibraryPopulated = true;
            StartCoroutine(populateUserInterfaces());
        }

// #if UNITY_IOS
// 			NativeNFCManager.Enable();
//         NfcService:Start();
// #endif
    }

    public void onBrandPressed()
    {

        if (!webViewBrandContainer.gameObject.activeInHierarchy)
        {
            disableAll();
            disableAllFooter();

            //brandFooterPanel.color = selectedBackground;
            brandSelectedFooterImage.enabled = true;
            brandFooterImage.enabled = false;
            brandFooterImage.color = selectedImage;
            brandText.color = selectedImage;



            if (!hasBrandLoaded)
            {
                hasBrandLoaded = true;
                StartCoroutine(getBrandContent());
            }

            if (GameData.instance.selectedCustomContent != null && !string.IsNullOrEmpty(GameData.instance.selectedCustomContent._id))
            {

                if (!string.IsNullOrEmpty(GameData.instance.selectedContentId) && GameData.instance.selectedCustomContent._id.Equals(GameData.instance.selectedContentId))
                {
                    if (brandView == null)
                        openNewWebViewForBrand(GameData.instance.selectedCustomContent);
                    else
                        webViewBrandContainer.gameObject.SetActive(true);
                }

            }
        }
        setBrandContainer(true);




    }

    public void onNoticePressed()
    {
        disableAllFooter();
        disableAll();

        setNoticeContainer(true);
        //noticeFooterPanel.color = selectedBackground;
        noticeSelectedFooterImage.enabled = true;
        noticeFooterImage.enabled = false;
        noticeFooterImage.color = selectedImage;
        noticeFooterImage.sprite = noNewNoticeIcon;
        noticeText.color = selectedImage;

    }

    #endregion


#region Flusso profilo / pagine informative

    public void onAboutPressed()
    {
        setMainProfileBody(false);
        setProfileBackButton(true);
        setAboutPage(true);
    }

    public void onTutorialPressed()
    {
        setMainProfileBody(false);
        tutorialPage.GetComponent<ScrollPanel>().resetTutorial();
        setTutorialPage(true);
    }

    public void onDemoARPressed()
    {
        setMainProfileBody(false);
        setProfileBackButton(true);
        setDemoPage(true);
    }

    public void onExplainPagePressed()
    {
        setMainProfileBody(false);
        setProfileBackButton(true);
        setExplainPage(true);
    }

    public void openDemoAR()
    {
        Application.OpenURL("https://www.creatiwa.eu/wp-content/uploads/2020/07/File_AR_DEMO_A4_Printable.pdf");
    }

    #endregion

    #region Permessi / app config

    private IEnumerator loadAsyncScene(string sceneName)
    {

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loadingAR);

#if UNITY_IOS

        yield return getIosCameraPermission(sceneName,waiting);

#elif UNITY_ANDROID


        if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
        {
            var callbacks = new PermissionCallbacks();

            callbacks.PermissionDenied += (name) =>
            {
                GameData.instance.appConfig._cameraPermission = false;

                if (!Permission.ShouldShowRequestPermissionRationale(Permission.Camera))
                {
                    Debug.Log("Camera permission denied and don't ask again");
                   
                }

                waiting.destroy();
            };

            callbacks.PermissionGranted += (name) =>
            {
                GameData.instance.appConfig._cameraPermission = true;
                AsyncOperation asyncLoad =
                    SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Single);
            };

            Permission.RequestUserPermission(Permission.Camera, callbacks);
        }
        else
        {
            GameData.instance.appConfig._cameraPermission = true;
            AsyncOperation asyncLoad =
                SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Single);
        }

        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
#endif


        yield return null;
    }

    private IEnumerator getIosCameraPermission(string sceneName, WaitingPopup waiting)
    {
        foreach (var device in WebCamTexture.devices)
        {
            Debug.Log("Name: " + device.name);
        }

        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
        if (Application.HasUserAuthorization(UserAuthorization.WebCam))
        {
            GameData.instance.appConfig._cameraPermission = true;
            AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Single);
        }
        else
        {
            GameData.instance.appConfig._cameraPermission = false;
        }
        waiting.destroy();


    }

     public void onGPSToggleChange(Toggle value)
    {
        if (value.isOn)
        {
#if UNITY_ANDROID

            if (!Permission.HasUserAuthorizedPermission(Permission.FineLocation))
            {
                var callbacks = new PermissionCallbacks();
                callbacks.PermissionDenied += ((name) =>
                {
                    value.isOn = false;
                });
                callbacks.PermissionGranted += ((name) =>
                {
                    GameData.instance.appConfig._gpsPermission = true;
                    Input.location.Start();
                });

                Permission.RequestUserPermission(Permission.FineLocation, callbacks);
            }
            else
            {
                if (Input.location.isEnabledByUser && Input.location.status == LocationServiceStatus.Stopped)
                    Input.location.Start();
            }


#elif UNITY_IOS
        getIosGPSPermission(value);
#endif
        }

        else
        {
            GameData.instance.appConfig._gpsPermission = false;
            Input.location.Stop();
        }

        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
    }

    public void onCameraToggleChange(Toggle value)
    {

        if (value.isOn)
        {
#if UNITY_ANDROID

            if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
            {
                var callbacks = new PermissionCallbacks();
                callbacks.PermissionDenied += ((name) =>
                {
                    value.isOn = false;
                    GameData.instance.appConfig._cameraPermission = false;
                });
                callbacks.PermissionGranted += ((name) =>
                {
                    GameData.instance.appConfig._cameraPermission = true;
                });

                Permission.RequestUserPermission(Permission.Camera, callbacks);
            }

            else
            {
                GameData.instance.appConfig._cameraPermission = true;
            }

#elif UNITY_IOS
        StartCoroutine(getIosCameraPermission(value));
#endif
        }

        else
        {
            GameData.instance.appConfig._cameraPermission = false;
        }

        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
    }

    public void onNotificationToggleChange(Toggle value)
    {
        if (value.isOn)
        {
#if UNITY_ANDROID

            GameData.instance.appConfig._notificationPermission = true;

#elif UNITY_IOS
            StartCoroutine(getNotificationPermission(value));
#endif
            StartCoroutine(Utilities.handleOnesignalPlayerID(false));
        }

        else
        {
            GameData.instance.appConfig._notificationPermission = false;
            StartCoroutine(Utilities.handleOnesignalPlayerID(true));
        }

        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
    }

    public void permissionContinueButton()
    {
        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();

        webViewContainer.gameObject.SetActive(true);
        permissionPanel.SetActive(false);
    }


    private IEnumerator getIosCameraPermission(Toggle value)
    {
        foreach (var device in WebCamTexture.devices)
        {
            Debug.Log("Name: " + device.name);
        }

        yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
        if (Application.HasUserAuthorization(UserAuthorization.WebCam))
        {
            GameData.instance.appConfig._cameraPermission = true;
        }
        else
        {
            GameData.instance.appConfig._cameraPermission = false;
            value.isOn = false;
        }
        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
    }
    private void getIosGPSPermission(Toggle value)
    {
        if (!Input.location.isEnabledByUser)
        {
            Input.location.Start();

            Input.location.Stop();

            if (!Input.location.isEnabledByUser)
            {
                GameData.instance.appConfig._gpsPermission = false;
                value.isOn = false;
            }

            else
            {
                GameData.instance.appConfig._gpsPermission = true;
                Input.location.Start();
            }
        }

        else
        {
            GameData.instance.appConfig._cameraPermission = true;
            Input.location.Start();
        }
        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
    }
    private IEnumerator getNotificationPermission(Toggle value)
    {
#if UNITY_IOS
        var authorizationOption = AuthorizationOption.Alert | AuthorizationOption.Badge;
        using (var req = new AuthorizationRequest(authorizationOption, true))
        {
            while (!req.IsFinished)
            {
                yield return null;
            };

            if (req.Granted)
            {
                GameData.instance.appConfig._notificationPermission = true;
            }

            else
            {
                GameData.instance.appConfig._notificationPermission = false;
                yield return Utilities.handleOnesignalPlayerID(true);
                value.isOn = false;
            }

        }
        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(GameData.instance.appConfig));
        PlayerPrefs.Save();
#else
        yield return null;
#endif
    }

    #endregion

    #region Download / libreria / contenuti

    private IEnumerator askForDownload(string id)
    {

        yield return getContentFromId(id);

        if (GameData.instance.loggedUser._associatedContent.Contains(id) && GameData.instance.availableDownloadedContent.containsDlc(id))
        {
            GameData.instance.selectedContentId = id;
            PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(tmpContent));
            PlayerPrefs.Save();

            if (tmpContent._isBrand)
            {
                Debug.Log("is Brand");
                CustomizationItem item = new CustomizationItem
                {
                    _id = tmpContent._id,
                    _customPageLink = tmpContent._custom_page,
                    _footerImageLink = tmpContent._tabbar_logo,
                    _splashImageLink = tmpContent._splash_logo
                };

                handleCustomization(false, item);
                yield return Utilities.donwloadLocallyImageAsBytes(tmpContent._splash_logo, Application.persistentDataPath, "customSplash.png");
            }
            else
            {
                handleCustomization(true);
                PlayerPrefs.DeleteKey("customContent");
                PlayerPrefs.Save();
            }
            goToLocalAR();

        }

        else
        {

            PopupChoiceMessage choice = UIController.instance.CreateChoicePopup();
            choice.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupChoiceJson[0]._title,
                GameData.instance.currentLanguage._popupChoiceJson[0]._message.Replace("{}", tmpContent._contentName),
                GameData.instance.currentLanguage._popupChoiceJson[0]._positive,
                GameData.instance.currentLanguage._popupChoiceJson[0]._negative,
                () =>
                {
                    GameObject.Destroy(choice.gameObject);
                    StartCoroutine(downloadDLC(id));
                });
        }


    }

    private void handleCustomization(bool haveToDelete, CustomizationItem c = null)
    {
        if (haveToDelete)
        {
            if (PlayerPrefs.HasKey("customContent"))
            {
                GameData.instance.selectedCustomContent = null;
                PlayerPrefs.DeleteKey("customContent");
                PlayerPrefs.Save();
            }

            // brandFooterImage.sprite = defaultBrandFooterImage;

            var file = Path.Combine(Application.persistentDataPath, "customSplash.png");
            if (File.Exists(file)) File.Delete(file);
        }

        else
        {
            if (c == null) return;

            GameData.instance.selectedCustomContent = c;
            PlayerPrefs.SetString("customContent", JsonUtility.ToJson(c));
            PlayerPrefs.Save();
            Debug.Log("custom salvato");
        }
    }

    private void resetProjSchema()
    {
        contentName.text = GameData.instance.currentLanguage._loading;
        contentType.text = GameData.instance.currentLanguage._loading;
        lastedVersion.text = GameData.instance.currentLanguage._loading;

        projectDescription.text = "";

        contentImage.sprite = defaultLoadImage;
        projectImage.sprite = defaultLoadImage;
        fullScreenAlbum.sprite = defaultLoadImage;

        connect.onClick.RemoveAllListeners();
        website.onClick.RemoveAllListeners();
        extras.onClick.RemoveAllListeners();
        buyProject.onClick.RemoveAllListeners();
        projSchemaLogoButton.onClick.RemoveAllListeners();
        projSchemaBackButton.onClick.RemoveAllListeners();

        website.gameObject.SetActive(false);
        buyProject.gameObject.SetActive(false);
        extras.gameObject.SetActive(false);

    }

   

    private void showDetailProjectSchema(string id, Action panelAction)
    {

        resetProjSchema();
        schemaContentView.position = new Vector2(schemaContentView.rect.position.x, 0);
        setProjectSchemaPanel(true);
        StartCoroutine(_showDetailProjectSchema(id, panelAction));
    }

    private IEnumerator _showDetailProjectSchema(string id, Action panelAction)
    {

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CONTENT_UPDATE + "/" + id + "?lang=" + GameData.instance.selectedLanguage))
        {

            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                _showDetailProjectSchema(id, panelAction);
            }

            else
            {
                ProjectContentResponse response = JsonUtility.FromJson<ProjectContentResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    var c = response._content;

                    using (var imgreq = UnityWebRequestTexture.GetTexture(c._thumbnailDescription))
                    {
                        yield return imgreq.SendWebRequest();

                        if (imgreq.result != UnityWebRequest.Result.Success)
                        {
                            Debug.Log(imgreq.error);
                        }
                        else
                        {
                            if (imgreq.isDone)
                            {
                                Texture2D t = DownloadHandlerTexture.GetContent(imgreq);
                                projectImage.sprite = Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0.5f, 0.5f));
                                fullScreenAlbum.sprite = projectImage.sprite;

                            }
                        }
                    }


                    contentName.text = c._contentName;
                    contentType.text = c._category;
                    lastedVersion.text = GameData.instance.currentLanguage._latestVersion + " " + c._version;

                    projectDescription.text = c._longDescription;


                    StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, contentImage, loadingImage, errorImage));



                    if (c._expired || !c._connect)
                    {
                        string title;
                        string message;
                        string buttonText;

                        if (c._expired)
                        {
                            title = GameData.instance.currentLanguage._popupInfoJson[19]._title;
                            message = GameData.instance.currentLanguage._popupInfoJson[19]._message;
                            buttonText = GameData.instance.currentLanguage._popupInfoJson[19]._buttonText;
                        }

                        else
                        {
                            title = GameData.instance.currentLanguage._popupInfoJson[18]._title;
                            message = GameData.instance.currentLanguage._popupInfoJson[18]._message;
                            buttonText = GameData.instance.currentLanguage._popupInfoJson[18]._buttonText;
                        }

                        connect.onClick.AddListener(() =>
                        {
                            PopupInfo popup = UIController.instance.CreateInfoPopup();
                            popup.initialize(UIController.instance.mainCanvas,
                                title,
                                message,
                                buttonText,
                                "error");
                        });


                    }
                    else
                    {
                        //attivo
                        connect.onClick.AddListener(() =>
                        {
                            StartCoroutine(askForDownload(c._id));
                        });
                    }



                    projSchemaBackButton.onClick.AddListener(() =>
                    {

                        setProjectSchemaPanel(false);
                        panelAction();

                    });

                    projSchemaLogoButton.onClick.AddListener(() =>
                    {

                        setProjectSchemaPanel(false);
                        panelAction();

                    });

                    if (string.IsNullOrEmpty(c._websiteShop))
                    {
                        buyProject.gameObject.SetActive(false);
                    }

                    else
                    {
                        buyProject.gameObject.SetActive(true);

                        buyProject.onClick.AddListener(() =>
                        {
                            Application.OpenURL(c._websiteShop);
                        });
                    }

                    if (string.IsNullOrEmpty(c._website))
                    {
                        website.gameObject.SetActive(false);
                    }

                    else
                    {
                        website.gameObject.SetActive(true);
                        website.onClick.AddListener(() =>
                        {
                            Application.OpenURL(c._website);
                        });
                    }

                    if (string.IsNullOrEmpty(c._extra))
                    {
                        extras.gameObject.SetActive(false);
                    }

                    else
                    {
                        extras.gameObject.SetActive(true);

                        extras.onClick.AddListener(() =>
                        {
                            Debug.Log("premuto");
                            openNewWebViewForExternalLInk(c._extra);
                        });
                    }


                }

            }

        }
    }


    private void populateContentGrids()
    {
        usernameLabel.text = GameData.instance.loggedUser._username;
        emailLabel.text = GameData.instance.loggedUser._email;

#if UNITY_IOS
        notificationPermission.SetActive(true);
#endif

        cameraPermissionToggle.isOn = GameData.instance.appConfig._cameraPermission;
        gpsPermissionToggle.isOn = GameData.instance.appConfig._gpsPermission;
        notificationPermissionToggle.isOn = GameData.instance.appConfig._notificationPermission;

        if (PlayerPrefs.HasKey("lastContentViewed"))
        {
            var c = JsonUtility.FromJson<Content>(PlayerPrefs.GetString("lastContentViewed"));

            GameData.instance.selectedContentId = c._id;

            StartCoroutine(checkForContentExpired(c._id));


            StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, lastContentImage, loadingImage, errorImage));

            lastTextMsg.text = GameData.instance.currentLanguage._keepWatchingBody.Replace("{}", c._contentName);
        }

        else
        {
            lastTextMsg.text = GameData.instance.currentLanguage._keepWatchingBodyNo;
        }



    }

    private IEnumerator checkForContentExpired(string id)
    {
        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CONTENT_UPDATE + "/" + id))
        {

            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                checkForContentExpired(id);
            }

            else
            {
                ProjectContentResponse response = JsonUtility.FromJson<ProjectContentResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    if (response._content._expired)
                        lastContentImage.transform.parent.parent.GetComponent<Button>().interactable = false;
                    else
                        lastContentImage.transform.parent.parent.GetComponent<Button>().interactable = true;

                }

            }

        }
    }

    private IEnumerator populateUserInterfaces()
    {

        if (isLibraryEmpty())
        {
            noContentDownload.gameObject.SetActive(true);
        }

        else
        {
            using (UnityWebRequest www = UnityWebRequest.PostWwwForm(APIs.LOGGED_USER_ACTION + GameData.instance.loggedUser._token + "/LIST", string.Empty))
            {
                yield return www.SendWebRequest();

                //Se c'è un errore nella request 
                if (www.result != UnityWebRequest.Result.Success)
                {
                    Debug.Log(www.error);
                }

                else
                {
                    UserContentResponse response = JsonUtility.FromJson<UserContentResponse>(www.downloadHandler.text);

                    if (response._success)
                    {
                        foreach (var c in response._data)
                        {

                            if (GameData.instance.availableDownloadedContent.containsDlc(c._id_content))
                            {
                                InteractiveLibraryItem g = Instantiate(libraryPrefab, libraryList, false);

                                g.name = c._id_content;

                                StartCoroutine(Utilities.getImageAndApply(c._thumbnailLibraryLink, g.image, loadingImage, errorImage)); //yield return

                                g.title.text = c._contentName;

                                g.message.text = c._description;

                                g.deleteButton.onClick.AddListener(() =>
                                {

                                    PopupChoiceMessage choice = UIController.instance.CreateChoicePopup();
                                    choice.initialize(UIController.instance.mainCanvas,
                                        GameData.instance.currentLanguage._popupChoiceJson[1]._title,
                                        GameData.instance.currentLanguage._popupChoiceJson[1]._message.Replace("{}", c._contentName),
                                        GameData.instance.currentLanguage._popupChoiceJson[1]._positive,
                                        GameData.instance.currentLanguage._popupChoiceJson[1]._negative,
                                        () =>
                                        {
                                            GameObject.Destroy(choice.gameObject);
                                            g.destroyItem();

                                            if (!string.IsNullOrEmpty(GameData.instance.selectedContentId) && GameData.instance.selectedCustomContent != null && GameData.instance.selectedCustomContent._id.Equals(GameData.instance.selectedContentId))
                                            {
                                                handleCustomization(true);
                                            }

                                            StartCoroutine(deleteDLC(c._id_content));

                                        });

                                });


                                if (c._expired)
                                    g.imageBtn.interactable = false;
                                else
                                    g.imageBtn.interactable = true;

                                g.imageBtn.onClick.AddListener(() =>
                                {
                                    StartCoroutine(askForDownload(c._id_content));
                                });

                                g.detailsButton.onClick.AddListener(() =>
                                {
                                    showDetailProjectSchema(c._id_content, onLibraryPressed);

                                });

                            }


                        }

                    }
                }
            }

        }
    }


    private bool isLibraryEmpty()
    {
        foreach (var id in GameData.instance.loggedUser._associatedContent)
        {
            if (GameData.instance.availableDownloadedContent.containsDlc(id))
                return false;
        }

        return true;
    }

    //Optimization function

    private IEnumerator getSportContent()
    {
        using (UnityWebRequest www = UnityWebRequest.Get(APIs.TAKE_CONTENTS + "sport" + "&lang=" + GameData.instance.selectedLanguage))
        {

            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                StartCoroutine(getSportContent());
            }

            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._contents.Count == 0)
                {
                    noContentSport.gameObject.SetActive(true);
                }

                else
                {
                    noContentSport.gameObject.SetActive(false);


                    foreach (Content c in response._contents)
                    {


                        if (!c._isOnlyCloud)
                        {
                            GridListItem g;

                            g = Instantiate(gridPrefab);

                            g.name = c._id;

                            StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, g.image, loadingImage, errorImage));////yield return

                            if (GameData.instance.loggedUser._associatedContent.Contains(c._id) && GameData.instance.availableDownloadedContent.containsDlc(c._id))
                            {
                                g.checkImage.SetActive(true);
                            }

                            g.panelButton.onClick.AddListener(() =>
                            {

                                showDetailProjectSchema(c._id, () =>
                                {
                                    onHomePressed();
                                    onSportPressed();
                                });
                            });


                            g.transform.SetParent(sportGrid, false);
                            g.text.text = c._contentName;
                        }

                        changeContentDownloadedStatus(c, true);

                        yield return new WaitForEndOfFrame();
                    }


                }

            }

        }

    }

    private IEnumerator getEventContent()
    {

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.TAKE_CONTENTS + "events" + "&lang=" + GameData.instance.selectedLanguage))
        {

            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                StartCoroutine(getEventContent());
            }

            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._contents.Count == 0)
                {
                    noContentEvents.gameObject.SetActive(true);
                }

                else
                {

                    noContentEvents.gameObject.SetActive(false);

                    foreach (Content c in response._contents)
                    {


                        if (!c._isOnlyCloud)
                        {
                            GridListItem g;

                            g = Instantiate(listPrefab);

                            if (string.IsNullOrEmpty(c._description))
                            {
                                g.image.transform.parent.GetComponent<RectTransform>().sizeDelta =
                                    new Vector2(0, 350);

                                g.text.transform.parent.gameObject.SetActive(false);
                            }

                            g.name = c._id;


                            StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, g.image, loadingImage, errorImage));////yield return

                            if (GameData.instance.loggedUser._associatedContent.Contains(c._id) && GameData.instance.availableDownloadedContent.containsDlc(c._id))
                            {
                                g.checkImage.SetActive(true);
                            }

                            g.panelButton.onClick.AddListener(() =>
                            {

                                showDetailProjectSchema(c._id, () =>
                                {
                                    onHomePressed();
                                    onEventsPressed();
                                });
                            });


                            g.transform.SetParent(eventsGrid, false);
                            g.text.text = c._contentName;
                        }
                        changeContentDownloadedStatus(c, true);
                        yield return new WaitForEndOfFrame();
                    }



                }




            }

        }
    }

    private IEnumerator getNewsContent()
    {

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.TAKE_CONTENTS + "news" + "&lang=" + GameData.instance.selectedLanguage))
        {

            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                StartCoroutine(getNewsContent());
            }

            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._contents.Count == 0)
                {
                    noContentNews.gameObject.SetActive(true);
                }


                else
                {

                    noContentNews.gameObject.SetActive(false);

                    foreach (Content c in response._contents)
                    {

                        if (!c._isOnlyCloud)
                        {
                            GridListItem g;

                            g = Instantiate(listPrefab);

                            if (string.IsNullOrEmpty(c._description))
                            {
                                g.image.transform.parent.GetComponent<RectTransform>().sizeDelta =
                                    new Vector2(0, 350);

                                g.text.transform.parent.gameObject.SetActive(false);
                            }

                            g.name = c._id;


                            StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, g.image, loadingImage, errorImage));////yield return

                            if (GameData.instance.loggedUser._associatedContent.Contains(c._id) && GameData.instance.availableDownloadedContent.containsDlc(c._id))
                            {
                                g.checkImage.SetActive(true);
                            }

                            g.panelButton.onClick.AddListener(() =>
                            {

                                showDetailProjectSchema(c._id, () =>
                                {
                                    onHomePressed();
                                    onNewsPressed();
                                });
                            });


                            g.transform.SetParent(newsList, false);
                            g.text.text = c._description;
                        }
                        changeContentDownloadedStatus(c, true);
                        yield return new WaitForEndOfFrame();
                    }



                }



            }

        }

    }

    private IEnumerator getBrandContent()
    {
        using (UnityWebRequest www = UnityWebRequest.Get(APIs.TAKE_BRAND_PAGES + "&lang=" + GameData.instance.selectedLanguage))
        {

            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                StartCoroutine(getBrandContent());
            }

            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._contents.Count == 0)
                {
                    noBrandAvailable.gameObject.SetActive(true);
                }

                else
                {
                    noBrandAvailable.gameObject.SetActive(false);


                    foreach (Content c in response._contents)
                    {


                        GridListItem g;

                        g = Instantiate(gridPrefab);

                        StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, g.image, loadingImage, errorImage));


                        g.panelButton.onClick.AddListener(() =>
                        {

                            CustomizationItem item = new CustomizationItem
                            {
                                _id = c._id,
                                _customPageLink = c._custom_page,
                                _footerImageLink = c._tabbar_logo,
                                _splashImageLink = c._splash_logo
                            };

                            openNewWebViewForBrand(item);

                        });


                        g.transform.SetParent(brandGrid, false);
                        g.text.text = c._contentName;

                        yield return new WaitForEndOfFrame();
                    }



                    if (response._contents.Count > 0 && response._contents.Count < 3)
                    {
                        for (int i = 0; i < 3 - response._contents.Count; i++)
                        {
                            GridListItem g;

                            g = Instantiate(gridPrefab);
                            Destroy(g.image);
                            g.name = "empty";
                            g.transform.SetParent(brandGrid, false);
                        }
                    }

                }

            }

        }
    }


    private IEnumerator getContentFromId(string id)
    {
        string requestData = GameData.instance.loggedUser._token + "/" + id + "/0";

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_AND_DOWNLOAD_DLC + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }


            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    tmpContent = response._contents[0];


                }

            }

        }
    }

     private IEnumerator downloadDLC(string id)
    {
        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();

        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._initializating);

        DLC dlc = new DLC(id);

        string requestData = GameData.instance.loggedUser._token + "/" + id + "/" + dlc._version;

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_AND_DOWNLOAD_DLC + requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                waiting.destroy();
                Debug.LogError(www.error);
                PopupInfo popup = UIController.instance.CreateInfoPopup();


                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[0]._title,
                    GameData.instance.currentLanguage._popupInfoJson[0]._message,
                    GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                    "error");
            }


            else
            {
                ContentRequestResponse response = JsonUtility.FromJson<ContentRequestResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    Content c = response._contents[0];

                    if (dlc._id.Equals(c._id))
                    {

                        waiting.destroy();

                        DownloadPopup downPopup = UIController.instance.CreateDownloadPopup();
                        downPopup.initialize(UIController.instance.mainCanvas);

                        yield return DownloadManager.downloadDLC(c, downPopup);

                        if (Directory.Exists(Path.Combine(SaveLoadManager.DLCPATH, dlc._id)))
                        {

                            dlc._version = c._version;
                            dlc._downloadDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                            //GameData.instance.userDLCMap.Add(dlc._id, dlc);
                            //aggiungo il dlc ai contenuti scaricati dall'utente in locale, faccio la chiamata per comunicare il download e aggiorno i contenuti già scaricati
                            if (!GameData.instance.loggedUser._associatedContent.Contains(dlc._id))
                                GameData.instance.loggedUser._associatedContent.Add(dlc._id);

                            if (!GameData.instance.availableDownloadedContent.containsDlc(dlc._id)) //Indica quali contenuti sono stati già scaricati e ne tiene traccia della versione
                            {
                                GameData.instance.availableDownloadedContent._dlcs.Add(dlc);

                                PlayerPrefs.SetString("availableContents", JsonUtility.ToJson(GameData.instance.availableDownloadedContent));
                                PlayerPrefs.Save();
                            }

                            yield return DownloadManager.UserDownloadDLC(dlc._id);

                            Analytics.instance.packageManaging(1, c._id);

                            GameData.instance.selectedContentId = c._id;
                            PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(c));
                            PlayerPrefs.Save();
                            OneSignal.User.AddTag("content-" + c._id, "1");

                            if (c._isBrand)
                            {
                                Debug.Log("is Brand");
                                CustomizationItem item = new CustomizationItem
                                {
                                    _id = c._id,
                                    _customPageLink = c._custom_page,
                                    _footerImageLink = c._tabbar_logo,
                                    _splashImageLink = c._splash_logo
                                };

                                handleCustomization(false, item);
                                yield return Utilities.donwloadLocallyImageAsBytes(c._splash_logo, Application.persistentDataPath, "customSplash.png");
                            }


                            goToLocalAR();

                        }
                    }
                }

                else
                {
                    waiting.destroy();
                    PopupInfo popup = UIController.instance.CreateInfoPopup();
                    popup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[0]._title,
                        GameData.instance.currentLanguage._popupInfoJson[0]._message,
                        GameData.instance.currentLanguage._popupInfoJson[0]._buttonText,
                        "error");
                }

            }

        }

        yield return null;
    }


    private IEnumerator deleteDLC(string id)
    {

        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._deletingInProgress);

        yield return DownloadManager.deleteDLCFromFileSystem(id);

        yield return getContentFromId(id);


        GameData.instance.loggedUser._associatedContent.Remove(id);

        if (GameData.instance.availableDownloadedContent.containsDlc(id)) //Indica quali contenuti sono stati già scaricati e ne tiene traccia della versione
        {
            GameData.instance.availableDownloadedContent.removeDlc(id);

            PlayerPrefs.SetString("availableContents", JsonUtility.ToJson(GameData.instance.availableDownloadedContent));
            PlayerPrefs.Save();
        }

        yield return DownloadManager.UserDeleteDLC(id);

        if (!tmpContent._isOnlyCloud)
        {
            yield return changeContentDownloadedStatus(tmpContent, false);
        }

        //Cancellare il contenuto
        if (libraryList.Find(tmpContent._id) != null)
        {
            Destroy(libraryList.Find(tmpContent._id).gameObject);
        }

        if (isLibraryEmpty())
        {
            noContentDownload.gameObject.SetActive(true);
        }


        if (GameData.instance.selectedContentId == id)
        {
            lastContentImage.sprite = defaultImageCamera;
            lastTextMsg.text = defaultCameraTxt;
            GameData.instance.selectedContentId = string.Empty;
            PlayerPrefs.DeleteKey("lastContentViewed");
            PlayerPrefs.Save();
        }

        if (GameData.instance.loggedUser._associatedContent.Count == 0)
            noContentDownload.gameObject.SetActive(true);


        Analytics.instance.packageManaging(2, id);

        OneSignal.User.RemoveTag("content-" + id);
        waiting.destroy();

        PopupInfo popup = UIController.instance.CreateInfoPopup();
        popup.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupInfoJson[3]._title,
            GameData.instance.currentLanguage._popupInfoJson[3]._message,
            GameData.instance.currentLanguage._popupInfoJson[3]._buttonText,
            default);

        yield return null;
    }


    private IEnumerator changeContentDownloadedStatus(Content c, bool status)
    {
        if (!c._isOnlyCloud)
        {
            switch (c._category)
            {
                case "sport":
                    {
                        if (hasSportLoaded)
                            sportGrid.Find(c._id).GetComponent<GridListItem>().checkImage.SetActive(status);
                        break;
                    }

                case "news":
                    {
                        if (hasNewsLoaded)
                            newsList.Find(c._id).GetComponent<GridListItem>().checkImage.SetActive(status);
                        break;
                    }

                case "events":
                    {
                        if (hasEventsLoaded)
                            eventsGrid.Find(c._id).GetComponent<GridListItem>().checkImage.SetActive(status);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }


        yield return null;
    }


    #endregion

    #region Scene AR / logout

    public void goToAR()
    {

        StartCoroutine(loadAsyncScene("ARScene"));

    }

    public void goToLocalAR()
    {
        StartCoroutine(loadAsyncScene("LocalMarkerScene"));

    }

    public void goToLastContent()
    {
        if (!PlayerPrefs.HasKey("lastContentViewed"))
        {
            goToAR();
        }

        else
        {
            goToLocalAR();
        }
    }

    public void openWebDemo()
    {
        Application.OpenURL("https://www.creatiwa.eu/wp-content/uploads/2020/07/File_AR_DEMO_A4_Printable.pdf");
    }

    public void logout()
    {
        StartCoroutine(_logOut());
    }

    public IEnumerator _logOut()
    {
        WaitingPopup waiting = UIController.instance.CreateWaitingPopup();
        waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._loggingOut);


        GameData.instance.hasLoadUserContent = false;
        GameData.instance.hasStartAR = false;

        yield return Utilities.handleOnesignalPlayerID(true);

        if (GameData.instance.loggedUser._loginType.Equals("g"))
        {
            GoogleSignIn.DefaultInstance.SignOut();
        }

        else if (GameData.instance.loginMode != null)
        {

            GameData.instance.loginMode.logout();
            GameData.instance.loginMode.destroy();
            GameData.instance.loginMode = null;

        }

        GameData.instance.loggedUser = new User();
        PlayerPrefs.DeleteKey("loggedUser");
        PlayerPrefs.DeleteKey("lastContentViewed");
        PlayerPrefs.DeleteKey("customContent");
        PlayerPrefs.Save();


        SceneManager.LoadScene("LoginScene", LoadSceneMode.Single);
        yield return null;
    }

    #endregion

    #region Social Button

    public void goOnFacebook()
    {
        Application.OpenURL("https://www.facebook.com/creatiwastudio");
    }

    public void goOnTiktok()
    {
        Application.OpenURL("https://vm.tiktok.com/ZSxEcdpb/");
    }

    public void goOnInstagram()
    {
        Application.OpenURL("https://www.instagram.com/creatiwastudio/?hl=it");
    }

    #endregion

    #region Notifiche

     private IEnumerator fetchNotice()
    {

        bool haveNewNotice = false;

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_FOR_NOTIFICATION + GameData.instance.loggedUser._token + "/?lang=" + GameData.instance.selectedLanguage))
        {
            yield return www.SendWebRequest();
            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);

            }


            else
            {
                NoticeResponse response = JsonUtility.FromJson<NoticeResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    if (response._notices.Count > 0)
                    {

                        //yield return cleanNotice();

                        noNotice.gameObject.SetActive(false);
                        response._notices.Reverse();
                        foreach (Notice n in response._notices)
                        {
                            if (!noticesIds.Contains(n._id))
                            {

                                noticesIds.Add(n._id);

                                Texture2D img = null;

                                using (var imgreq = UnityWebRequestTexture.GetTexture(n._icon))
                                {
                                    yield return imgreq.SendWebRequest();

                                    if (imgreq.result != UnityWebRequest.Result.Success)
                                    {
                                        Debug.Log(imgreq.error);
                                        img = defaultNoticeIcon;
                                    }
                                    else
                                    {
                                        if (imgreq.isDone)
                                        {
                                            img = DownloadHandlerTexture.GetContent(imgreq);
                                        }
                                    }
                                }

                                NoticeItem notice = Instantiate(noticePrefab, noticeList, false);
                                var notBeh = notice.GetComponent<NotificationBehaviour>();

                                notice.id = n._id;
                                notice.image.sprite = Sprite.Create(img, new Rect(0, 0, img.width, img.height), new Vector2(0.5f, 0.5f));
                                notice.title.text = n._title;
                                notice.message.text = n._message;

                                Action behaviour;

                                if (n._action.Equals(Utilities.NOTICEACTION[0]))
                                {

                                    behaviour = (() =>
                                    {
                                        notBeh.readNotice();
                                        StartCoroutine(askForDownload(n._action_value));
                                    });
                                }

                                else if (n._action.Equals(Utilities.NOTICEACTION[1]))
                                {
                                    behaviour = (() =>
                                    {


                                        notBeh.markNoticeAsRead();

                                        showDetailProjectSchema(n._action_value, onNoticePressed);

                                    });
                                }

                                else if (n._action.Equals(Utilities.NOTICEACTION[2]))
                                {
                                    behaviour = (() =>
                                    {


                                        notBeh.markNoticeAsRead();
                                        Application.OpenURL(n._action_value);

                                    });
                                }

                                else
                                {
                                    behaviour = (() =>
                                    {


                                        notBeh.markNoticeAsRead();
                                        openNewWebViewForExternalLInk(n._action_value);

                                    });
                                }

                                notBeh.noticeBtn.onClick.AddListener(() =>
                                {

                                    behaviour.Invoke();

                                });


                                if (!string.IsNullOrEmpty(n._id_read_notification))
                                {
                                    notBeh.markAsRead.interactable = false;
                                    notice.gameObject.GetComponentInChildren<CanvasGroup>().alpha = 0.70f;
                                }

                                else
                                {
                                    haveNewNotice = true;
                                }

                            }

                        }

                        if (haveNewNotice)
                        {
                            haveNewNotice = false;

                            if (!noticeContainer.gameObject.activeInHierarchy)
                            {
                                noticeFooterImage.sprite = newNoticeIcon;
                            }

                        }

                    }

                    else
                    {
                        noNotice.gameObject.SetActive(true);
                    }

                }

                else
                {
                    noNotice.gameObject.SetActive(true);
                }

            }

        }

    }

    private IEnumerator cleanNotice()
    {
        while (noticeList.childCount > 1)
        {
            Destroy(transform.GetChild(1).gameObject);
            yield return new WaitForEndOfFrame();
        }

        yield return null;
    }



    private IEnumerator _refreshNotice()
    {
        // Instead of data acquisition.
        //yield return new WaitForSeconds(1.5f);
        yield return fetchNotice();

        // Call EndRefreshing() when refresh is over.
        m_UIRefreshControl.EndRefreshing();
    }

    

    private void refreshNotice()
    {
        StartCoroutine(_refreshNotice());
    }

    // Register the callback you want to call to OnRefresh when refresh starts.
    public void onRefreshCallback()
    {
        Debug.Log("OnRefresh called.");
    }

    #endregion

    #region Altre routine

    public void exit()
    {
        Application.Quit();
    }

    public void openLink(string link)
    {
        Application.OpenURL(link);
    }

    public void openVideoTutorial()
    {
        Application.OpenURL("https://www.youtube.com/watch?v=xArMYVE7fqk");
    }

  public void onProfileLanguageChanged()
    {
        resetAllTextForLanguage();

        if (PlayerPrefs.HasKey("lastContentViewed"))
        {
            var c = JsonUtility.FromJson<Content>(PlayerPrefs.GetString("lastContentViewed"));

            lastTextMsg.text = GameData.instance.currentLanguage._keepWatchingBody.Replace("{}", c._contentName);
        }

        else
        {
            lastTextMsg.text = GameData.instance.currentLanguage._keepWatchingBodyNo;
        }

        if (hasSportLoaded)
        {
            foreach (Transform child in sportGrid)
            {
                Destroy(child.gameObject);
            }
            hasSportLoaded = false;
        }

        if (hasEventsLoaded)
        {
            foreach (Transform child in eventsGrid)
            {
                Destroy(child.gameObject);
            }
            hasEventsLoaded = false;
        }

        if (hasNewsLoaded)
        {
            foreach (Transform child in newsList)
            {
                Destroy(child.gameObject);
            }
            hasNewsLoaded = false;
        }

        if (hasLibraryPopulated)
        {
            foreach (Transform child in libraryList)
            {
                Destroy(child.gameObject);
            }
            hasLibraryPopulated = false;
        }

        if (hasBrandLoaded)
        {
            foreach (Transform child in brandGrid)
            {
                Destroy(child.gameObject);
            }
            hasBrandLoaded = false;
        }

        if (noticeList.childCount > 1)
        {
            for (int i = 1; i < noticeList.childCount; i++)
            {
                Destroy(noticeList.GetChild(i).gameObject);
            }

            noticesIds = new List<string>();

            StartCoroutine(fetchNotice());
        }

    }


    






    public void resetAllTextForLanguage()
    {
        lastTextTitle.text = GameData.instance.currentLanguage._keepWatchingTitle;
        findNewContentTitle.text = GameData.instance.currentLanguage._findNewContentTitle;
        findNewContentBody.text = GameData.instance.currentLanguage._findNewContentBody;
        noContentSport.text = GameData.instance.currentLanguage._noContentAvailable;
        noContentNews.text = GameData.instance.currentLanguage._noContentAvailable;
        noContentEvents.text = GameData.instance.currentLanguage._noContentAvailable;
        noContentDownload.text = GameData.instance.currentLanguage._noContentDownloaded;
        noNotice.text = GameData.instance.currentLanguage._noNotification;
        detailsText.text = GameData.instance.currentLanguage._detail.ToUpper();

        orText.text = GameData.instance.currentLanguage._or;
        noticeTitle.text = GameData.instance.currentLanguage._noticeSection;
        libraryTitle.text = GameData.instance.currentLanguage._librarySection;

        loadingProfileText.text = GameData.instance.currentLanguage._loadingProfile;
        loadingExternalLinkText.text = GameData.instance.currentLanguage._loading;
        loadingBrandText.text = GameData.instance.currentLanguage._loading;

        homeText.text = GameData.instance.currentLanguage._homeFooter;
        #region HUB
        brandText.text = GameData.instance.currentLanguage._profileFooter;
        #endregion
        cameraText.text = GameData.instance.currentLanguage._cameraFooter;
        libraryText.text = GameData.instance.currentLanguage._libraryFooter;
        noticeText.text = GameData.instance.currentLanguage._noticeFooter;

        sportSectionText.text = GameData.instance.currentLanguage._contentSportText;
        partnersSectionText.text = GameData.instance.currentLanguage._contentPartnersText;
        eventsSectionText.text = GameData.instance.currentLanguage._contentEventsText;

        buyText.text = GameData.instance.currentLanguage._buyButtonText;
        websiteText.text = GameData.instance.currentLanguage._websiteButtontext;

        installationText.text = GameData.instance.currentLanguage._completeInstallation;
        internetPermissionText.text = GameData.instance.currentLanguage._internetPermission;
        cameraPermissionText.text = GameData.instance.currentLanguage._cameraPermission;
        gpsPermissionText.text = GameData.instance.currentLanguage._gpsPermission;
        notificationPermissionText.text = GameData.instance.currentLanguage._notificationPermission;
        permissionContinueText.text = GameData.instance.currentLanguage._confirm;
    }

    #endregion

    #region WebView / profilo / brand / link esterni  
    public void initializeWebView()
    {

        string newUri = APIs.PROFILE_VIEW + GameData.instance.loggedUser._token + "&language=" + GameData.instance.selectedLanguage + "&version=" + Application.version;


        Web.ClearAllData();
        profileView = CanvasWebViewPrefab.Instantiate();
        profileView.transform.SetParent(webViewContainer);
        var rectTransform = profileView.transform as RectTransform;
        rectTransform.anchoredPosition3D = Vector3.zero;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        profileView.Resolution = 1300;
        profileView.transform.localScale = Vector3.one;

        profileView.Native2DModeEnabled = true;

        Web.SetAutoplayEnabled(true);
        Web.SetUserAgent(true);

        profileView.Initialized += (sender, e) =>
        {
            (profileView.WebView as IWithNative2DMode).SetNativeZoomEnabled(false);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif


            //string newUri = APIs.PROFILE_VIEW + GameData.instance.loggedUser._token + "&language="+GameData.instance.selectedLanguage+"&os="+os;
            Debug.Log("urlo di profilo: " + newUri);
            profileView.WebView.LoadUrl(newUri);

            profileView.WebView.LoadProgressChanged += (s, eventArgs) =>
            {
                if (eventArgs.Type == ProgressChangeType.Finished && profileView.WebView.Url.Equals(newUri))
                {
                    Debug.Log(profileView.WebView.Url);
                    Destroy(loadingProfile);
                }

            };


            profileView.WebView.MessageEmitted += (sender2, eventArgs2) =>
            {
                Debug.Log("received from WebView: " + eventArgs2.Value);

                var jobj = JSON.Parse(eventArgs2.Value);

                if (jobj["type"].Equals("logout"))
                {

                    logout();
                }

                else if (jobj["type"].Equals("gotocontent"))
                {

                    showDetailProjectSchema(jobj["value"], onLibraryPressed);
                }

                else if (jobj["type"].Equals("external"))
                {
                    Application.OpenURL(jobj["value"]);
                }

                else if (jobj["type"].Equals("language"))
                {
                    GameData.instance.selectedLanguage = jobj["value"];
                    OneSignal.User.AddTag("user_lang", GameData.instance.selectedLanguage);
                    var jsonLanguageFile = Resources.Load("Localization/" + jobj["value"]) as TextAsset;
                    GameData.instance.currentLanguage = JsonUtility.FromJson<JsonLanguage>(jsonLanguageFile.text);
                    PlayerPrefs.SetString("appLanguage", GameData.instance.selectedLanguage);
                    PlayerPrefs.Save();
                    onProfileLanguageChanged();
                }

                else if (jobj["type"].Equals("configuration"))
                {
                    webViewContainer.gameObject.SetActive(false);
                    permissionPanel.SetActive(true);
                }

            };


        };



    }

    public void openNewWebViewForBrand(CustomizationItem c)
    {
        webViewBrandContainer.gameObject.SetActive(true);

        if (brandView == null)
        {
            Web.ClearAllData();
            brandView = CanvasWebViewPrefab.Instantiate();
            brandView.transform.SetParent(webViewBrandContainer);
            var rectTransform = brandView.transform as RectTransform;
            rectTransform.anchoredPosition3D = Vector3.zero;
            rectTransform.offsetMin = Vector2.zero;
            rectTransform.offsetMax = Vector2.zero;
            brandView.Resolution = 1300;
            brandView.transform.localScale = Vector3.one;

            brandView.Native2DModeEnabled = true;

            Web.SetAutoplayEnabled(true);
            Web.SetUserAgent(true);

            brandView.Initialized += (sender, e) =>
            {
                (brandView.WebView as IWithNative2DMode).SetNativeZoomEnabled(false);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif

                brandView.WebView.LoadUrl(c._customPageLink + "&token=" + GameData.instance.loggedUser._token);

                brandView.WebView.LoadProgressChanged += (s, eventArgs) =>
                {
                    if (eventArgs.Type == ProgressChangeType.Finished)
                    {
                        brandLoadingContainer.SetActive(false);
                    }

                };

                brandView.WebView.MessageEmitted += (sender2, eventArgs2) =>
                {
                    Debug.Log("received from WebViewExternalLink: " + eventArgs2.Value);

                    var jobj = JSON.Parse(eventArgs2.Value);

                    if (jobj["type"].Equals("back"))
                    {

                        destroyBrandWebView();
                    }

                    else if (jobj["type"].Equals("connect"))
                    {
                        string contentId = jobj["id"];

                        if (!(GameData.instance.loggedUser._associatedContent.Contains(contentId) && GameData.instance.availableDownloadedContent.containsDlc(contentId)))
                        {
                            onHomePressed();
                            showDetailProjectSchema(contentId, () =>
                            {
                                onHomePressed();
                            });

                        }

                        StartCoroutine(askForDownload(contentId));

                    }

                };

            };
        }

        else
        {
            brandView.WebView.LoadUrl(c._customPageLink);

        }



    }


    public void openNewWebViewForExternalLInk(string uri)
    {
        webViewExternalLinkContainer.gameObject.SetActive(true);

        Web.ClearAllData();
        externalLinkView = CanvasWebViewPrefab.Instantiate();
        externalLinkView.transform.SetParent(webViewExternalLinkContainer);
        var rectTransform = externalLinkView.transform as RectTransform;
        rectTransform.anchoredPosition3D = Vector3.zero;
        rectTransform.offsetMin = Vector2.zero;
        rectTransform.offsetMax = Vector2.zero;
        externalLinkView.Resolution = 1300;
        externalLinkView.transform.localScale = Vector3.one;

        externalLinkView.Native2DModeEnabled = true;

        Web.SetAutoplayEnabled(true);
        Web.SetUserAgent(true);

        externalLinkView.Initialized += (sender, e) =>
        {
            (externalLinkView.WebView as IWithNative2DMode).SetNativeZoomEnabled(false);

#if UNITY_IOS && !UNITY_EDITOR
    (webview.WebView as iOSWebView).SetTargetFrameRate(10);
    (webview.WebView as iOSWebView).SetScrollViewBounces(false);
#endif

#if UNITY_ANDROID && !UNITY_EDITOR
    // Vuplex: il metodo AndroidWebView.SetMediaPlaybackRequiresUserGesture() è stato rimosso
    Vuplex.WebView.Web.SetAutoplayEnabled(true);
#endif


            externalLinkView.WebView.LoadUrl(uri);

            externalLinkView.WebView.LoadProgressChanged += (s, eventArgs) =>
            {
                if (eventArgs.Type == ProgressChangeType.Finished && profileView.WebView.Url.Equals(uri))
                {
                    externalLinkLoadingContainer.SetActive(false);
                }

            };

            externalLinkView.WebView.MessageEmitted += (sender2, eventArgs2) =>
            {
                Debug.Log("received from WebViewExternalLink: " + eventArgs2.Value);

                var jobj = JSON.Parse(eventArgs2.Value);

                if (jobj["type"].Equals("back"))
                {

                    destroyExternalLInkWebView();
                }

            };

        };

    }

    private void destroyExternalLInkWebView()
    {
        webViewExternalLinkContainer.gameObject.SetActive(false);
        if (externalLinkView != null)
        {
            externalLinkLoadingContainer.SetActive(true);
            Destroy(externalLinkView);
        }
    }

    private void destroyBrandWebView()
    {
        webViewBrandContainer.gameObject.SetActive(false);
        //if (brandView != null)
        //{
        //    brandLoadingContainer.SetActive(true);
        //    Destroy(brandView);
        //}
    }

    #endregion


  

}
