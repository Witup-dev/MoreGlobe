using easyar;
using System.Collections;
using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using DG.Tweening;

public class SpartialManager : MonoBehaviour
{


    [Header("Singleton")]
    public static SpartialManager instance { get; private set; }

    // public Spatial3DModelItem itemPrefab;
    // private Spatial3DModelItem activeItem;
    // public Transform horizontalScrollContent;


    [Header("AR core")]

    public ElementorModel elementorModel;
    public ARSession Session;
    public ARTouchController TouchControl;
    private SurfaceTrackerFrameFilter target;
    private CameraDeviceFrameSource cameraDevice;





   [Header("UI stato & footer")] 

    //Variables for ui handling
    public Canvas globalCanvas;
    public GameObject closeModelFooterButton;
    public GameObject functionsFooter;
    public RectTransform modelFooter;
    //variables for ui handling
    public bool isModelSelected;




    
    [Header("Tutorial & input")] 

    //Tutorial
    public Button modelMenuButton;
    public Button tutorialButton;
    public Button screenshotButton;
    private bool isTutorialSeen;
    public bool tutorialModelSelected;
    public bool tutorialMoveTheModel;
    public bool tutorialZoomTheModel;
    public bool tutorialRotateTheModel;
    public Sprite part1;
    public Sprite part2;
    public Sprite part3;




    #region Unity Lifecycle

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        if (PlayerPrefs.HasKey("spatialTutorial"))
        {
            isTutorialSeen = PlayerPrefs.GetInt("spatialTutorial") == 1 ? true : false;
        }

        else
        {
            isTutorialSeen = false;
            tutorialModelSelected =
                tutorialMoveTheModel =
                tutorialZoomTheModel =
                tutorialRotateTheModel = false;
        }

        isModelSelected = false;

        target = Session.GetComponentInChildren<SurfaceTrackerFrameFilter>();
        cameraDevice = Session.GetComponentInChildren<CameraDeviceFrameSource>();

        Session.StateChanged += (state) =>
        {
            if (state == ARSession.SessionState.Ready)
            {
                TouchControl.TurnOn(TouchControl.transform, Session.Assembly.Camera, false, false, true, true);
            }
        };


        // activeItem = null;

        // foreach (var model in GameData.instance.modelListForSpatial)
        // {
        //     Spatial3DModelItem item = Instantiate(itemPrefab, horizontalScrollContent, false);

        //     item.data = model;

        //     item.initialize();

        // }

        // StartCoroutine(buildExperience());

    }

    // Start is called before the first frame update
    void Start()
    {
        if (!isTutorialSeen)
        {
            Debug.Log("partiamo con il tutorial");
            // StartCoroutine(startTutorial());
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.touchCount == 1 && !EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
        {
            var touch = Input.touches[0];
            if (touch.phase == TouchPhase.Moved)
            {
                var viewPoint = new Vector2(touch.position.x / Screen.width, touch.position.y / Screen.height);
                var coord = Session.ImageCoordinatesFromScreenCoordinates(viewPoint);
                if (target && target.Target != null && coord.OnSome)
                {
                    target.Target.AlignTo(coord.Value);
                    Debug.Log("Muovo il modello");
                    if (tutorialModelSelected)
                        tutorialMoveTheModel = true;
                }
            }
        }
    }



    #endregion
    #region Navigation & UI
    

    public void goToMenu()
    {
        SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);
    }

        public void openModelFooter()
    {

        functionsFooter.gameObject.SetActive(false);
        modelFooter.DOAnchorPos(new Vector2(0, modelFooter.sizeDelta.y), 0.25f)
            .onComplete = () =>
            {
                if (isModelSelected)
                    closeModelFooterButton.SetActive(true);
            };



    }

    public void closeModelFooter()
    {
        closeModelFooterButton.SetActive(false);
        modelFooter.DOAnchorPos(new Vector2(-modelFooter.rect.width, modelFooter.sizeDelta.y), 0.30f)
            .onComplete = () => { functionsFooter.gameObject.SetActive(true); };

    }


    public void switchCamera()
    {

        if (!cameraDevice || cameraDevice.Opened)
        {
            return;
        }
        if (CameraDeviceFrameSource.CameraCount == 0)
        {
            cameraDevice.Close();
            return;
        }

        var index = cameraDevice.Index;
        index = (index + 1) % CameraDeviceFrameSource.CameraCount;
        cameraDevice.CameraOpenMethod = CameraDeviceFrameSource.CameraDeviceOpenMethod.DeviceIndex;
        cameraDevice.CameraOpenIndex = index;

        cameraDevice.Close();
        cameraDevice.Open();

        //Analytics.instance.cameraSwitch(index + 1, GameData.instance.sessionId + "");
    }

    public void takeScreenShot()
    {

        StartCoroutine(_takeScreenShot());


    }

   private IEnumerator _takeScreenShot()
{
    globalCanvas.enabled = false;

    yield return new WaitForEndOfFrame();

    Texture2D t = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
    t.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
    t.Apply();

    globalCanvas.enabled = true;

    string screenName = "MoreGlobe_Screenshot_-" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".jpg";

    // NIENTE assegnazione, solo la chiamata
    NativeGallery.SaveImageToGallery(t, "Moreglobe", screenName, (success, path) =>
    {
        Debug.Log("Screenshot saved in gallery in: " + path);

        var popup = UIController.instance.CreateTutorialPopup();
        popup.initialize(
            UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[0]._title,
            GameData.instance.currentLanguage._popupTutorialJson[0]._message,
            2.5f
        );
    });
}


    #endregion
    #region 3D model management

    public void handle3DModel(Spatial3DModelItem item)
    {
        //TouchControl.transform.parent.gameObject.SetActive(true);
        // if (activeItem != null)
        // {
        //     activeItem.enableInteraction();
        //     activeItem.modelPrevScale = activeItem.modelRef.transform.localScale;
        //     activeItem.modelRef.SetActive(false);
        // }

        // activeItem = item;

        // item.disableInteraction();

        if (!item.isDownloaded)
        {

            StartCoroutine(_handle3DModel(item));
        }

        else
        {
            item.modelRef.transform.localScale = item.modelPrevScale;
            item.modelRef.SetActive(true);
        }
    }

    private IEnumerator buildExperience()
    {
        Debug.Log("ciao");

        using (UnityWebRequest www = UnityWebRequest.Get("https://arstudio.moreglobe.com/api/experience?id_experience=1"))
        {

            yield return www.SendWebRequest();


            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log($"business error: {www.error}");
            }


            else
            {
                ElementorInfo response = ElementorInfo.CreateFromJSON(www.downloadHandler.text);


                if (response._success)
                {
                    Debug.Log($"ciao {TouchControl.transform}");
                    // elementorModel.EntityInstantiate(response.items, TouchControl);
                }

            }

        }


        yield return null;
    }

    public void Get3DModelElement(Transform controller, DataRequest response)
    {
        StartCoroutine(get3DModelElement(controller, response));
    }

    IEnumerator get3DModelElement(Transform controller, DataRequest response)
    {

        // if (OfflineGameManager.instance.connectionPopup != null)
        // {
        //     OfflineGameManager.instance.connectionPopup.destroy();
        // }

        string bundleURL = response.url + "-";
        Debug.Log("entro nel 3d");
#if UNITY_ANDROID
        bundleURL += "Android";
#else
        bundleURL += "IOS";
#endif


        using (UnityWebRequest www = UnityWebRequestAssetBundle.GetAssetBundle(bundleURL))
        {
            yield return www.SendWebRequest();

            // yield return DownloadManager.handleBundleDownloadProgressBar(controller, www, download, downPopup);

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);

            }

            else
            {
                Debug.Log("get3DModel: richiesta buon fine");

                AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(www);

                if (bundle != null)
                {
                    if (!PlayerPrefs.HasKey("framingTutorial"))
                    {
                        PlayerPrefs.SetInt("framingTutorial", 1);
                        PlayerPrefs.Save();
                    }

                    string rootAssetPath = bundle.GetAllAssetNames()[0];
                    GameObject parentModel = Instantiate(new GameObject(), Vector3.zero, Quaternion.identity, parent: controller.transform);
                    GameObject arObject = Instantiate(bundle.LoadAsset(rootAssetPath) as GameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, controller.transform);
                    arObject.AddComponent<ModelEntity>().Constructor(response);
                    // arObject.AddComponent<Lean.Touch.LeanPinchScale>();
                    bundle.Unload(false);
                    isModelSelected = true;
                }
                else
                {
                    Debug.Log("Bungle empty");
                }
            }

        }
    }
    private IEnumerator _handle3DModel(Spatial3DModelItem item)
    {
        string bundleURL = item.data._src + "-";

#if UNITY_ANDROID
        bundleURL += "Android";
#else
        bundleURL += "IOS";
#endif


        using (UnityWebRequest www = UnityWebRequestAssetBundle.GetAssetBundle(bundleURL))
        {

            DownloadPopup downPopup = UIController.instance.CreateDownloadPopup();
            downPopup.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._downloading);

            UnityWebRequestAsyncOperation download = www.SendWebRequest();


            yield return DownloadManager.handleBundleDownloadProgressBar(null, www, download, downPopup);

            if (www.result != UnityWebRequest.Result.Success || OfflineGameManager.instance.downloadAborted)
            {
                Debug.Log(www.error);

                if (downPopup != null)
                    downPopup.destroy();

            }

            else
            {

                AssetBundle bundle = DownloadHandlerAssetBundle.GetContent(www);

                if (bundle != null)
                {

                    Debug.Log("get3DModel: Ho un bundle");

                    item.isDownloaded = true;

                    string rootAssetPath = bundle.GetAllAssetNames()[0];

                    var type =

                    item.modelRef = Instantiate(bundle.LoadAsset(rootAssetPath) as GameObject, TouchControl.transform, false);

                    Analytics.instance.model3D(string.Empty, item.data._id, GameData.instance.sessionId + "");

                    item.modelRef.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
                    item.modelRef.transform.localRotation = Quaternion.Euler(90, 0, 0);

                    bundle.Unload(false);

                    closeModelFooter();
                    tutorialModelSelected = true;
                    isModelSelected = true;
                }
                else
                {

                    if (downPopup != null)
                        downPopup.destroy();

                }
            }

        }
    }



    #endregion
    #region  Tutorial


    public void showTutorial()
    {
        // StartCoroutine(startTutorial());
    }

    private IEnumerator startTutorial()
    {
        Debug.Log("Tutorial partito");

        var t0 = UIController.instance.CreateTutorialPopup();
        t0.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[2]._title,
            GameData.instance.currentLanguage._popupTutorialJson[2]._message,
            0);

        yield return new WaitUntil(() => t0 == null);

        var t1 = UIController.instance.CreateTutorialPopupImage();
        t1.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[3]._title,
            GameData.instance.currentLanguage._popupTutorialJson[3]._message,
            part1,
            0);

        yield return new WaitUntil(() => t1 == null);

        var t2 = UIController.instance.CreateTutorialPopupImage();
        t2.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[4]._title,
            GameData.instance.currentLanguage._popupTutorialJson[4]._message,
            part2,
            0);

        yield return new WaitUntil(() => t2 == null);

        var t3 = UIController.instance.CreateTutorialPopupImage();
        t3.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[5]._title,
            GameData.instance.currentLanguage._popupTutorialJson[5]._message,
            part3,
            0,
            () =>
            {
                PlayerPrefs.SetInt("spatialTutorial", 1);
                PlayerPrefs.Save();
            });


    }


    #endregion
    #region Download & Images

    
    public void DownloadImage(string link, UnityEngine.UI.Image spriteImage)
    {
        StartCoroutine(downloadMask(link, spriteImage));
    }
    private IEnumerator downloadMask(string link, UnityEngine.UI.Image spriteImage = null)
    {
        using (var www = UnityWebRequestTexture.GetTexture(link))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                if (www.isDone)
                {
                    Sprite tmpMask;
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    tmpMask = Sprite.Create(x, new Rect(0.0f, 0.0f, x.width, x.height), new Vector2(0.5f, 0.5f), 100.0f);
                    if (spriteImage != null)
                    {
                        spriteImage.sprite = tmpMask;
                    }
                }
            }
        }
    }

    #endregion
}
