using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeepLinkManager : MonoBehaviour
{
    public enum Actions { NoAction, Content };

    public static DeepLinkManager instance { get; private set; }

    public bool hasAction;

    public Actions actionType;

    public string actionValue;

    private void Awake()
    {
        hasAction = false;
        actionValue = string.Empty;


        if (instance == null)
        {
            instance = this;

            Application.deepLinkActivated += onDeepLinkActivated;

            if (!string.IsNullOrEmpty(Application.absoluteURL))
            {
                onDeepLinkActivated(Application.absoluteURL);
            }


        }
        else
        {
            Destroy(gameObject);
        }


    }

    private void onDeepLinkActivated(string url)
    {
        string[] param = url.Split('?')[1].Split('=');

        if (param[0].Equals("content"))
        {
            hasAction = true;
            actionType = Actions.Content;
            actionValue = param[1];
        }

        Debug.Log($"Deeplink: {url}");
        Debug.Log($"Deeplink: para {param}");
        Debug.Log($"Deeplink para 0: {param[0]}");
        Debug.Log($"Deeplink para 1: {param[1]}");

        //TODO: code for deeplink
    }

    public void reset()
    {
        hasAction = false;
        actionType = Actions.NoAction;
        actionValue = string.Empty;

    }

}
