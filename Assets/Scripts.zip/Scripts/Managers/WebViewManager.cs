﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class WebViewManager : MonoBehaviour
{

    private string webUrl;

    public Text urlText;

    // Start is called before the first frame update
    void Start()
    {
        webUrl = PlayerPrefs.GetString("site");
        urlText.text = webUrl;
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void goToAR()
    {
        SceneManager.LoadScene("ARscene", LoadSceneMode.Single);
    }
}
