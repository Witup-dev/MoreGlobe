﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Networking;
using UnityEngine.EventSystems;
using System.IO;
using DG.Tweening;
using System;
using easyar;
using TMPro;
using OneSignalSDK;


public class OfflineGameManager : MonoBehaviour
{
    

    [Header("Singleton")]
    

    public static OfflineGameManager instance { get; private set; }




    [Header("AR components")]
     
     
    public TargetCreationManager targetManagerInstance;
    public ARSession Session;
    public ImageTargetController imageTargetController;
    private SurfaceTrackerFrameFilter target;
    private ImageTrackerFrameFilter imageTracker;
    public ARTouchController TouchControl;
    public CameraDeviceFrameSource cameraDevice;
    private TargetHandler currentTarget;




[Header("Spatial / experience state")]

    public GameObject closeExperienceBtn;
    private RectTransform experienceGB;
    public bool isExperience;


    


[Header("Download and connection state ")]
   
    public bool downloadInProgress;
    public bool downloadAborted;
    public UnityWebRequestAsyncOperation inProgressRequest;
    public PopupInfo connectionPopup;
    private float timeLeftToOnline;
    private float timeoutForBadConnection;
    public bool startToCountdownForBadConnection;
    public bool connectionPopupActivator;





    [Header("Global UI and controls ")]

    public GameObject scrittaVideo;
    public GameObject closeFullScreenButton;
    public GameObject flashButton;
    public GameObject menuButton;
    public BlinkObject badConnection;
    public Button siteButton;
    public Button fullScreenButton;
    public Button spatialButton;
    public GameObject switchCameraButton;
    public UnityEngine.UI.Image iAmWatching;
    public GameObject panelOptions;
    public Canvas globalCanvas;





    [Header("Project / content panel")]

    public RectTransform projectPanel;
    public UnityEngine.UI.Image projectLogo;
    public UnityEngine.UI.Image projectAlbum;
    public UnityEngine.UI.Image FullScreenProjectAlbum;
    public TextMeshProUGUI contentName;
    public TextMeshProUGUI contentCategory;
    public TextMeshProUGUI contentLastVersion;
    public TextMeshProUGUI contentDescription;
    public TextMeshProUGUI detailsText;
    public TextMeshProUGUI websiteText;
    public TextMeshProUGUI buyText;
    public GameObject photoButton;






    [Header("Side video commands menu")]

    public SideMenuManager sideMenu;
    public Button playVideoButton;
    public Button pauseVideoButton;
    public Button gobackVideoButton;
    public Button goForwardVideoButton;






    [Header("Content and business data")]

    private Content currentContent;
    private Content tmpContent;
    private bool isExpired;




    [Header("Tutorial state")]

    //tutorial
    private bool isTutorialSeen;
    public Sprite tutorialSprite;






    [Header("State flags")]

    [HideInInspector]
    public bool isInFullscreen;
    public bool isFrameSomething;
    public bool isProjectPageOpen;
    public bool isGoBackPopup;
    private bool isFlashActive;





    [Header("Media resources")]
   
    public Sprite mp4SourceType;
    public Sprite youtubeSourceType;
    public Sprite loadingImage;
    public Sprite errorImage;

    
    #region Unity Lifecicle

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        GameData.instance.sessionId = new DateTimeOffset(DateTime.Now).ToUnixTimeSeconds();
        GameData.instance.modelListForSpatial = new List<MarkerModel>();

        if (PlayerPrefs.HasKey("framingTutorial"))
        {
            isTutorialSeen = PlayerPrefs.GetInt("framingTutorial") == 1 ? true : false;
        }

        currentTarget = null;
        tmpContent = null;
        isGoBackPopup = false;
        isProjectPageOpen = false;
        downloadInProgress = false;
        downloadAborted = false;
        inProgressRequest = null;
        isFlashActive = false;
        startToCountdownForBadConnection = false;
        connectionPopupActivator = true;
        connectionPopup = null;

        imageTracker = Session.GetComponentInChildren<ImageTrackerFrameFilter>();
        target = Session.GetComponentInChildren<SurfaceTrackerFrameFilter>();
        Session.StateChanged += (state) =>
        {
            if (state == ARSession.SessionState.Ready)
            {
                TouchControl.TurnOn(TouchControl.transform, Session.Assembly.Camera, false, false, true, true);
            }
        };
    }

    // Start is called before the first frame update
    void Start()
    {
        Screen.orientation = ScreenOrientation.Portrait;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        resetTimer();
        resetBadConnectionTimer();

        currentContent = JsonUtility.FromJson<Content>(PlayerPrefs.GetString("lastContentViewed"));

        if (currentContent._isBrand)
        {
            CustomizationItem item = new CustomizationItem
            {
                _id = currentContent._id,
                _customPageLink = currentContent._custom_page,
                _footerImageLink = currentContent._tabbar_logo,
                _splashImageLink = currentContent._splash_logo
            };

            GameData.instance.selectedCustomContent = item;
            PlayerPrefs.SetString("customContent", JsonUtility.ToJson(item));
            PlayerPrefs.Save();
        }
        else
        {
            PlayerPrefs.DeleteKey("customContent");
            PlayerPrefs.Save();
        }

        contentName.text = "Loading...";
        contentCategory.text = "Loading...";
        contentLastVersion.text = "Loading...";
        contentDescription.text = "Loading...";

        StartCoroutine(initialize());

        if (!GameData.instance.appConfig._cameraPermission)
        {
            PopupInfo popup = UIController.instance.CreateInfoPopup();
            popup.initialize(UIController.instance.mainCanvas,
                GameData.instance.currentLanguage._popupInfoJson[20]._title,
                GameData.instance.currentLanguage._popupInfoJson[20]._message,
                GameData.instance.currentLanguage._popupInfoJson[20]._buttonText,
                "error",
                () =>
                {

                    goToMenu();

                });
        }

        else if (!isTutorialSeen)
        {
            StartCoroutine(startTutorial());
        }
        else
        {
            setupArScene();
        }
        OneSignal.User.AddTag("user_lang", GameData.instance.selectedLanguage);
    }

     // Update is called once per frame
    void Update()
    {
        if (Input.touchCount == 1 && !EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
        {
            var touch = Input.touches[0];
            if (touch.phase == TouchPhase.Moved)
            {
                var viewPoint = new Vector2(touch.position.x / Screen.width, touch.position.y / Screen.height);
                var coord = Session.ImageCoordinatesFromScreenCoordinates(viewPoint);
                if (target && target.Target != null && coord.OnSome)
                {
                    target.Target.AlignTo(coord.Value);
                    Debug.Log("Muovo il modello");
                    // if (tutorialModelSelected)
                    //     tutorialMoveTheModel = true;
                }
            }
        }
        if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft)
        {
            iAmWatching.rectTransform.localRotation = Quaternion.Euler(new Vector3(0, 0, -90));
            iAmWatching.rectTransform.sizeDelta = new Vector2(300, 200);
        }

        else if (Input.deviceOrientation == DeviceOrientation.LandscapeRight)
        {
            iAmWatching.rectTransform.localRotation = Quaternion.Euler(new Vector3(0, 0, 90));
            iAmWatching.rectTransform.sizeDelta = new Vector2(300, 200);
        }

        else if (Input.deviceOrientation == DeviceOrientation.Portrait)
        {
            iAmWatching.rectTransform.localRotation = Quaternion.Euler(new Vector3(0, 0, 0));
            iAmWatching.rectTransform.sizeDelta = new Vector2(350, 200);
        }

        if (!isFrameSomething && !isInFullscreen && !isProjectPageOpen)
        {
            if (timeLeftToOnline > 0) timeLeftToOnline -= Time.deltaTime;
            else
            {
                if (!isGoBackPopup)
                {
                    isGoBackPopup = true;
                    PopupChoiceMessage choice = UIController.instance.CreateChoicePopup();
                    choice.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupChoiceJson[2]._title,
                        GameData.instance.currentLanguage._popupChoiceJson[2]._message,
                        GameData.instance.currentLanguage._popupChoiceJson[2]._positive,
                        GameData.instance.currentLanguage._popupChoiceJson[2]._negative,
                        () =>
                        {//go

                            SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
                        },
                        () =>
                        {// stay
                            GameObject.Destroy(choice.gameObject);
                            resetTimer();
                            isGoBackPopup = false;

                        });
                }

            }
        }

        if (startToCountdownForBadConnection)
        {
            timeoutForBadConnection -= Time.deltaTime;

            if (timeoutForBadConnection <= 0) //if timeout expired
            {

                if (!badConnection.gameObject.activeInHierarchy)
                {
                    badConnection.startBlink();
                }

                if (connectionPopup == null && connectionPopupActivator)
                {
                    connectionPopup = UIController.instance.CreateInfoPopup();
                    connectionPopup.initialize(UIController.instance.mainCanvas,
                        GameData.instance.currentLanguage._popupInfoJson[17]._title,
                        GameData.instance.currentLanguage._popupInfoJson[17]._message,
                        GameData.instance.currentLanguage._popupInfoJson[17]._buttonText,
                        "warning",
                        () =>
                        {
                            Destroy(connectionPopup.gameObject);
                            if (currentTarget != null)
                            {
                                Debug.Log("Target ok, cancello");


                                StartCoroutine(targetManagerInstance.createTarget(currentTarget.controller));
                            }
                            else
                            {
                                Debug.Log("Target Non presente");
                            }
                            resetBadConnectionTimer();
                            connectionPopupActivator = false;

                        });
                }



            }
        }

        else
        {
            if (badConnection.gameObject.activeInHierarchy)
            {
                badConnection.stopBlink();
                if (connectionPopup != null)
                    Destroy(connectionPopup.gameObject);
                resetBadConnectionTimer();
                connectionPopupActivator = false;
            }

        }


        if (isInFullscreen)
        {
            closeFullScreenButton.SetActive(true);
            flashButton.SetActive(false);
            menuButton.SetActive(false);
            badConnection.gameObject.SetActive(false);
            panelOptions.gameObject.SetActive(false);
            switchCameraButton.SetActive(false);
        }
        else
        {
            closeFullScreenButton.SetActive(false);
            flashButton.SetActive(true);
            menuButton.SetActive(true);
            panelOptions.gameObject.SetActive(true);
            switchCameraButton.SetActive(true);

            if (GameData.instance.modelListForSpatial.Count > 0)
                spatialButton.gameObject.SetActive(true);

        }
    }

        private void OnApplicationPause(bool pause)
    {

        if (pause)
        {
            cameraDevice.enabled = false;

        }

        else
        {
            cameraDevice.enabled = true;
        }


    }


    private void OnApplicationFocus(bool focus)
    {
        if (focus)
        {
            cameraDevice.enabled = true;
            imageTracker.enabled = true;

            if (target != null)
                target.enabled = false;
        }
    }

    #endregion
    #region AR setup & tutorial


    private void setupArScene()
    {
        Debug.Log($"[NFC] entro {PlayerPrefs.GetString("NFC_ID")}");
        if (PlayerPrefs.HasKey("NFC_ID") && !string.IsNullOrEmpty(PlayerPrefs.GetString("NFC_ID")))
        {
            if (target != null)
                target.enabled = true;
            imageTracker.enabled = false;
        }
        else
        {
            Debug.Log($"[NFC] eh niente");
            if (target != null)
                target.enabled = false;
            imageTracker.enabled = true;
        }
    }
    private IEnumerator startTutorial()
    {
        yield return new WaitForSeconds(1f);
        var tutorial = UIController.instance.CreateTutorialPopupImage();
        tutorial.initialize(UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[1]._title,
            GameData.instance.currentLanguage._popupTutorialJson[1]._message,
            tutorialSprite,
            0,
            () =>
            {
                setupArScene();
            });

    }

    private IEnumerator startManualTutorial()
    {
        yield return new WaitForSeconds(1f);
        var tutorial = UIController.instance.CreateTutorialPopupImage();
        tutorial.initialize(UIController.instance.mainCanvas,
            "Welcome in Moreglobe's experience",
            "Enjoy seeing the experiences in your spaces! \n Press close experience button to restart a new experience.",
            tutorialSprite,
            0);

    }

        private void setArMode(bool marker, bool spatial)
    {
        // Debug.Log($"tracker {tracker}");
        Debug.Log($"imageTracker {imageTracker}");
        target.enabled = spatial;
        imageTracker.enabled = marker;
    }




    #endregion
    #region Content loading & DLC management



    private IEnumerator initialize()
    {


        StartCoroutine(Utilities.getImageAndApply(currentContent._thumbnailLibraryLink, iAmWatching, loadingImage, errorImage));//yield return


        yield return getContentFromId(currentContent._id);

        if (!isExpired)
        {
            yield return getContent3DModel(currentContent._id, false);

            var associatedDLC = GameData.instance.availableDownloadedContent.getDLC(tmpContent._id);

            if (tmpContent != null && ((DateTime.Parse(associatedDLC._downloadDate) < DateTime.Parse(tmpContent._updated_at)) || string.IsNullOrEmpty(associatedDLC._downloadDate)))
            {
                if (target != null)
                    target.enabled = false;
                imageTracker.enabled = false;
                PopupInfo popup = UIController.instance.CreateInfoPopup();
                popup.initialize(UIController.instance.mainCanvas,
                    GameData.instance.currentLanguage._popupInfoJson[4]._title,
                    GameData.instance.currentLanguage._popupInfoJson[4]._message,
                    GameData.instance.currentLanguage._popupInfoJson[4]._buttonText,
                    default,
                    () =>
                    {
                        GameObject.Destroy(popup.gameObject);
                        StartCoroutine(updateDLC(associatedDLC._downloadDate));
                    });
            }

            else
            {

                yield return Utilities.checkForMaintenance(false);

                if (GameData.instance.isInMaintenance)
                {
                    MaintenancePopup popup = UIController.instance.CreateMaintenancePopup();
                    popup.initialize(UIController.instance.mainCanvas);
                }


                StartCoroutine(Utilities.getImageAndApply(tmpContent._thumbnailLink, projectLogo, loadingImage, errorImage));////yield return

                StartCoroutine(Utilities.getImageAndApply(tmpContent._thumbnailDescription, projectAlbum, loadingImage, errorImage));////yield return

                StartCoroutine(Utilities.getImageAndApply(tmpContent._thumbnailDescription, FullScreenProjectAlbum, loadingImage, errorImage));////yield return


                contentName.text = tmpContent._contentName;
                contentCategory.text = tmpContent._category;
                contentLastVersion.text = GameData.instance.currentLanguage._latestVersion + " " + tmpContent._version;
                contentDescription.text = tmpContent._longDescription;
                websiteText.text = GameData.instance.currentLanguage._websiteButtontext;
                buyText.text = GameData.instance.currentLanguage._buyButtonText;
                detailsText.text = GameData.instance.currentLanguage._detail.ToUpper();

            }
        }

    }


    private IEnumerator getContent3DModel(string id, bool haveToWait)
    {

        if (haveToWait)
        {
            yield return new WaitForSeconds(3f);
        }


        string requestData = APIs.TAKE_3D_MODEL_LIST + GameData.instance.loggedUser._token + APIs.LIST_FOR_SPATIAL_TO_ADD + id;

        using (UnityWebRequest www = UnityWebRequest.Get(requestData))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }


            else
            {
                MarkerModelResponse response = JsonUtility.FromJson<MarkerModelResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    if (response._data.Count > 0)
                    {
                        Debug.Log("entrato nel counter " + response._data.Count);
                        spatialButton.gameObject.SetActive(true);
                        GameData.instance.modelListForSpatial = response._data;
                    }
                    else
                    {
                        spatialButton.gameObject.SetActive(false);
                        GameData.instance.modelListForSpatial = new List<MarkerModel>();
                    }


                }

            }

        }
    }

    private IEnumerator updateDLC(string date)
    {
        WaitingPopup waiting;
        //yield return DownloadManager.deleteDLCFromFileSystem(tmpContent._id);//TODO: questo non serve più


        DownloadPopup downPopup = UIController.instance.CreateDownloadPopup();
        downPopup.initialize(UIController.instance.mainCanvas);

        yield return DownloadManager.updateDLC(tmpContent, downPopup, date);

        if (Directory.Exists(Path.Combine(SaveLoadManager.DLCPATH, tmpContent._id)))
        {

            if (GameData.instance.availableDownloadedContent.containsDlc(tmpContent._id)) //Indica quali contenuti sono stati già scaricati e ne tiene traccia della versione
            {
                GameData.instance.availableDownloadedContent.updateDlc(tmpContent._id, tmpContent._version, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                PlayerPrefs.SetString("availableContents", JsonUtility.ToJson(GameData.instance.availableDownloadedContent));
                PlayerPrefs.SetString("lastContentViewed", JsonUtility.ToJson(tmpContent));
                PlayerPrefs.Save();


                waiting = UIController.instance.CreateWaitingPopup();
                waiting.initialize(UIController.instance.mainCanvas, GameData.instance.currentLanguage._refreshingAR);

                SceneManager.LoadScene("LocalMarkerScene", LoadSceneMode.Single);

            }
        }

        yield return null;
    }

    private IEnumerator getContentFromId(string id)
    {
        string requestData = GameData.instance.loggedUser._token + "/" + id + "/0";

        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CONTENT_UPDATE + "/" + id + "?lang=" + GameData.instance.selectedLanguage))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }


            else
            {
                ProjectContentResponse response = JsonUtility.FromJson<ProjectContentResponse>(www.downloadHandler.text);

                if (response._success)
                {

                    tmpContent = response._content;
                    if (!tmpContent._connect)
                    {
                        isExpired = true;
                        string title;
                        string message;
                        string buttonText;

                        if (tmpContent._expired)
                        {
                            title = GameData.instance.currentLanguage._popupInfoJson[19]._title;
                            message = GameData.instance.currentLanguage._popupInfoJson[19]._message;
                            buttonText = GameData.instance.currentLanguage._popupInfoJson[19]._buttonText;
                        }

                        else
                        {
                            title = GameData.instance.currentLanguage._popupInfoJson[18]._title;
                            message = GameData.instance.currentLanguage._popupInfoJson[18]._message;
                            buttonText = GameData.instance.currentLanguage._popupInfoJson[18]._buttonText;
                        }

                        PopupInfo popup = UIController.instance.CreateInfoPopup();
                        popup.initialize(UIController.instance.mainCanvas,
                            title,
                            message,
                            buttonText,
                            "error", () =>
                            {
                                SceneManager.LoadSceneAsync("MenuScene", LoadSceneMode.Single);
                            });
                        StartCoroutine(LoadSceneCoroutine());
                    }

                }

            }

        }
    }

    #endregion
    #region Navigation & timers

    IEnumerator LoadSceneCoroutine()
    {
        yield return new WaitForSeconds(3f);
        SceneManager.LoadSceneAsync("MenuScene", LoadSceneMode.Single);
    }

        public void goToMenu()
    {
        if (currentTarget != null && !GameData.instance.webviewForVideo)
        {
            currentTarget.resetVideo();
        }

        GameData.instance.fullScreenTimeToResume = 0;
        GameData.instance.fullScreenVideoMarker = null;

        SceneManager.LoadScene("MenuScene", LoadSceneMode.Single);
    }


    public void goToSpace3D()
    {
        SceneManager.LoadScene("SpaceVisualization", LoadSceneMode.Single);

    }

        public void resetTimer()
    {
        timeLeftToOnline = 120f;
    }
    public void resetBadConnectionTimer()
    {
        timeoutForBadConnection = 17f;
    }





    #endregion
    #region Project panel & external links

   
    public void openProjectPanel()
    {
        projectPanel.gameObject.SetActive(true);
        projectPanel.DOScaleY(1, 0.2f);
        isProjectPageOpen = true;
    }

    public void closeProjectPanel()
    {
        projectPanel.DOScaleY(0, 0.2f).onComplete = () => { projectPanel.gameObject.SetActive(false); isProjectPageOpen = false; };
    }

    public void openBuyProduct()
    {
        Application.OpenURL(tmpContent._websiteShop);
    }

    public void openWebsite()
    {
        Application.OpenURL(tmpContent._website);
    }

    #endregion
    #region Target & video control


    public void exitFullscreen()
    {
        currentTarget.exitFullscreen();
    }

    public void setCurrentTarget(TargetHandler newTarget)
    {
        if (currentTarget == null)
        {
            currentTarget = newTarget;
            return;
        }

        if (!newTarget.getMarker().name.Equals(currentTarget.getMarker().name))
        {
            if (isInFullscreen)
            {
                isInFullscreen = false;
                currentTarget.exitFullscreen();
            }


            currentTarget.isVideoBegin = false;

            if (!GameData.instance.webviewForVideo)
                currentTarget.resetVideo();

            currentTarget = newTarget;

            Analytics.instance.recognize(newTarget.getMarker().name, GameData.instance.sessionId + "");

        }
    }

        public TargetHandler getCurrentTarget()
    {
        return currentTarget;
    }

    
    public void buttonDoPlayPause(bool isPlaying)
    {
        if (isPlaying)
        {
            pauseVideoButton.gameObject.SetActive(true);
            playVideoButton.gameObject.SetActive(false);
        }

        else
        {
            pauseVideoButton.gameObject.SetActive(false);
            playVideoButton.gameObject.SetActive(true);
        }
    }

    #endregion
    #region 3D model management

    public void fetch3DModel()
    {
        if (!spatialButton.gameObject.activeInHierarchy)
            StartCoroutine(getContent3DModel(currentContent._id, true));
    }


    #endregion
    #region Camera, flash & screenshot



    public void makeFlash()
    {
        isFlashActive = !isFlashActive;
        cameraDevice.SetFlashTorch(isFlashActive);
    }



    public void switchCamera()
    {
        if (!cameraDevice || cameraDevice.Opened)
        {
            return;
        }
        if (CameraDeviceFrameSource.CameraCount == 0)
        {
            cameraDevice.Close();
            return;
        }

        var index = cameraDevice.Index;
        index = (index + 1) % CameraDeviceFrameSource.CameraCount;
        cameraDevice.CameraOpenMethod = CameraDeviceFrameSource.CameraDeviceOpenMethod.DeviceIndex;
        cameraDevice.CameraOpenIndex = index;

        cameraDevice.Close();
        cameraDevice.Open();

        // if (index == 0)
        // {
        //     if (currentTarget != null)
        //         currentTarget.controller.HorizontalFlip = false;
        // }
        // else
        // {
        //     if (currentTarget != null)
        //         currentTarget.controller.HorizontalFlip = true;
        // }

        Analytics.instance.cameraSwitch(index + 1, GameData.instance.sessionId + "");
    }

    private IEnumerator takeShot()
{
    globalCanvas.enabled = false;

    if (currentTarget != null)
        currentTarget.disableUI();

    yield return new WaitForEndOfFrame();

    var preview = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
    preview.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
    preview.Apply();

    globalCanvas.enabled = true;

    if (currentTarget != null)
        currentTarget.enableUI();

    string screenName = "MoreGlobe_Screenshot_-" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + ".jpg";

    // niente variabile "permission"
    NativeGallery.SaveImageToGallery(preview, "Moreglobe", screenName, (success, path) =>
    {
        Debug.Log("Screenshot saved in gallery ");

        var popup = UIController.instance.CreateTutorialPopup();
        popup.initialize(
            UIController.instance.mainCanvas,
            GameData.instance.currentLanguage._popupTutorialJson[0]._title,
            GameData.instance.currentLanguage._popupTutorialJson[0]._message,
            2.5f
        );
    });

    yield return null;
}



    public void takeScreenshot()
    {

        StartCoroutine(takeShot());
    }

    #endregion
    #region Marker / spatial experience

       public void MarkerToSpatial(bool canSwitch, bool isNfc = false, Transform canvas = null)
    {
        if (canSwitch)
        {
            if (imageTargetController != null && imageTargetController.transform.childCount > 0)
            {
                if (!isTutorialSeen)
                    StartCoroutine(startManualTutorial());

                setArMode(false, true);
                RectTransform oldPos = experienceGB = imageTargetController.transform.GetChild(0).GetComponent<RectTransform>();
                experienceGB.SetParent(TouchControl.transform, true);
                // Vector3 rot = new Vector3(transform.eulerAngles.x - 90f, transform.eulerAngles.y, transform.eulerAngles.z);
                experienceGB.transform.localRotation = Quaternion.Euler(transform.localRotation.x + 90f, transform.localRotation.y, transform.localRotation.z);
                experienceGB.position = new Vector3(experienceGB.position.x, experienceGB.position.y, 15f);
                experienceGB.localScale = new Vector3(0.002f, 0.002f, 0.002f);
                // experienceGB.localScale = new Vector3();
                // targetManagerInstance.elementorModel.SetCanvasPosition(TouchControl.transform);
                closeExperienceBtn.SetActive(true);
            }
            else
            {
                if (canvas != null)
                {
                    canvas.SetParent(TouchControl.transform, true);
                    // Vector3 rot = new Vector3(transform.eulerAngles.x - 90f, transform.eulerAngles.y, transform.eulerAngles.z);
                    canvas.transform.localRotation = Quaternion.Euler(transform.localRotation.x + 90f, transform.localRotation.y, transform.localRotation.z);
                    canvas.position = new Vector3(canvas.position.x, canvas.position.y, 15f);
                    canvas.localScale = new Vector3(0.002f, 0.002f, 0.002f);
                    // experienceGB.localScale = new Vector3();
                    // targetManagerInstance.elementorModel.SetCanvasPosition(TouchControl.transform);
                    closeExperienceBtn.SetActive(true);
                }
            }
        }
        else
        {
            isExperience = false;
        }
    }

    public void SpatialToMarker()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("LocalMarkerScene");
        // experienceGB.SetParent(imageTargetController.transform);
        // setArMode(true, false);
        // closeExperienceBtn.SetActive(false);
    }
        
    #endregion
    #region Web / site navigation

    public void goToWebView()
    {
        Analytics.instance.site(currentTarget.getMarker().name, currentTarget.getMarker().site, GameData.instance.sessionId + "");
        Application.OpenURL(currentTarget.getMarker().site);
    }

    #endregion


}
