using UnityEngine;
#if UNITY_IOS
using Unity.Notifications.iOS;
#elif UNITY_ANDROID
using UnityEngine.Android;
#endif

[System.Serializable]
public class AppConfiguration
{
    [SerializeField]
    private bool cameraPermission;
    [SerializeField]
    private bool gpsPermission;
    [SerializeField]
    private bool notificationPermission;

    public AppConfiguration()
    {
//#if UNITY_ANDROID

//            if (!Permission.HasUserAuthorizedPermission(Permission.Camera))
//            {
//                cameraPermission = false;
//            }

//            else
//            {
//                cameraPermission = true;
//            }

//#elif UNITY_IOS

//        if (Application.HasUserAuthorization(UserAuthorization.WebCam))
//        {
//            cameraPermission = true;
//        }
//        else
//        {
//            cameraPermission = false;
//        }
//#endif
        
        cameraPermission = false;
        gpsPermission = false;
        notificationPermission = true;

    }

    public AppConfiguration(bool camera, bool gps,bool notification)
    {
        cameraPermission = camera;
        gpsPermission = gps;
        notificationPermission = notification;
    }


    public bool _cameraPermission
    {
        get { return cameraPermission; }
        set { cameraPermission = value; }
    }
    
    
    public bool _gpsPermission
    {
        get { return gpsPermission; }
        set { gpsPermission = value; }
    }
    
    public bool _notificationPermission
    {
        get { return notificationPermission; }
        set { notificationPermission = value; }
    }


}
