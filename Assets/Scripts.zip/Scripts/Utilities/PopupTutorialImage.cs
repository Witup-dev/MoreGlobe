﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using System.Collections;

public class PopupTutorialImage : MonoBehaviour
{

    [SerializeField]
    private TextMeshProUGUI title;
    [SerializeField]
    private TextMeshProUGUI body;
    [SerializeField]
    private Image image;

    [SerializeField]
    private Button clickToDestroy;

    private Action action;

    public void initialize(Transform canvas, string title, string bodyTxt, Sprite image, float timeout, Action action = null)
    {

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;


        this.action = action;
        this.title.text = title;
        body.text = bodyTxt;
        this.image.sprite = image;
        clickToDestroy.onClick.AddListener(clickToDestroyBehaviour);

        if (timeout > 0.0f)
            StartCoroutine(timeoutToDestroy(timeout));

    }

    public void clickToDestroyBehaviour()
    {
        action?.Invoke();

        Destroy(gameObject);
    }

    private IEnumerator timeoutToDestroy(float timeout)
    {
        yield return new WaitForSeconds(timeout);

        if(gameObject != null)
        {
            action?.Invoke();
            Destroy(gameObject);
        }
        
    }
}
