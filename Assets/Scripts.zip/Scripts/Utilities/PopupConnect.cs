﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PopupConnect : MonoBehaviour
{

    [SerializeField]
    private Image logoImage;
    [SerializeField]
    private Button connectButton;
    [SerializeField]
    private TextMeshProUGUI body;
    public Sprite loadingImage;
    public Sprite errorImage;
    public Button destroyPopupAreaButton;


    

    public void initialize(Transform canvas, Content c, Action action, bool canDestroy)
    {

        StartCoroutine(Utilities.getImageAndApply(c._thumbnailLink, logoImage, loadingImage, errorImage));

        if (canDestroy)
        {
            destroyPopupAreaButton.onClick.AddListener(() => {

                Destroy(gameObject);

            });
        }        

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;


        body.text = GameData.instance.currentLanguage._projectDownload.Replace("{}", c._contentName);


        connectButton.onClick.AddListener(() => {

            action();

        });

    }

    public void destroy()
    {
        Destroy(gameObject);
    }
}
