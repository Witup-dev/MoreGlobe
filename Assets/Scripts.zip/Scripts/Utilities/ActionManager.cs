using UnityEngine;

public class ActionManager : MonoBehaviour
{
    public static ActionManager instance;

    void Awake()
    {
        instance ??= this;
    }

    public void OpenExternalLink(string url)
    {
        Debug.Log("entro nel sito");
        Application.OpenURL(url);
    }
}