﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GridScale : MonoBehaviour
{
    public bool isGrid;
    public DimConfiguration conf;
    private GridLayoutGroup layout;

    private void Awake()
    {
        
    }

    void Start()
    {

        if (isGrid)
            conf = ScreenResolutionManager.instance.gridConf;
        else
            conf = ScreenResolutionManager.instance.listConf;

        layout = GetComponent<GridLayoutGroup>();

        layout.cellSize = conf.cellSize;
        layout.spacing = conf.spacing;

        layout.padding = conf.padding;
    }

    void Update()
    {

    }

    
}

