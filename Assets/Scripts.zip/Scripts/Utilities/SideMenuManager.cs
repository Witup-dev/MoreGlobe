﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class SideMenuManager : MonoBehaviour
{

    public RectTransform sideMenuToMove;
    public RectTransform openCloseButtonRect;
    public Button openCloseButton;

    private bool isSideMenuOpen;

    private bool firstTime;


    private void Awake()
    {
        firstTime = true;
        isSideMenuOpen = false;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void firstOpen()
    {
        if (firstTime)
        {
            firstTime = false;
            StartCoroutine(_firstOpen());
        }
        
    }

    private IEnumerator _firstOpen()
    {
        openCloseButton.interactable = false;
        openSideMenu();
        yield return new WaitForSeconds(4f);
        closeSideMenu();
        openCloseButton.interactable = true;
    }

    public void openSideMenu()
    {
        openCloseButtonRect.transform.localScale = new Vector3(-openCloseButtonRect.transform.localScale.x, openCloseButtonRect.transform.localScale.y, openCloseButtonRect.transform.localScale.z);
        isSideMenuOpen = true;
        sideMenuToMove.DOAnchorPos(new Vector2(0, 0), 0.25f);
    }

    public void closeSideMenu()
    {
        openCloseButtonRect.transform.localScale = new Vector3(-openCloseButtonRect.transform.localScale.x, openCloseButtonRect.transform.localScale.y, openCloseButtonRect.transform.localScale.z);
        isSideMenuOpen = false;
        sideMenuToMove.DOAnchorPos(new Vector2(sideMenuToMove.sizeDelta.x, 0), 0.25f);
    }

    public void show()
    {
        sideMenuToMove.GetComponent<CanvasGroup>().alpha = 1;
    }

    public void hide()
    {
        sideMenuToMove.GetComponent<CanvasGroup>().alpha = 0;
    }


    public void openCloseButtonBehavoiur()
    {
        if (isSideMenuOpen)
            closeSideMenu();
        else
            openSideMenu();
    }


}
