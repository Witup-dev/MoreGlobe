﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;

public class PopupChoiceMessage : MonoBehaviour
{
    [SerializeField]
    private Button positiveButton;
    [SerializeField]
    private Button negativeButton;

    [SerializeField]
    private TextMeshProUGUI title;
    [SerializeField]
    private TextMeshProUGUI body;
    [SerializeField]
    private TextMeshProUGUI positiveText;
    [SerializeField]
    private TextMeshProUGUI negativeText;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void initialize(Transform canvas, string title, string bodyTxt, string positiveText, string negativeText, Action positiveAction, Action negativeAction=null)
    {

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;

        if (string.IsNullOrEmpty(title))
        {
            this.title.gameObject.SetActive(false);
        }

        else
        {

            this.title.text = title;
        }

        body.text = bodyTxt;

        this.positiveText.text = positiveText;
        this.negativeText.text = negativeText;

        positiveButton.onClick.AddListener(() => {

            positiveAction();

        });

        negativeButton.onClick.AddListener(() => {

            if (negativeAction != null)
                negativeAction();
            else
                GameObject.Destroy(this.gameObject);

        });
        
    }
}
