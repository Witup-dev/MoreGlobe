﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using DG.Tweening;
using UnityEngine.Networking;
using TMPro;

public class NotificationBehaviour : MonoBehaviour
{


    [Header("Panels UI")]

    public RectTransform actionsPanel;
    public RectTransform noticeBodyPanel;




    [Header("Buttons")]
    
    public Button noticeBtn;
    public Button delete;
    public Button markAsRead;
    public Button options;
    public CanvasGroup panelToAlpha;




 [Header("Parametri animazioni / testi")]

    public float percentTreshold = 0.25f;
    public TextMeshProUGUI markAsReadText;
    public TextMeshProUGUI deleteText;
    



    #region Unity lifecycle

    void Awake()
    {
        options.onClick.AddListener(openOption);
        
    }

    void Start()
    {
        markAsRead.onClick.AddListener(markNoticeAsRead);
        delete.onClick.AddListener(deleteNotice);
        markAsReadText.text = GameData.instance.currentLanguage._detail;
        deleteText.text = GameData.instance.currentLanguage._delete;
    }

    #endregion
   
    #region Apertura / chiusura pannello opzioni

    public void openOption()
    {
        //notice.DOAnchorPos(new Vector2(-350, notice.offsetMax.y), 0.25f);
        //actions.DOSizeDelta(new Vector2(350, actions.sizeDelta.y), 0.25f);
        //noticeBtn.onClick.AddListener(closeOption);

        activeText();

        actionsPanel.DOSizeDelta(new Vector2(noticeBodyPanel.rect.width, actionsPanel.sizeDelta.y), percentTreshold);

        options.onClick.AddListener(closeOption);
    }

    public void closeOption()
    {
        //notice.DOAnchorPos(new Vector2(0, notice.offsetMax.y), 0.25f);
        //actions.DOSizeDelta(new Vector2(0, actions.sizeDelta.y), 0.25f);
        //noticeBtn.onClick.AddListener(openOption);

        actionsPanel.DOSizeDelta(new Vector2(0, actionsPanel.sizeDelta.y), percentTreshold);

        deactiveText();

        options.onClick.AddListener(openOption);
    }

    private void activeText()
    {
        markAsReadText.gameObject.SetActive(true);
        deleteText.gameObject.SetActive(true);
    }

    private void deactiveText()
    {
        markAsReadText.gameObject.SetActive(false);
        deleteText.gameObject.SetActive(false);
    }


#endregion
   
    #region Azioni notifica

    public void readNotice()
    {
        StartCoroutine(_readNotice(false));
    }

    public void markNoticeAsRead()
    {
        StartCoroutine(_readNotice(true));
    }
    
    public void deleteNotice()
    {
        StartCoroutine(_deleteNotice());
        
    }

    private IEnumerator _readNotice(bool justMark)
    {
        var n = gameObject.GetComponent<NoticeItem>();

        WWWForm form = new WWWForm();

        form.AddField("action", "read-notification");

        form.AddField("id", n.id);

        string uri = APIs.CHECK_FOR_NOTIFICATION + GameData.instance.loggedUser._token;
        
        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log("Error: " + www.error);
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (response._success)
                {
                    if (justMark)
                    {
                        closeOption();
                        markAsRead.interactable = false;
                        panelToAlpha.alpha = 0.70f;
                    }
                    

                    Debug.Log("NoticeCall: Read - Success");
                }
            }

        }
    }

    private IEnumerator _deleteNotice()
    {
        var n = gameObject.GetComponent<NoticeItem>();
        
        WWWForm form = new WWWForm();

        form.AddField("action", "delete-notification");

        form.AddField("id", n.id);

        string uri = APIs.CHECK_FOR_NOTIFICATION + GameData.instance.loggedUser._token;
        
        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log("Error: " + www.error);
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (response._success)
                {
                    RectTransform rect = noticeBtn.gameObject.GetComponent<RectTransform>();
                    var item = this.gameObject.GetComponent<NoticeItem>();


                    rect.DOAnchorPos(new Vector2(-rect.rect.width, rect.rect.position.y + rect.offsetMax.y), 0.25f).onComplete = (() =>
                    {
                        MenuManager.noticesIds.Remove(item.id);

                        if (MenuManager.noticesIds.Count == 0)
                        {
                            MenuManager.instance.noNotice.gameObject.SetActive(true);
                        }

                        Destroy(this.gameObject);

                    });


                    Debug.Log("NoticeCall: Delete - Success");
                }
            }

        }
    }

    #endregion
}
