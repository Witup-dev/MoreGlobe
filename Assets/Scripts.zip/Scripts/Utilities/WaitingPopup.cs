﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class WaitingPopup : MonoBehaviour
{

 [Header("Riferimenti UI")]
    public RectTransform spinner;
    public TextMeshProUGUI title;

    
#region Methods
    public void initialize(Transform canvas, string title = null)
    {

        if (!string.IsNullOrEmpty(title))
            this.title.text = title;

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;

        StartCoroutine(spinAround());

    }

    public void destroy()
    {
        GameObject.Destroy(this.gameObject);
    }


    private IEnumerator spinAround()
    {
        while (this.gameObject.activeInHierarchy)
        {
            spinner.transform.Rotate(new Vector3(0, 0, -45 * 5 * Time.deltaTime));
            yield return null;
        }
    }
#endregion
}
