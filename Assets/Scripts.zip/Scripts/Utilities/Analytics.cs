﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using UnityEngine.Android;

public class Analytics : MonoBehaviour
{

     [Header("Costanti / Dati condivisi")]
    public static Analytics instance { get; private set; }

    private readonly string URL = APIs.APIDOMAIN + "analytics/"; //  /token/action - /token/action/lat/long


#region Unity Lifecycle

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this);
        }
    }

    void Start()
    {

        //Ask permission for android
        if (GameData.instance.appConfig._gpsPermission)
        {
            if (Input.location.isEnabledByUser)
            {
                Input.location.Start();
            }
        }

        session(1);
    }


#endregion
#region API pubbliche (wrappa le coroutine) ..

    public void session(int type)
    {
        StartCoroutine(_session(type));
    }

    public void recognize(string id_marker,string sessionId)
    {
        StartCoroutine(_recognize(id_marker, sessionId));
    }

    public void site(string id_marker, string site,string sessionId)
    {
        StartCoroutine(_site(id_marker, site, sessionId));
    }

    public void videoAction(int action, string id_marker, int play_pause ,int time, string sessionId)
    {
        if(action == 1) StartCoroutine(_playPause(id_marker, play_pause, time, sessionId));
        if(action == 2) StartCoroutine(_stop(id_marker, time, sessionId));
    }

    public void cameraSwitch(int type, string sessionId)
    {
        StartCoroutine(_cameraSwitch(type, sessionId));
    }

    public void model3D(string id_marker, string id, string sessionId)
    {
        StartCoroutine(_model3D(id_marker, id, sessionId));
    }

    public void packageManaging(int action, string id_content)
    {
        if (action == 1) StartCoroutine(_downloadPackage(id_content));
        if (action == 2) StartCoroutine(_deletePackage(id_content));
    }
#endregion
#region Coroutine private (chiamate REST) ..
   

    private IEnumerator _session(int type)
    {
        int deviceType = GameData.instance.isTablet ? 1 : 2;
        string device = SystemInfo.operatingSystem;

        int os = 2;
#if UNITY_IOS
        os = 1;
#endif
#if UNITY_ANDROID

         os = 2;
#endif
        string model = SystemInfo.deviceModel;

        WWWForm form = new WWWForm();
        form.AddField("type", type);
        form.AddField("deviceType", deviceType);
        form.AddField("device", device);
        form.AddField("model", model);
        form.AddField("os", os);


        string uri = URL + GameData.instance.loggedUser._token + "/session" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_session(type));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_session(type));
                else Debug.Log("SessionCall Success");
            }
        }

        
    }

    private IEnumerator _recognize(string id_marker, string sessionId)
    {

        WWWForm form = new WWWForm();
        form.AddField("id_marker", id_marker);
        form.AddField("timestamp", sessionId);

        string uri = URL + GameData.instance.loggedUser._token + "/recognize" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_recognize(id_marker, sessionId));

            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_recognize(id_marker, sessionId));
                else Debug.Log("RecognizeCall Success");

            }
        }

        yield return null;
    }

    private IEnumerator _site(string id_marker, string site, string sessionId)
    {

        WWWForm form = new WWWForm();
        form.AddField("id_marker", id_marker);
        form.AddField("site", site);
        form.AddField("timestamp", sessionId);

        string uri = URL + GameData.instance.loggedUser._token + "/site-open" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_site(id_marker,site, sessionId));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_site(id_marker, site, sessionId));
                else Debug.Log("siteCall Success");
            }
        }

        yield return null;
    }

    private IEnumerator _playPause(string id_marker, int action, int time,string sessionId)
    {

        WWWForm form = new WWWForm();
        form.AddField("id_marker", id_marker);
        form.AddField("time", time);
        form.AddField("timestamp", sessionId);

        if (action == 1)
            form.AddField("type", "play");
        else
            form.AddField("type", "pause");

        string uri = URL + GameData.instance.loggedUser._token + "/play-pause-video" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_playPause(id_marker,action,time,sessionId));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_playPause(id_marker,action,time,sessionId));
                else Debug.Log("playPauseCall Success");
            }
        }

        yield return null;
    }

    private IEnumerator _stop(string id_marker, int time, string sessionId)
    {

        WWWForm form = new WWWForm();
        form.AddField("id_marker", id_marker);
        form.AddField("time", time);
        form.AddField("timestamp", sessionId);

        string uri = URL + GameData.instance.loggedUser._token + "/stop-video" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_stop(id_marker,time, sessionId));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_stop(id_marker, time, sessionId));
                else Debug.Log("stopCall Success");
            }
        }

        yield return null;
    }

    private IEnumerator _cameraSwitch(int type,string sessionId)
    {

        WWWForm form = new WWWForm();
        form.AddField("type", type);
        form.AddField("timestamp", sessionId);

        string uri = URL + GameData.instance.loggedUser._token + "/fotocamera" + getCoordinate();

        

        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_cameraSwitch(type, sessionId));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_cameraSwitch(type, sessionId));
                else Debug.Log("cameraSwitchCall Success");
            }
        }

        yield return null;
    }

    private IEnumerator _model3D(string id_marker, string id, string sessionId)
    {

        WWWForm form = new WWWForm();
        if(!string.IsNullOrEmpty(id_marker))
            form.AddField("id_marker", id_marker);
        
        if(!string.IsNullOrEmpty(id))
            form.AddField("id_3D", id);
        
        form.AddField("timestamp", sessionId);

        string uri = URL + GameData.instance.loggedUser._token + "/3d" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_model3D(id_marker,name, sessionId));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_model3D(id_marker,name, sessionId));
                else Debug.Log("3DModelCall Success");
            }
        }


        yield return null;
    }

    private IEnumerator _downloadPackage(string id_content)
    {

        WWWForm form = new WWWForm();
        form.AddField("id_content", id_content);

        string uri = URL + GameData.instance.loggedUser._token + "/content-download" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_downloadPackage(id_content));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_downloadPackage(id_content));
                else Debug.Log("downloadCall Success");
            }
        }

        yield return null;
    }

    private IEnumerator _deletePackage(string id_content)
    {

        WWWForm form = new WWWForm();
        form.AddField("id_content", id_content);

        string uri = URL + GameData.instance.loggedUser._token + "/content-delete" + getCoordinate();


        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                StartCoroutine(_deletePackage(id_content));
            }

            else
            {
                Response response = JsonUtility.FromJson<Response>(www.downloadHandler.text);

                if (!response._success) StartCoroutine(_deletePackage(id_content));
                else Debug.Log("deleteCall Success");
            }
        }

        yield return null;
    }

    #endregion


    public static string getCoordinate()
    {
#if UNITY_IOS
        if(GameData.instance.appConfig._gpsPermission && Input.location.isEnabledByUser && Input.location.status == LocationServiceStatus.Running && GameData.instance.iOSHavePermission);
        {
            return "/" + Input.location.lastData.latitude.ToString().Replace(",", ".") + "/" + Input.location.lastData.longitude.ToString().Replace(",", ".");
        }
#elif UNITY_ANDROID
        if (GameData.instance.appConfig._gpsPermission && Input.location.isEnabledByUser && Input.location.status == LocationServiceStatus.Running)
        {
            return "/" + Input.location.lastData.latitude.ToString().Replace(",", ".") + "/" + Input.location.lastData.longitude.ToString().Replace(",", ".");
        }
#endif

        return string.Empty;
    }


    void OnApplicationPause(bool pauseStatus)
    {
        Debug.Log("Application ending after " + Time.time + " seconds");

        if (pauseStatus)
        {
            StartCoroutine(_session(2));
        }
    }
}

