﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BlinkObject : MonoBehaviour
{
    private bool isOn;
    private Image _image;

    private IEnumerator blinkCoroutine;

    private void Awake()
    {
        _image = GetComponent<Image>();
        isOn = false;
        blinkCoroutine = blink();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }


    public void startBlink()
    {
        gameObject.SetActive(true);
        _image.enabled = true;
        StartCoroutine(blinkCoroutine);
    }

    public void stopBlink()
    {
        if (gameObject.activeInHierarchy)
        {
            gameObject.SetActive(false);
            _image.enabled = false;
            StopCoroutine(blinkCoroutine);
        }
        
    }
    

    private IEnumerator blink()
    {
        while (gameObject.activeInHierarchy)
        {
            if (!isOn)
            {
                isOn = true;
                _image.enabled = false;
                yield return new WaitForSeconds(0.5f);
            }

            else
            {
                isOn = false;
                _image.enabled = true;
                yield return new WaitForSeconds(0.5f);
            }
        }
        
    }

}
