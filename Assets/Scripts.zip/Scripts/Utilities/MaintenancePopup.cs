﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MaintenancePopup : MonoBehaviour
{
    [SerializeField]
    private Button dismissButton;
    public TextMeshProUGUI title;
    public TextMeshProUGUI body;
    public TextMeshProUGUI buttonText;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void initialize(Transform canvas)
    {
        title.text = GameData.instance.currentLanguage._popupMaintainanceJson[0]._title;
        body.text = GameData.instance.currentLanguage._popupMaintainanceJson[0]._message;
        buttonText.text = GameData.instance.currentLanguage._popupMaintainanceJson[0]._buttonText;

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;

        dismissButton.onClick.AddListener(() => {

            Destroy(this.gameObject);

        });


    }
}
