﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIController : MonoBehaviour
{

 [Header("Singleton")]
    public static UIController instance;


 [Header("Riferimenti UI")]
    public Transform mainCanvas;


 [Header("Prefab popup (serializzati da Inspector)")]

    [SerializeField]
    private PopupInfo infoPopupPrefab;
    [SerializeField]
    private PopupChoiceMessage choicePopupPrefab;
    [SerializeField]
    private WaitingPopup waitingPopupPrefab;
    [SerializeField]
    private DownloadPopup downloadPopupPrefab;
    [SerializeField]
    private MaintenancePopup MaintenanceInfoPopupPrefab;
    [SerializeField]
    private PopupConnect connectPopup;
    [SerializeField]
    private PopupTutorial tutorialPopup;
    [SerializeField]
    private PopupTutorialImage tutorialPopupImage;




#region UNITY LIFECYCLE
    private void Awake()
    {
       if(instance != null)
        {
            GameObject.Destroy(this.gameObject);
            return;
        }

        instance = this; 
    }

    // Start is called before the first frame update
    void Start()
    {

    }

#endregion

#region Factory methods per popup

    public PopupInfo CreateInfoPopup()
    {
        var popup = Instantiate(infoPopupPrefab);
        return popup.GetComponent<PopupInfo>();
    }

    public PopupChoiceMessage CreateChoicePopup()
    {
        var popup = Instantiate(choicePopupPrefab);
        return popup.GetComponent<PopupChoiceMessage>();
    }

    public WaitingPopup CreateWaitingPopup()
    {
        var popup = Instantiate(waitingPopupPrefab);
        return popup.GetComponent<WaitingPopup>();
    }

    public DownloadPopup CreateDownloadPopup()
    {
        var popup = Instantiate(downloadPopupPrefab);
        return popup.GetComponent<DownloadPopup>();
    }

    public MaintenancePopup CreateMaintenancePopup()
    {
        var popup = Instantiate(MaintenanceInfoPopupPrefab);
        return popup.GetComponent<MaintenancePopup>();
    }

    public PopupConnect CreateConnectPopup()
    {
        var popup = Instantiate(connectPopup);
        return popup.GetComponent<PopupConnect>();
    }

    public PopupTutorial CreateTutorialPopup()
    {
        var popup = Instantiate(tutorialPopup);
        return popup.GetComponent<PopupTutorial>();
    }
    public PopupTutorialImage CreateTutorialPopupImage()
    {
        var popup = Instantiate(tutorialPopupImage);
        return popup.GetComponent<PopupTutorialImage>();
    }

#endregion
}
