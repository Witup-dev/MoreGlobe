﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class APIs
{

 [Header("Dominio base")]
 //   : string  ' dominio base delle API
    //public const string APIDOMAIN = "https://www.moreglobe.com/be/api/";
    public const string APIDOMAIN = "https://arstudio.moreglobe.com/api/";


 [Header("Versioning")]
 // : string  ' endpoint per controllare la versione dell’app
    public static string VERSION_CONTROL = APIDOMAIN + "version/";



 [Header("Autenticazione / Utente")]
   //: string  ' login classico (email/password)
    public static string LOGIN_SERVICE = APIDOMAIN +"auth";

     //: string  ' login tramite Facebook
    public static string LOGIN_FB_SERVICE = APIDOMAIN + "auth/auth-fb";
  
    //  : string  ' login tramite Apple
    public static string LOGIN_APPLE_SERVICE = APIDOMAIN + "auth/auth-apple";
   
   //  : string  ' login tramite Google
    public static string LOGIN_GOOGLE_SERVICE = APIDOMAIN + "auth/auth-google";
   
     //: string  ' registrazione nuovo utente (signup)
    public static string REGISTRATION_SERVICE = APIDOMAIN + "signup";
  
   // : string  ' recupero password (con query email)
    public static string PASSWORD_RECOVER_SERVICE = APIDOMAIN + "auth/recovery?email=";
 
 // string ' verifica univocità username/email
    public static string CHECK_USERNAME_AND_EMAIL_SERVICE = APIDOMAIN + "check?";


[Header("Contenuti & DLC")]
// : string  ' verifica/ottenimento aggiornamenti contenuti
    public static string CONTENT_UPDATE = APIDOMAIN + "content";
    
    //: string  ' check & download dei DLC (contenuti scaricabili)
    public static string CHECK_AND_DOWNLOAD_DLC = APIDOMAIN + "download/";
   
   
   
[Header("Manutenzione & Notifiche")]

//: string  ' recupero contenuti pubblicitari / adv
    public static string TAKE_ADV = APIDOMAIN + "adv/";
    
    //: string  ' verifica stato manutenzione del servizio
    public static string CHECK_FOR_MAINTENANCE = APIDOMAIN + "maintenance";

//: string  ' recupero notifiche per utente/token
    public static string CHECK_FOR_NOTIFICATION = APIDOMAIN + "notifiche/";



[Header("Update contenuti / OneSignal")]
    // <Token>/check-marker-update?id_content=<idContent>&date=<yyyy-MM-dd HH:mm:ss>
    // : string  ' check update marker/contenuti (con token/id_content/date)
    public static string UPDATE_CONTENT = APIDOMAIN + "update/";
        
    //token/<operation>
    //register-token
    //destroy-token
    // : string  ' registrazione / gestione deviceId OneSignal (token/operation)
    public static string HANDLE_ONESIGNAL_USERID = APIDOMAIN + "device/";

    //token/LIST -> downloaded content list  
    //token/DELETE/idContent -> cancellazione   
    //token/SET/idContent -> downlaod a content
    //  : string  ' operazioni sull’elenco contenuti utente (LIST/DELETE/SET)
    public static string LOGGED_USER_ACTION = APIDOMAIN + "content/";



[Header("Elenchi contenuti & brand")]
    //category = sport,event,news
    //: string  ' lista contenuti per categoria (sport, event, news)
    public static string TAKE_CONTENTS = APIDOMAIN + "content?category="; 
    
    
    //category = sport,event,news
    //  : string  ' lista pagine brand (is_brand=1)
    public static string TAKE_BRAND_PAGES = APIDOMAIN + "content?is_brand=1";



[Header("Marker & 3D / Spatial")]
    //token/idmarker/latitute/longitude  (lat e long opzionali)
//: string  ' metadati marker (token/idmarker/lat/long)
    public static string TAKE_MARKER_METADATA = APIDOMAIN + "marker/"; 

    //token
    //: string  ' elenco modelli 3D associati al token
    public static string TAKE_3D_MODEL_LIST = APIDOMAIN + "_3d/";

    //idContent
   // : string  ' lista modelli per modalità "spatial" dato id_content
    public static string LIST_FOR_SPATIAL_TO_ADD = "/get-list-by-content?id_content=";




[Header("Business card & Dashboard")]
    //idMarker
     // : string  ' dati business card per un marker
    public static string GET_BUSINESS_CARD = APIDOMAIN + "/businesscard?id_marker=";

 //: string  ' URL dashboard profilo utente (token in querystring)
    public static string PROFILE_VIEW = "https://arstudio.moreglobe.com/app/dashboard?token=";
}
