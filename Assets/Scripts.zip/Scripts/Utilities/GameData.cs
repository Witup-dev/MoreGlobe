﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
//using Facebook.Unity;
using Vuplex.WebView;

public class GameData : MonoBehaviour
{
     // --- SINGLETON  ---
    public static GameData instance { get; private set; }

 [Header("Config")]
    public AppConfiguration appConfig;

 [Header("Session flags")]
    //SessionVariable
    public bool hasStarted; //Start the application
    public bool hasContentUpdated; //i have updated the contents
    public bool hasLoadUserContent; // the user content has been loaded
    public bool hasStartAR; //if i started ar once
    public bool isInMaintenance;
    public bool webviewForVideo;
    public bool isTablet; // if the device is a tablet or smartphone
    public bool iOSHavePermission;
    public bool profileLanguageRefresh;    
    public bool canLoadOn;



 [Header("Session flags")]

    public long sessionId;
    public Marker fullScreenVideoMarker;
    public int fullScreenTimeToResume;
    public AvailableContents availableDownloadedContent;
    public User loggedUser;
    public string selectedContentId;
    public string selectedLanguage;
    public CustomizationItem selectedCustomContent;
    public List<MarkerModel> modelListForSpatial;
    public List<MarkerModel> modelListForSpatialDemo;
    public string iOS_IDFA;



[Header(" .. UI / Facebook ..")]

    private WaitingPopup FbWaiting;



[Header("Lingua")]

    public JsonLanguage currentLanguage;



[Header("Lingua")]

    public GeneralLogin loginMode;




// --- UNITY LIFECYCLE ---
#region UNITY LIFECYCLE

    private void Awake()
    {

        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(this);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        hasStarted = false;
        hasContentUpdated = false;
        hasLoadUserContent = false;
        hasStartAR = false;

        fullScreenTimeToResume = 0;
        fullScreenVideoMarker = null;

        selectedCustomContent = null;

        iOSHavePermission = false;

        currentLanguage = null;
        profileLanguageRefresh = false;

        canLoadOn = false;

        loginMode = null;

        modelListForSpatial = new List<MarkerModel>();
        modelListForSpatialDemo = new List<MarkerModel>();



    }

    private void Start()
    {
        Web.SetUserAgent(true);

        //If to setting the system language
        if (PlayerPrefs.HasKey("appLanguage"))
        {
            Debug.Log($"final debug: have the language");
            selectedLanguage = PlayerPrefs.GetString("appLanguage");
            var jsonLanguageFile = Resources.Load("Localization/" + selectedLanguage) as TextAsset;
            currentLanguage = JsonUtility.FromJson<JsonLanguage>(jsonLanguageFile.text);
        }
        else
        {
            Debug.Log($"final debug: not have the language");
            selectedLanguage = "en";
            var jsonLanguageFile = Resources.Load("Localization/en") as TextAsset;
            currentLanguage = JsonUtility.FromJson<JsonLanguage>(jsonLanguageFile.text);
        }

        //Retrieve the user downloaded content list from playerPrefs
        if (PlayerPrefs.HasKey("availableContents"))
        {
            Debug.Log($"final debug: have available contents");
            availableDownloadedContent = JsonUtility.FromJson<AvailableContents>(PlayerPrefs.GetString("availableContents"));

        }
        else
        {
            Debug.Log($"final debug: not have the available contents");
            availableDownloadedContent = new AvailableContents();
        }
        //Retrieve the logged user from the PlayerPrefs
        if (PlayerPrefs.HasKey("loggedUser"))
        {
            Debug.Log($"final debug: Logged user");
            loggedUser = JsonUtility.FromJson<User>(PlayerPrefs.GetString("loggedUser"));
            gameObject.AddComponent<Analytics>();

            if (PlayerPrefs.HasKey("availableContents"))
            {
                foreach (var dlc in availableDownloadedContent._dlcs)
                {
                    if (string.IsNullOrEmpty(dlc._downloadDate))
                        dlc._downloadDate = "2021-12-01 10:10:10";
                }
            }

            if (!PlayerPrefs.HasKey("syncOneSignalDownload"))
            {
                Debug.Log($"final debug: not have the syncOneSignal");
                StartCoroutine(Utilities.handleOnesignalPlayerID(false));
                PlayerPrefs.SetInt("syncOneSignalDownload", 1);
                PlayerPrefs.Save();
            }

            if (loggedUser._loginType.Equals("g"))//logged with google
            {

                //loginMode = gameObject.AddComponent<GoogleLogin>();
                //loginMode.init();
                canLoadOn = true;
            }

            /* else if (loggedUser._loginType.Equals("f"))//logged with facebook
            {
                loginMode = gameObject.AddComponent<FacebookLogin>();
                loginMode.init();
            } */

            else if (loggedUser._loginType.Equals("a"))//logged with apple
            {
                loginMode = gameObject.AddComponent<AppleLogin>();
                loginMode.init();
                canLoadOn = true;
            }

            else
            {
                canLoadOn = true;
            }

        }

        else
        {
            Debug.Log($"final debug: have to log in");
            Debug.Log("bisogna loggare");
            loggedUser = new User();
            canLoadOn = true;
        }





    }

#endregion

// --- Behavior ---
#region Behaviour

    public IEnumerator StartNFcArContent(string text)
    {
        PlayerPrefs.SetString("NFC_ID", text);
        Debug.Log($"oh si { PlayerPrefs.GetString("NFC_ID")}");
        yield return new WaitForEndOfFrame();
        MenuManager.instance.goToLastContent();
    }

    public void updateAppConfig()
    {
        PlayerPrefs.SetString("appConfig", JsonUtility.ToJson(appConfig));
        PlayerPrefs.Save();
    }

        #endregion
      
/* #region FACEBOOK_TO_REMOVE

    private void onInitCallBack()
    {

        if (FB.IsInitialized)
        {
            if (!FB.IsLoggedIn)
            {
                if (loggedUser._loginType.Equals("f"))
                {
                    loggedUser = new User();
                }
            }
        }

        else
        {
            FB.Init(onInitCallBack, onHideUnity);
        }
    }

    private void onHideUnity(bool isGameShown)
    {
        if (!isGameShown)
        {
            // Pause the game - we will need to hide
          Time.timeScale = 0;
        }
        else
        {
            // Resume the game - we're getting focus again
            Time.timeScale = 1;
        }
    }

    public void facebookLogout()
    {
        FB.LogOut();
    }

    public void signInWithFacebook()
    {
        FB.LogInWithReadPermissions(new List<string>() { "public_profile", "email", "user_friends" }, onFacebookLoginResult);
    }

    private void onFacebookLoginResult(ILoginResult result)
    {
        if (FB.IsLoggedIn)
        {
            Debug.Log("login effettuato");
            handleFacebookLogin();
        }
        else
        {
            Debug.Log("User cancel login");
        }
    }

    private void handleFacebookLogin()
    {
        FbWaiting = UIController.instance.CreateWaitingPopup();
        FbWaiting.initialize(UIController.instance.mainCanvas, "LOGGING IN...");
        FB.API("/me?fields=id,name,email", HttpMethod.GET, GetFacebookInfo, new Dictionary<string, string>() { });
    }

    private void GetFacebookInfo(IResult result)
    {

        if (result.Error == null)
        {
            var accessToken = AccessToken.CurrentAccessToken;

            Debug.Log(result.ResultDictionary["id"].ToString());
            Debug.Log(result.ResultDictionary["name"].ToString());
            Debug.Log(result.ResultDictionary["email"].ToString());

            loggedUser._email = result.ResultDictionary["email"].ToString();
            loggedUser._fbID = accessToken.UserId;
            loggedUser._username = result.ResultDictionary["name"].ToString();

            loggedUser._loginType = "f";

            PlayerPrefs.SetString("loggedUser", JsonUtility.ToJson(loggedUser));
            PlayerPrefs.Save();

            LoginSceneManager.instance.signInWithFacebook(FbWaiting);

        }
        else
        {
            FbWaiting.destroy();
            Debug.Log(result.Error);
        }
    }

#endregion  */

}