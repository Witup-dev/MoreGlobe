﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class PopupInfo : MonoBehaviour
{

 [Header("Riferimenti UI")]

    [SerializeField]
    private Button dismissButton;
    [SerializeField]
    private TextMeshProUGUI title;
    [SerializeField]
    private TextMeshProUGUI body;
    [SerializeField]
    private TextMeshProUGUI buttonText;
    

    public void initialize(Transform canvas, string title, string bodyTxt, string btnTxt, string type = "info", Action action = null)
    {

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;

        if (string.IsNullOrEmpty(title))
        {
            this.title.gameObject.SetActive(false);
        }

        else
        {
            if (type == "error")
                this.title.color = Color.red;

            if (type == "warning")
                this.title.color = new Color32(255, 208, 0,255); //FFBD00

            this.title.text = title;
        }

        body.text = bodyTxt;
        buttonText.text = btnTxt;

        if(action == null)
        {
            dismissButton.onClick.AddListener( () => {

                GameObject.Destroy(this.gameObject);

            });

        }

        else
        {
            dismissButton.onClick.AddListener(() => {

                action();

            });
        }

        
    }


    public void destroy()
    {
        Destroy(gameObject);
    }
}
