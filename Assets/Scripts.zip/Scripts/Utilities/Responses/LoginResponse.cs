﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class LoginResponse : Response
{

    [SerializeField]
    private string token;

    [SerializeField]
    private string username;

    [SerializeField]
    private string id;

    public string _username
    {
        get { return username; }

    }

    public string _token
    {
        get { return token; }

    }

    public string _id
    {
        get { return id; }

    }



}
