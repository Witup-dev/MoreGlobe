﻿using UnityEngine;

[System.Serializable]
public class MetadataResponse : Response
{
    [SerializeField]
    private Marker metadata;


    public Marker _metadata
    {
        get { return metadata; }
    }
}
