﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class NoticeResponse : Response
{
    [SerializeField]
    private List<Notice> data;


    public List<Notice> _notices
    {
        get { return data; }
    }
}
