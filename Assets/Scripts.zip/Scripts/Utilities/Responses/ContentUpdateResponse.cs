using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ContentUpdateResponse : Response
{
    [SerializeField]
    private List<UpdateContent> data;


    public List<UpdateContent> _data
    {
        get { return data; }
    }
}

[System.Serializable]
public class UpdateContent
{
    [SerializeField]
    private string id;

    [SerializeField]
    private string action;

    [SerializeField]
    private string link;

    public UpdateContent(string id, string action, string link)
    {
        this.id = id;
        this.action = action;
        this.link = link;
    }


    public string _id
    {
        get { return id; }
    }

    public string _action
    {
        get { return action; }
    }

    public string _link
    {
        get { return link; }
    }
}