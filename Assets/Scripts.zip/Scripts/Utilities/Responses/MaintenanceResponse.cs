﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MaintenanceResponse : Response
{
    [SerializeField]
    private bool maintenance;

    [SerializeField]
    private bool webview;

    public bool _maintenance
    {
        get { return maintenance; }
    }

    public bool _webview
    {
        get { return webview; }
    }
}
