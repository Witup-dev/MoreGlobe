﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Response 
{

 //indica se la richiesta è andata a buon fine
    [SerializeField]
    private bool success;


// ' messaggio associato (esito, errore, dettaglio)
  
    [SerializeField]
    private string message;

//' flag per abilitare/disabilitare modalità spatial
    [SerializeField]
    private bool switchSpatial;


// ' espone il risultato della richiesta
    public bool _success
    {
        get { return success; }

    }

//' espone il messaggio ricevuto dalle API
    public string _message
    {
        get { return message; }

    }

 //' espone lo stato dello switch spatial
    public bool _switchSpatial
    {
        get { return switchSpatial; }
    }

}
