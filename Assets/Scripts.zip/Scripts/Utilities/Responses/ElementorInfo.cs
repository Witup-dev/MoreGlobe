using UnityEngine;

[System.Serializable]
public class ElementorInfo : Response
{
    public DataRequest[] items;


    public static ElementorInfo CreateFromJSON(string jsonString)
    {
        return JsonUtility.FromJson<ElementorInfo>(jsonString);
    }
}