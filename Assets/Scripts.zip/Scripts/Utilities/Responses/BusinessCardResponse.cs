using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BusinessCardResponse : Response
{

    [SerializeField]
    private BusinessCard data;


    public BusinessCard _data
    {
        get { return data; }
    }

}
