﻿using UnityEngine;

[System.Serializable]
public class ProjectContentResponse : Response
{

    [SerializeField]
    private Content content;


    public Content _content
    {
        get { return content; }
    }

}