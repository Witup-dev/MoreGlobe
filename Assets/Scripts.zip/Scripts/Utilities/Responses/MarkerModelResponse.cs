﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MarkerModelResponse : Response
{

    [SerializeField]
    private List<MarkerModel> data;


    public List<MarkerModel> _data
    {
        get { return data; }
        set { data = value; }
    }
}
