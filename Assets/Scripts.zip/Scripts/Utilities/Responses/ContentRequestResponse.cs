﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ContentRequestResponse : Response
{

    [SerializeField]
    private List<Content> content;


    public List<Content> _contents
    {
        get { return content; }
    }

}