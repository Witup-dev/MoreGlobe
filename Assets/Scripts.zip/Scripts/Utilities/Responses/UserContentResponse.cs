﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;








[System.Serializable]
public class UserContentResponse : Response
{
    [SerializeField]
    private List<UserDataContent> data;


    public List<UserDataContent> _data
    {
        get { return data; }
        set { data = value; }
    }
    

    public List<string> getAllContentIDs()
    {
        List<string> list = new List<string>();

        foreach(var content in data)
        {
            list.Add(content._id_content);
        }


        return list;
    }

}


[System.Serializable] 
public class UserDataContent
{
    [SerializeField]
    private string id_content;

    [SerializeField]
    private string thumbnailLibraryLink;

    [SerializeField]
    private string contentName;


    [SerializeField]
    private string description;

    [SerializeField]
    private bool expired;


    public string _id_content
    {
        get { return id_content; }
        set { id_content = value; }
    }

    public string _thumbnailLibraryLink
    {
        get { return thumbnailLibraryLink; }
        set { thumbnailLibraryLink = value; }
    }

    public string _description
    {
        get { return description; }
        set { description = value; }
    }

    public string _contentName
    {
        get { return contentName; }
        set { contentName = value; }
    }

    public bool _expired
    {
        get { return expired; }
        set { expired = value; }
    }
}