﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DownloadPopup : MonoBehaviour
{

    public Slider slider;
    public TextMeshProUGUI perc;
    public TextMeshProUGUI title;



    public void initialize(Transform canvas, string title = null)
    {

        slider.value = 0;

        if (!string.IsNullOrEmpty(title))
            this.title.text = title;
        else
            this.title.text = GameData.instance.currentLanguage._downloading;

        transform.SetParent(canvas);
        transform.localScale = Vector3.one;
        transform.localPosition = Vector3.zero;
        GetComponent<RectTransform>().offsetMin = Vector2.zero;
        GetComponent<RectTransform>().offsetMax = Vector2.zero;

    }

    public void setValue(float perc)
    {
        slider.value = perc;
        this.perc.text = perc + "%";
    }


    public void destroy()
    {
        GameObject.Destroy(this.gameObject);
    }


}
