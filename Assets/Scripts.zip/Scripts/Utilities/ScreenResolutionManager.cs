﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScreenResolutionManager : MonoBehaviour
{
    public static ScreenResolutionManager instance { get; private set; }

    private int[] widths = { 480, 720, 1080, 1440 };

    private Dictionary<int, DimConfiguration> gridConfs = new Dictionary<int, DimConfiguration>();
    private Dictionary<int, DimConfiguration> listConfs = new Dictionary<int, DimConfiguration>();

    private DimConfiguration _gridConf;
    private DimConfiguration _listConf;

    public DimConfiguration gridConf
    {
        get
        {
            return _gridConf;
        }
    }

    public DimConfiguration listConf
    {
        get
        {
            return _listConf;
        }
    }


    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        gridConfs.Add(1080, new DimConfiguration(
            new Vector2(250, 400),
            new Vector2(100, 100),
            new RectOffset(50, 50, 20, 0),
            100,
            40
            ));

        gridConfs.Add(720, new DimConfiguration(
            new Vector2(200, 260),
            new Vector2(150, 250),
            new RectOffset(50, 50, 100, 0),
            60,
            40
            ));

        listConfs.Add(1080, new DimConfiguration(
            new Vector2(800, 400),
            new Vector2(0, 25),
            new RectOffset(0, 0, 20, 0),
            150,
            40
            ));

        listConfs.Add(720, new DimConfiguration(
            new Vector2(600, 300),
            new Vector2(0, 200),
            new RectOffset(0, 0, 75, 0),
            100,
            40
            ));

    }


    private void Start()
    {
        _gridConf = getGridConf(Screen.currentResolution.width);
        _listConf = getListConf(Screen.currentResolution.width);
    }

    private void getCloseRes(int width)
    {
        
    }

    public DimConfiguration getGridConf(int resWidth)
    {
        if (resWidth < 1080)
        {
            return gridConfs[720];
        }

        return gridConfs[1080];
    }

    public DimConfiguration getListConf(int resWidth)
    {
        if (resWidth < 1080)
        {
            return listConfs[720];
        }

        return listConfs[1080];
    }

}

public class DimConfiguration
{
    public Vector2 cellSize;
    public Vector2 spacing;
    public RectOffset padding;// top,right,bottom,left

    public float textContainerSize;
    public float maxTextSize;

    public DimConfiguration(Vector2 cellSize, Vector2 spacing, RectOffset padding, 
        float textContainerSize, float maxTextSize)
    {

        this.cellSize = cellSize;
        this.spacing = spacing;
        this.padding = padding;
        this.textContainerSize = textContainerSize;
        this.maxTextSize = maxTextSize;

    }

}


