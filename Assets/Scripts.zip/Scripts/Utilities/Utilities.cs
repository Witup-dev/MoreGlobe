﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.IO;
using System;
using OneSignalSDK;

public static class Utilities
{


 [Header("Costanti / Dati condivisi")]
 //' elenco stringhe "1".."31"
    public static List<string> DAYS = new List<string>(new string[] {"1","2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13",
        "14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"});

// ' elenco nomi mesi in inglese
    public static List<string> MONTHS = new List<string>(new string[] {"January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"});

// ' tipi di azione per le notifiche ("open-project", "detail-project", ...)
    public static string[] NOTICEACTION = { "open-project", "detail-project", "website", "webview" };

 //' testi "scegli lingua" / "conferma" per le varie lingue
    public static Dictionary<string, string[]> chooseLanguageMap = new Dictionary<string, string[]>()
    {
        {"en", new string[] {"Choose your language","Confirm"}},
        {"it", new string[] {"Scegli la tua lingua","Conferma"}},
        {"de", new string[] {"Wählen Sie Ihre Sprache", "Bestätigen Sie"}},
        {"fr", new string[] {"Choisissez votre langue", "Confirmer"}},
        {"es", new string[] {"Elija su idioma", "Confirmar"}}
    };



 #region  Utility generali

 //' calcola la diagonale fisica dello schermo in pollici usando Screen.width/height/dpi
    public static float DeviceDiagonalSizeInInches()
    {
        float screenWidth = Screen.width / Screen.dpi;
        float screenHeight = Screen.height / Screen.dpi;
        float diagonalInches = Mathf.Sqrt(Mathf.Pow(screenWidth, 2) + Mathf.Pow(screenHeight, 2));

        Debug.Log("Getting device inches: " + diagonalInches);

        return diagonalInches;
    }
    #endregion

    #region AYNC_CALLS
    //  ' scarica un’immagine da URL e la imposta come sprite di una Image (con placeholder loading/errore)
    public static IEnumerator getImageAndApply(string url, Image putInto, Sprite loadingImg, Sprite error)
    {
        using (var www = UnityWebRequestTexture.GetTexture(url))
        {
            putInto.sprite = loadingImg;

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
                putInto.sprite = error;
            }
            else
            {
                if (www.isDone)
                {
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    Sprite sprite = Sprite.Create(x, new Rect(0, 0, x.width, x.height), new Vector2(x.width, x.height));
                    putInto.sprite = sprite;
                }
                else
                {
                    putInto.sprite = error;
                }
            }
        }
    }


// ' scarica un’immagine e la salva su disco come file di byte (Path.Combine(path, name))
    public static IEnumerator donwloadLocallyImageAsBytes(string url, string path, string name)
    {
        using (var www = UnityWebRequestTexture.GetTexture(url))
        {

            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                if (www.isDone)
                {
                    Texture2D x = DownloadHandlerTexture.GetContent(www);
                    File.WriteAllBytes(Path.Combine(path, name), www.downloadHandler.data);
                }
            }
        }
    }


  //' chiama l’endpoint di maintenance e aggiorna GameData.isInMaintenance / webviewForVideo

    public static IEnumerator checkForMaintenance(bool doneInSplash)
    {
        using (UnityWebRequest www = UnityWebRequest.Get(APIs.CHECK_FOR_MAINTENANCE))
        {
            yield return www.SendWebRequest();

            //Se c'è un errore nella request 
            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log("maintanance error: " + www.error);
                GameData.instance.isInMaintenance = false;
                GameData.instance.webviewForVideo = false;
            }

            else
            {
                MaintenanceResponse response = JsonUtility.FromJson<MaintenanceResponse>(www.downloadHandler.text);

                if (response._success)
                {
                    GameData.instance.isInMaintenance = response._maintenance;
                    GameData.instance.webviewForVideo = response._webview;
                }


            }

            //    if(doneInSplash)
            //        GameData.instance.isMaintainanceCallDone = true;
        }
    }




//' registra o rimuove il player_id di OneSignal per l’utente loggato
    //' (usa APIs.HANDLE_ONESIGNAL_USERID e il token di GameData.loggedUser)
   public static IEnumerator handleOnesignalPlayerID(bool isDeleting)
{
    
    var push = OneSignal.User.PushSubscription;
    string userID = push != null ? push.Id : null;

    if (!string.IsNullOrEmpty(userID))
    {
        string uri = APIs.HANDLE_ONESIGNAL_USERID + GameData.instance.loggedUser._token + "/";

        if (!isDeleting)
        {
            uri += "register-token";
        }
        else
        {
            uri += "destroy-token";
        }

        WWWForm form = new WWWForm();
        form.AddField("player_id", userID);

        using (UnityWebRequest www = UnityWebRequest.Post(uri, form))
        {
            yield return www.SendWebRequest();

            
            if (www.result != UnityWebRequest.Result.Success)
            {
                //TODO: error handling
            }
            else
            {
                //TODO: Success response handling
            }
        }
    }

    
    yield return null;
}

    #endregion


}
