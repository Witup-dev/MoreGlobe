﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using DG.Tweening;
using TMPro;

public class ScrollButtonOption : MonoBehaviour, IDragHandler, IEndDragHandler
{
    public RectTransform container;
    private Vector2 position;
    public float percentTreshold = 0.2f;
    private bool isPhotoButton;
    public TextMeshProUGUI photo;
    public TextMeshProUGUI video;

    public GameObject photoButton;
    public GameObject ScreenCaptureButton;


    private float tweenDuration = 0.25f;

    // Start is called before the first frame update
    void Start()
    {

#if UNITY_IOS
        photo.text = "PHOTO";
        //this.gameObject.GetComponent<ScrollButtonOption>().enabled = false;
#else

        photo.text = "PHOTO";
        //this.gameObject.GetComponent<ScrollButtonOption>().enabled = false;
#endif
        isPhotoButton = true;
        position = Vector2.zero;
    }

    public void OnEndDrag(PointerEventData data)
    {
        float percentage = (data.pressPosition.x - data.position.x) / Screen.width;

        if (Mathf.Abs(percentage) >= percentTreshold)
        {

            if (!isPhotoButton)
            {
                isPhotoButton = true;

                photo.rectTransform.DOAnchorPos(new Vector2(-100, photo.rectTransform.offsetMax.y), tweenDuration).OnComplete(goBackPhoto);
                photo.DOColor(new Color(1, 1, 1, 0.5f), tweenDuration / 2);

                video.rectTransform.DOAnchorPos(new Vector2(100, video.rectTransform.offsetMax.y), tweenDuration).OnComplete(goBackVideo);
                video.DOColor(new Color(1, 1, 1, 0.5f), tweenDuration / 2);

                photoButton.SetActive(true);
                ScreenCaptureButton.SetActive(false);
            }
            else
            {
                isPhotoButton = false;


                photo.rectTransform.DOAnchorPos(new Vector2(-100, photo.rectTransform.offsetMax.y), tweenDuration).OnComplete(goBackPhoto);
                photo.DOColor(new Color(1, 1, 1, 0.5f), tweenDuration/2);

                video.rectTransform.DOAnchorPos(new Vector2(100, video.rectTransform.offsetMax.y), tweenDuration).OnComplete(goBackVideo);
                video.DOColor(new Color(1, 1, 1, 0.5f), tweenDuration / 2);

                photoButton.SetActive(false);
                ScreenCaptureButton.SetActive(true);
            }
        }
    }

    private void goBackVideo()
    {
        video.rectTransform.DOAnchorPos(new Vector2(0, photo.rectTransform.offsetMax.y), tweenDuration);

        if (isPhotoButton)
            video.DOColor(new Color(1, 1, 1, 0), tweenDuration / 2);
        else
            video.DOColor(new Color(1, 1, 1, 1f), tweenDuration / 2);
    }

    private void goBackPhoto()
    {

        photo.rectTransform.DOAnchorPos(new Vector2(0, photo.rectTransform.offsetMax.y), tweenDuration);

        if(isPhotoButton)
            photo.DOColor(new Color(1, 1, 1, 1f), tweenDuration / 2);
        else
            photo.DOColor(new Color(1, 1, 1, 0), tweenDuration / 2);
    }

    public void OnDrag(PointerEventData eventData)
    {

    }
}
