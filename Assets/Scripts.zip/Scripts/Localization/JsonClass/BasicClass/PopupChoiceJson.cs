﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PopupChoiceJson 
{
    [SerializeField]
    private string title;
    [SerializeField]
    private string message;
    [SerializeField]
    private string positive;
    [SerializeField]
    private string negative;


    public string _title
    {
        get { return title; }
    }

    public string _message
    {
        get { return message; }
    }

    public string _positive
    {
        get { return positive; }
    }

    public string _negative
    {
        get { return negative; }
    }


}
