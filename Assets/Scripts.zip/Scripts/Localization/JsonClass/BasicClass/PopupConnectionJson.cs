﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PopupConnectionJson 
{
    [SerializeField]
    private string title;
    [SerializeField]
    private string message;
    [SerializeField]
    private string buttonText;


    public string _title
    {
        get { return title; }
    }

    public string _message
    {
        get { return message; }
    }

    public string _buttonText
    {
        get { return buttonText; }
    }
}
