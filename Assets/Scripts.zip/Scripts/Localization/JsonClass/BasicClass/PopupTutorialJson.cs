﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PopupTutorialJson
{
    [SerializeField]
    private string title;
    [SerializeField]
    private string message;


    public string _title
    {
        get { return title; }
    }

    public string _message
    {
        get { return message; }
    }

}
