﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class JsonLanguage
{


 [Header("Collezioni popup")]

    [SerializeField]
   // ' Elenco dei testi per i popup informativi (titolo, messaggio, bottone)
    private List<PopupInfoJson> popupInfoJson;

    [SerializeField]
     // ' Elenco dei testi per i popup con scelta (es. Sì/No, Continua/Annulla)
    private List<PopupChoiceJson> popupChoiceJson;

    [SerializeField]
    // ' Elenco dei testi per i popup tutorial (passi, istruzioni guidate)
    private List<PopupTutorialJson> popupTutorialJson;

    [SerializeField]
   // ' Elenco dei testi per i popup di manutenzione (app in manutenzione, messaggi server)
    private List<PopupMaintainanceJson> popupMaintainanceJson;

[Header("Testi login / registrazione")]
    //' Testi pagina contenuti
    [SerializeField]
    private string contentSportText;
    [SerializeField]
    private string contentPartnersText;
    [SerializeField]
    private string contentEventsText;


[Header("Testi login / registrazione")]

    [SerializeField]
    //' Testo istruzioni per la compilazione dello username
    private string usernameInstruction;

    [SerializeField]
    // ' Testo istruzioni per la compilazione della password
    private string passwordInstruction;

    [SerializeField]
    //  ' Testo dell’etichetta "Conferma password"
    private string confirmPassword;

    [SerializeField]
    //  ' Testo link/etichetta "Termini e servizi"
    private string termsAndServices;

    [SerializeField]
    // ' Testo tipo "Non sei ancora registrato?"
    private string notAMemberYet;

     [SerializeField]
     //  ' Testo "Password dimenticata?"
    private string passwordForgotten;

    [SerializeField]
    //  ' Testo istruzioni per controllare la mail dopo la registrazione
    private string checkEmailForSignUp;

    [SerializeField]
    //' Testo istruzioni per controllare la mail dopo la richiesta di recupero password
    private string checkEmailForPasswordRecover;

    [SerializeField]
    // ' Testo descrittivo del flusso di recupero password
    private string passwordRecoverText;

    [SerializeField]
    //' Testo del pulsante/azione "Crea account"
    private string createAccount;

    [SerializeField]
    //  ' Testo generico del pulsante di conferma
    private string confirm;

    [SerializeField]
   //  ' Testo per l’azione di login (es. "Accedi", "Login")
    private string loginAction;

    [SerializeField]
    //  ' Prefisso testo "Continua con ..."
    private string continueWith;

    [SerializeField]
      //' Testo "Crea nuovo account"
    private string createNewAccount;

    [SerializeField]
   // ' Testo generico per pulsante "Continua"
    private string generalContinue;



    [Header("Testi di stato / caricamento")]

    [SerializeField]
    // ' Messaggio di caricamento AR (es. "Caricamento AR in corso...")
    private string loadingAR;

    [SerializeField]
    //' Messaggio di inizializzazione (es. "Inizializzazione...")
    private string initializating;

    [SerializeField]
    //' Messaggio "Cancellazione in corso..."
    private string deletingInProgress;

    [SerializeField]
    //  ' Messaggio "Aggiornamento AR in corso..."
    private string refreshingAR;

    [SerializeField]
     // ' Messaggio "Decompressione in corso..."
    private string decompressing;

    [SerializeField]
    //  ' Messaggio "Caricamento profilo..."
    private string loadingProfile;

     [SerializeField]
     //  ' Testo che informa sulla versione più recente dell’app
    private string latestVersion;

    [SerializeField]
    //' Testo generico di "Caricamento..."
    private string loading;
    
    [SerializeField]
    private string projectDownload;

    [SerializeField]
    //  ' Messaggio "Download in corso..."
    private string downloading;

    [SerializeField]
    //  ' Messaggio "Accesso in corso..."
    private string loggingIn;

    [SerializeField]
    //  ' Messaggio "Disconnessione in corso..."
    private string loggingOut;



    [Header("Testi di stato / caricamento")]


    [SerializeField]
    //  ' Titolo finestra "Scopri nuovi contenuti"
    private string findNewContentTitle;

    [SerializeField]
     // ' Corpo del messaggio "Scopri nuovi contenuti"
    private string findNewContentBody;

    [SerializeField]
    //' Titolo "Vuoi continuare a guardare?"
    private string keepWatchingTitle;

    [SerializeField]
    //' Testo "Vuoi continuare a guardare?" (versione principale)
    private string keepWatchingBody;
    
    [SerializeField]
    // ' Testo alternativo "Vuoi continuare a guardare?" (versione NO)
    private string keepWatchingBodyNo;
   
    [SerializeField]
    //  ' Testo "Nessun contenuto disponibile"
    private string noContentAvailable;

    [SerializeField]
    // ' Testo "Nessuna notifica disponibile"
    private string noNotification;

     [SerializeField]
     //' Testo "Nessun contenuto scaricato"
    private string noContentDownloaded;

    [SerializeField]
    //  ' Etichetta della sezione "Notizie/Avvisi"
    private string noticeSection;

    [SerializeField]
    //' Etichetta della sezione "Libreria"
    private string librarySection;

    [SerializeField]
    // ' Testo per "oppure" tra due azioni
    private string or;

    [SerializeField]
    // ' Testo generico "Dettaglio" o "Dettagli"
    private string detail;

    [SerializeField]
    // ' Testo del pulsante "Elimina"
    private string delete;

   

   [Header("Footer / navigazione")]

    [SerializeField]
    //  ' Testo del footer della schermata "Home"
    private string homeFooter;

    [SerializeField]
    // ' Testo del footer della schermata "Profilo"
    private string profileFooter;

    [SerializeField]
    //  ' Testo del footer della schermata "Camera" (AR)
    private string cameraFooter;

    [SerializeField]
    //' Testo del footer della schermata "Libreria"
    private string libraryFooter;

    [SerializeField]
    //' Testo del footer della schermata "Notifiche/Avvisi"
    private string noticeFooter;
    
    [SerializeField]
   // ' Testo del footer per la sezione "Brand"
    private string brandFooter;



   [Header("Pulsanti e azioni")]

    [SerializeField]
    //' Testo del pulsante che apre il sito web
    private string websiteButtontext;

    [SerializeField]
    // ' Testo del pulsante "Acquista"/"Compra"
    private string buyButtonText;

    


    [Header("Permessi / onboarding")]

    [SerializeField]
    //  ' Testo per completare l’installazione o configurazione iniziale
    private string completeInstallation;
    
    [SerializeField]
   //  ' Testo relativo al permesso di accesso a internet
    private string internetPermission;

    [SerializeField]
    //' Testo relativo al permesso di usare la fotocamera
    private string cameraPermission;

    [SerializeField]
    //' Testo relativo al permesso di usare il GPS
    private string gpsPermission;

    [SerializeField]
    //  ' Testo relativo al permesso di inviare notifiche all’utente
    private string notificationPermission;


    public string _contentSportText
    {
        get { return contentSportText; }
    }

    public string _contentPartnersText
    {
        get { return contentPartnersText; }
    }

    public string _contentEventsText
    {
        get { return contentEventsText; }
    }

    public string _generalContinue
    {
        get { return generalContinue; }
    }

    public string _completeInstallation
    {
        get { return completeInstallation; }
    }

    public string _cameraPermission
    {
        get { return cameraPermission; }
    }

    public string _internetPermission
    {
        get { return internetPermission; }
    }

    public string _gpsPermission
    {
        get { return gpsPermission; }
    }

    public string _notificationPermission
    {
        get { return notificationPermission; }
    }

    public string _continueWith
    {
        get { return continueWith; }
    }

    public string _createNewAccount
    {
        get { return createNewAccount; }
    }

    public string _loginAction
    {
        get { return loginAction; }
    }

    public string _buyButtonText
    {
        get { return buyButtonText; }
    }

    public string _websiteButtontext
    {
        get { return websiteButtontext; }
    }


    public string _homeFooter
    {
        get { return homeFooter; }
    }

    public string _brandFooter
    {
        get { return brandFooter; }
    }

    public string _profileFooter
    {
        get { return profileFooter; }
    }

    public string _noticeSection
    {
        get { return noticeSection; }
    }

    public string _cameraFooter
    {
        get { return cameraFooter; }
    }

    public string _libraryFooter
    {
        get { return libraryFooter; }
    }

    public string _noticeFooter
    {
        get { return noticeFooter; }
    }

    public string _librarySection
    {
        get { return librarySection; }
    }
    public string _or
    {
        get { return or; }
    }

    public string _downloading
    {
        get { return downloading; }
    }

    public string _loggingIn
    {
        get { return loggingIn; }
    }
    public string _loggingOut
    {
        get { return loggingOut; }
    }



    public string _noContentDownloaded
    {
        get { return noContentDownloaded; }
    }

    public string _noContentAvailable
    {
        get { return noContentAvailable; }
    }

    public string _noNotification
    {
        get { return noNotification; }
    }

    public string _detail
    {
        get { return detail; }
    }

    public string _projectDownload
    {
        get { return projectDownload; }
    }


    public string _delete
    {
        get { return delete; }
    }

    public string _passwordForgotten
    {
        get { return passwordForgotten; }
    }

    public string _checkEmailForSignUp
    {
        get { return checkEmailForSignUp; }
    }

    public string _checkEmailForPasswordRecover
    {
        get { return checkEmailForPasswordRecover; }
    }

    public string _passwordRecoverText
    {
        get { return passwordRecoverText; }
    }

    public string _createAccount
    {
        get { return createAccount; }
    }
    public string _usernameInstruction
    {
        get { return usernameInstruction; }
    }


    public string _confirm
    {
        get { return confirm; }
    }

    public string _confirmPassword
    {
        get { return confirmPassword; }
    }

    public string _passwordInstruction
    {
        get { return passwordInstruction; }
    }

    public string _termsAndServices
    {
        get { return termsAndServices; }
    }

    public string _notAMemberYet
    {
        get { return notAMemberYet; }
    }

    public string _loadingAR
    {
        get { return loadingAR; }
    }

    public string _initializating
    {
        get { return initializating; }
    }

    public string _deletingInProgress
    {
        get { return deletingInProgress; }
    }

    public string _refreshingAR
    {
        get { return refreshingAR; }
    }

    public string _decompressing
    {
        get { return decompressing; }
    }

    public string _loadingProfile
    {
        get { return loadingProfile; }
    }

    public string _findNewContentTitle
    {
        get { return findNewContentTitle; }
    }

    public string _findNewContentBody
    {
        get { return findNewContentBody; }
    }

    public string _keepWatchingTitle
    {
        get { return keepWatchingTitle; }
    }

    public string _keepWatchingBody
    {
        get { return keepWatchingBody; }
    }
    
    public string _keepWatchingBodyNo
    {
        get { return keepWatchingBodyNo; }
    }

    public string _latestVersion
    {
        get { return latestVersion; }
    }

    public string _loading
    {
        get { return loading; }
    }

    public List<PopupInfoJson> _popupInfoJson
    {
        get { return popupInfoJson; }
    }

    public List<PopupChoiceJson>_popupChoiceJson
    {
        get { return popupChoiceJson; }
    }

    public List<PopupTutorialJson> _popupTutorialJson
    {
        get { return popupTutorialJson; }
    }

    public List<PopupMaintainanceJson> _popupMaintainanceJson
    {
        get { return popupMaintainanceJson; }
    }



}
